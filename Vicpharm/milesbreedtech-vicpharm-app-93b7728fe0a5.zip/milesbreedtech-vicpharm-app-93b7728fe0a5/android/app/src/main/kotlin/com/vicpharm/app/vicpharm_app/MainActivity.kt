package com.vicpharm.app.vicpharm_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

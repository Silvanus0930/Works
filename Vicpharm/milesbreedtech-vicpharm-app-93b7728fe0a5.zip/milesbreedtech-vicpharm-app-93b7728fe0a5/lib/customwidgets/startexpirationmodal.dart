import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vicpharm_app/customwidgets/completeexpirationmodal.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class StartExpirationModal extends StatefulWidget {
  StartExpirationModal({Key? key}) : super(key: key);

  @override
  _StartExpirationModalState createState() => _StartExpirationModalState();
}

class _StartExpirationModalState extends State<StartExpirationModal> {

  Widget _selectProductDialog(BuildContext context) {
      return Container(
                height: Get.height * 0.7,
                width: Get.width * 0.8,
                child: Padding(
                  padding: const EdgeInsets.all(0.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        color: mainColor,
                        width: double.infinity,
                        height: Get.height * 0.08,
                        child: Stack(
                          //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: IconButton(
                                icon: Icon(Icons.close, color: whiteBG, size: 14,),
                                onPressed: (){
                                  Get.back();
                                },
                              ),
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: Text(
                                "Select Product",
                                style: TextStyle(color: whiteBG, fontFamily: 'PoppinsSemiBold', fontSize: 12),
                              ),
                            ),

                          ],
                        ),
                      ),

                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.05,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 15, right: 15, top:10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("NAME",
                                style: TextStyle(fontSize: 14),),
                              Text("QTY",
                                style: TextStyle(fontSize: 14),),
                            ],
                          ),
                        ),
                      ),

                      Padding(
                        padding: const EdgeInsets.only(right: 20, left: 20),
                        child: Divider(thickness: 2, color: Color(0xb21c63ba),),
                      ),

                      Expanded(

                        child: ListView(
                          shrinkWrap: true,
                          children: List.generate(9, (index) => ListTile(
                            onTap: (){
                              //selectedProduct = products[index];
                              //print(selectedProduct.name);
                              //productid = products[index].sId;
                              //quantity = products[index].availableQuantity;
                              Navigator.of(context).pop();
                              Get.dialog(
                                CompleteExpirationModal(),
                                barrierDismissible: true
                              );
                            },
                            leading: Text(
                              "Para",//products[index].name,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),

                            ),
                            trailing: Text(
                              "67",//products[index].availableQuantity.toString(),
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),
                            ),
                          )),
                        ),
                      ),


                    ],
                  ),
                ),
              );
           
  }


  @override
  Widget build(BuildContext context) {
    return Center(
       child: Material(
         child: _selectProductDialog(context),
       )
    );
  }
}
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class CompleteExpirationModal extends StatefulWidget {
  CompleteExpirationModal({Key? key}) : super(key: key);

  @override
  _CompleteExpirationModalState createState() => _CompleteExpirationModalState();
}

class _CompleteExpirationModalState extends State<CompleteExpirationModal> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController qtyController = new TextEditingController();

  Widget dialogHeader(BuildContext context) {
    return Container(
      color: mainColor,
      width: double.infinity,
      height: MediaQuery.of(context).size.height * 0.07,
      child: Stack(

        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: IconButton(
              icon: Icon(Icons.close, color: whiteBG, size: 16,),
              onPressed: (){
                Navigator.of(context).pop();
              },
            ),
          ),

          Align(
            alignment: Alignment.center,
            child: Text(
              "Expire Product(s)",
              style: TextStyle(color: whiteBG, fontFamily: 'PoppinsSemiBold', fontSize: 12),
            ),
          ),

        ],
      ),
    );
  }


  Widget itemContainer(BuildContext context) {
    return Container(

      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [

          Padding(
            padding: const EdgeInsets.only(top: 8, right: 1, left: 8, bottom: 8),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.4,
              child: Text("Para", overflow: TextOverflow.ellipsis,style: TextStyle(fontSize: 12),),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8, right: 8, left: 1, bottom: 8),
            child: qtyContainer(context),
          )
        ],
      ),
    );
  }

  Widget qtyContainer(BuildContext context){
    return Container(
      padding: EdgeInsets.all(0.0),
      width: Get.width * 0.25,
      height: 40, //MediaQuery.of(context).size.height * 0.5,
      decoration: BoxDecoration(

          borderRadius:  BorderRadius.all(Radius.circular(10))
      ),
      child: TextField(
        keyboardType: TextInputType.number,
        style: TextStyle(color: mvsblue, fontFamily: 'PoppinsRegular', fontSize: 12),
        controller: qtyController,
        textAlign: TextAlign.center,
        decoration: InputDecoration(

          border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10))
          ),
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10))
          ),
          enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10))
          ),
          filled: true,
          fillColor: Color(0xffdadada),
        ),
      ),
    );
  }

  Widget expireBtn(BuildContext context) => Padding(
    padding: EdgeInsets.only(top: 20, right: 20.0, bottom: 5.0),
    child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.08,
        width: MediaQuery.of(context).size.width * 0.4,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(50)),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                blurRadius: 15,
                spreadRadius: 3,
                offset: Offset(-1, 20),
              ),
            ],
          ),
          child: MaterialButton(
            elevation: 0.0,
            shape: StadiumBorder(),

            onPressed: (){
              

            },

            color: mainColor,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Expire",
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: whiteBG),
                  ),
                ),
                Align(
                    alignment: Alignment.centerRight,
                    child: Icon(Icons.arrow_forward_ios,size: 16, color: whiteBG)),
              ],
            ),

          ),
        )
    ),
  );




  Widget _expDialog() {
    return SingleChildScrollView(
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.4,
                  width: MediaQuery.of(context).size.width * 0.8,
                  child: Padding(
                    padding: const EdgeInsets.all(0.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        dialogHeader(context),
                        /**Padding(
                            padding: const EdgeInsets.only(top: 15.0, left: 10, right: 10),
                            child: filterField(context),
                            ),**/

                        Padding(
                          padding: const EdgeInsets.only(top: 20, bottom: 8, left: 10, right: 30),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("NAME", style: TextStyle(fontSize: 14),),
                              Text("QTY", style: TextStyle(fontSize: 14),)
                            ],
                          ),
                        ),
                        //itemsList(context),
                        itemContainer(context),


                        expireBtn(context),
                      ],
                    ),
                  ),
                ),
              );
            
  }



  @override
  Widget build(BuildContext context) {
    return Center(
       child: Material(
         child: _expDialog()
       )
    );
  }
}
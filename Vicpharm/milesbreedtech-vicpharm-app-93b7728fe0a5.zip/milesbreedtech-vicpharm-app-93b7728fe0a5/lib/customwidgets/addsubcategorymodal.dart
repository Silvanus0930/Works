import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class AddSubCategoryModal extends StatefulWidget {
  
  @override
  _AddSubCategoryModalState createState() => _AddSubCategoryModalState();
}

class _AddSubCategoryModalState extends State<AddSubCategoryModal> {
  TextEditingController nameController = new TextEditingController();

  Widget receiptidField(BuildContext context) => Material(
    child: TextField(
      style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      controller: nameController,
      enableSuggestions: true,
      autocorrect: true,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.done,
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            suffixIcon: Icon(Icons.description, color: Colors.grey, size: 16,),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Enter Category",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),

    ),
  );

  Widget startBtn(BuildContext context) => Padding(
    padding: EdgeInsets.only(top: 20, right: 20.0, bottom: 5.0),
    child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.07,
        width: MediaQuery.of(context).size.width * 0.3,
        child: Container(
          decoration: BoxDecoration(

            borderRadius: BorderRadius.all(Radius.circular(50)),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                blurRadius: 15,
                spreadRadius: 3,
                offset: Offset(-1, 20),
              ),
            ],
          ),
          child: MaterialButton(
            elevation: 0.0,
            shape: StadiumBorder(),
            onPressed: (){
                    print("iiii");
                    
                    if(nameController.text.isNotEmpty){
                      Get.back();
                      Provider.of<InventoryProvider>(context, listen: false).addSubCategory(nameController.text);
                    }else{
                      LoadingControl.showSnackBar(
                        "Ouchs!!!", 
                        "Subcategory name is required", 
                        Icon(Icons.error, color: Colors.red,)
                      );
                    }
                    //Get.to(() => FoundReturnScreen());
                  },
            color: mainColor,
            child: Stack(
              //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Save",
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: whiteBG),
                  ),
                ),
                Align(alignment: Alignment.centerRight, child: Icon(Icons.arrow_forward_ios,size: 16, color: whiteBG)),
              ],
            ),

          ),
        )
    ),
  );

  Widget formContainer(BuildContext context) => SingleChildScrollView(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
          child: receiptidField(context),
        ),

        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
          child: Align(
              alignment: Alignment.bottomCenter,
              child: startBtn(context)),
        ),
      ],
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        borderRadius: BorderRadius.all(Radius.circular(10)),
        child: Container(
                  height:Get.height * 0.3,
                  width: Get.width * 0.8,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(10))
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(0.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(                          
                          width: double.infinity,
                          height: Get.height * 0.07,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
                            color: mainColor,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              IconButton(
                                icon: Icon(Icons.close, color: whiteBG, size: 14,),
                                onPressed: (){
                                  Navigator.of(context).pop();
                                },
                              ),
                              SizedBox(
                                width: 50,
                              ),
                              Text(
                                "Initiate Return",
                                style: TextStyle(color: whiteBG, fontFamily: 'PoppinsSemiBold', fontSize: 12),
                              ),

                            ],
                          ),
                        ),

                        formContainer(context),
                      ],
                    ),
                  ),
                ),
      ),
    );
  }

}
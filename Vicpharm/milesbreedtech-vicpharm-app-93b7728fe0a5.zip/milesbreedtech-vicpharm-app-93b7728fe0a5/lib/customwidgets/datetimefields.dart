import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class AndroidDateTimeField extends StatelessWidget {
  TextEditingController? expiryDateController;
  String? label;
  AndroidDateTimeField({
    this.expiryDateController,
    this.label

  });

  final format = DateFormat("yyyy-MM-dd");
  @override
  
  Widget build(BuildContext context) {
    return DateTimeField(
      controller: expiryDateController,
      style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),

          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          suffixIcon: Icon(Icons.calendar_today, color: Colors.grey, size: 16,),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
          hintText: label,
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

        format: format,
        onShowPicker: (context, currentValue) async {
          final date = await showDatePicker(
              context: context,
              firstDate: DateTime(1900),
              initialDate: currentValue ?? DateTime.now(),
              lastDate: DateTime(2100));
          if (date != null) {
         
            return DateTimeField.combine(date, null);
          } else {
            return currentValue;
          }
        },
      );

  }
}

class IosDateTimeField extends StatefulWidget {

  TextEditingController? expiryDateController;
  String? label;

  IosDateTimeField({this.expiryDateController, this.label});

  @override
  _IosDateTimeFieldState createState() => _IosDateTimeFieldState();
}



class _IosDateTimeFieldState extends State<IosDateTimeField> {
  final format = DateFormat("yyyy-MM-dd");
  DateTime? value;

  @override
  Widget build(BuildContext context) {
    return Material(
          child: DateTimeField(enableInteractiveSelection: true,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
        controller: widget.expiryDateController,
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),

            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            suffixIcon: Icon(Icons.calendar_today, color: Colors.grey, size: 16,),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: widget.label,
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
          initialValue: value,
          format: format,
          onShowPicker: (context, currentValue) async {
            await showCupertinoModalPopup(
                context: context,
                builder: (context) {
                  return CupertinoDatePicker(
                    mode: CupertinoDatePickerMode.date,
                    backgroundColor: Colors.white,

                    onDateTimeChanged: (DateTime date) {
                      value = date;
                      Navigator.of(context).pop();
                    },
                  );
                });
            setState(() {});
            return value;
          },
        ),
    );

  }
}
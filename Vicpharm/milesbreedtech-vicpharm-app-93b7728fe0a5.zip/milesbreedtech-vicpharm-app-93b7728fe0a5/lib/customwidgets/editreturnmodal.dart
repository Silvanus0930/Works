import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/customwidgets/completereturnmodal.dart';
import 'package:vicpharm_app/models/returnproductrequest.dart';
import 'package:vicpharm_app/screens/return/returnprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class EditReturnModal extends StatefulWidget {
  EditReturnModal({Key? key}) : super(key: key);

  @override
  _EditReturnModalState createState() => _EditReturnModalState();
}

class _EditReturnModalState extends State<EditReturnModal> {
  List<TextEditingController> qtyControllers = [];
  Map<String, dynamic> qtyMap = Map<String, dynamic>();
  var currencyFormat = new NumberFormat.currency(locale: "en_US", symbol: "\u{020A6} ");

  @override
  void initState() { 
    super.initState();
    //qtyControllers = List.generate(Provider.of<ReturnProvider>(context, listen: false).selectedProductDetail!.length, (index) => TextEditingController());
  }

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Edit Quantity",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 16,),
      onPressed: (){
        Get.back();
       /* Navigator.push(
          _scaffoldKey.currentContext,
          BouncyPageRoute(widget: ReturnRecordsPage()),
        ); */
      }
    ),


  );

  Widget startBtn(BuildContext context) => Padding(
    padding: EdgeInsets.only(top: 20, right: 20.0, bottom: 5.0),
    child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.07,
        width: MediaQuery.of(context).size.width * 0.4,
        child: Container(
          decoration: BoxDecoration(

            borderRadius: BorderRadius.all(Radius.circular(50)),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                blurRadius: 15,
                spreadRadius: 3,
                offset: Offset(-1, 20),
              ),
            ],
          ),
          child: MaterialButton(
            elevation: 0.0,
            shape: StadiumBorder(),
            onPressed: (){
              print(qtyMap);
              Map<String, dynamic> qtyMapReal = Map<String, dynamic>();
              qtyMap.entries.forEach((element) { 
                if(element.value > 0){
                  qtyMapReal[element.key] = element.value;
                }
              });

              print(qtyMapReal);

              ReturnProductRequest rpr = ReturnProductRequest(
                quantity: qtyMapReal
              );   
              Provider.of<ReturnProvider>(context, listen: false).setRpr(rpr);

              Get.dialog(
                CompleteReturnModal(),
                
              );    
            },
            color: mainColor,
            child: Stack(
              //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Continue",
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: whiteBG),
                  ),
                ),
                Align(alignment: Alignment.centerRight, child: Icon(Icons.arrow_forward_ios,size: 16, color: whiteBG)),
              ],
            ),

          ),
        )
    ),
  );

    
   Widget dialogHeader(BuildContext context) {
    return Container(
      
      width: double.infinity,
      height: Get.height * 0.07,
      decoration: BoxDecoration(
        color: mainColor,
        borderRadius: BorderRadius.only(topRight: Radius.circular(10), topLeft: Radius.circular(10)),
      ),
      child: Stack(

        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: IconButton(
              icon: Icon(Icons.close, color: whiteBG, size: 14,),
              onPressed: (){
                Navigator.of(context).pop();
              },
            ),
          ),

          Align(
            alignment: Alignment.center,
            child: Text(
              "Edit Quantity",
              style: TextStyle(color: whiteBG, fontFamily: 'PoppinsSemiBold', fontSize: 12),
            ),
          ),

        ],
      ),
    );
  }

  
  Widget returnBtn(BuildContext context) => Padding(
    padding: EdgeInsets.only(top: 20, right: 10.0, left: 10, bottom: 10.0),
    child: SizedBox(
        height: Get.height * 0.08,
        width: Get.width * 0.4,
        child: Container(
          decoration: BoxDecoration(

            borderRadius: BorderRadius.all(Radius.circular(50)),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                blurRadius: 15,
                spreadRadius: 3,
                offset: Offset(-1, 20),
              ),
            ],
          ),
          child: MaterialButton(
            elevation: 0.0,
            shape: StadiumBorder(),

            onPressed: (){
              Get.back(closeOverlays: true);
              Get.dialog(
                CompleteReturnModal(),
                barrierDismissible: true
              );
              /* ProductDetails pd = new ProductDetails();
              for(var i = 0; i < rProducts.length; i++){
                if(rProducts[i].selected){
                  print(rProducts[i].productName);
                  pd = rProducts[i];
                  break;
                }
              }

              Navigator.of(context).pop();
              if(pd.id == null){
                _errorDialog(context, "You have not selected any product yet. Please select a product to continue.");
              }else{
                _miscDialog2(rProducts, pd);
              } */

            },

            color: mainColor,
            child: Stack(
              //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Continue",
                    style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold', color: whiteBG),
                  ),
                ),
                Align(alignment: Alignment.centerRight, child: Icon(Icons.arrow_forward_ios,size: 16, color: whiteBG)),
              ],
            ),

          ),
        )
    ),
  );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: appbar(context),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Column(
                children: Provider.of<ReturnProvider>(context, listen: true).selectedProductDetail!.quantity!.entries.map((e) {
              //var name = Provider.of<ReturnProvider>(context, listen: true).selectedProductDetail!.productName;
              var sellingPrice = Provider.of<ReturnProvider>(context, listen: true).selectedProductDetail!.sellingPrice![e.key];
              
              return Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    child: Text("${e.key}".capitalizeFirst!, style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14),),
                  ),
                   
                   Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: TextField(
                      //controller: qtyControllers[index],
                      onEditingComplete: () => FocusScope.of(context).nextFocus(),
                      style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12, color: Colors.black),
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0xffecf0f1),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                        hintText: "Quantity sold: ${e.value} || unit Price: ${currencyFormat.format(sellingPrice)}",
                        hintStyle: TextStyle(fontFamily: 'Roboto', fontSize: 13, color: grey)
                  ),
        
                      onChanged: (String value){
                        if(value.isNotEmpty){
                          qtyMap[e.key] = double.tryParse(value);
                          //Provider.of<InventoryProvider>(context, listen: false).setMapQty(invp.measurements![index], double.parse(qtyControllers[index].text));
                        }else{
                          qtyMap[e.key] = 0.0;
                        }
                      },
                    ),
                  ),
                
                ],
              );
            }).toList(),
              ),

              startBtn(context)
            ]
          ),
        ),
      )
    );     
  }

}
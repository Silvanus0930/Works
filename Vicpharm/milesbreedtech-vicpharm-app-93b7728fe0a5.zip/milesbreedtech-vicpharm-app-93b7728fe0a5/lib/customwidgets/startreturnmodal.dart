import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/customwidgets/completereturnmodal.dart';
import 'package:vicpharm_app/customwidgets/editreturnmodal.dart';
import 'package:vicpharm_app/screens/return/returnprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class StartReturnModal extends StatefulWidget {
  StartReturnModal({Key? key}) : super(key: key);

  @override
  _StartReturnModalState createState() => _StartReturnModalState();
}

class _StartReturnModalState extends State<StartReturnModal> {
  //List<TextEditingController> _controllers = [];

  Widget dialogHeader(BuildContext context) {
    return Container(
      
      width: double.infinity,
      height: Get.height * 0.07,
      decoration: BoxDecoration(
        color: mainColor,
        borderRadius: BorderRadius.only(topRight: Radius.circular(10), topLeft: Radius.circular(10)),
      ),
      child: Stack(

        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: IconButton(
              icon: Icon(Icons.close, color: whiteBG, size: 14,),
              onPressed: (){
                Navigator.of(context).pop();
              },
            ),
          ),

          Align(
            alignment: Alignment.center,
            child: Text(
              "Return Product",
              style: TextStyle(color: whiteBG, fontFamily: 'PoppinsSemiBold', fontSize: 12),
            ),
          ),

        ],
      ),
    );
  }

  
  Widget returnBtn(BuildContext context) => Padding(
    padding: EdgeInsets.only(top: 20, right: 10.0, left: 10, bottom: 10.0),
    child: SizedBox(
        height: Get.height * 0.08,
        width: Get.width * 0.4,
        child: Container(
          decoration: BoxDecoration(

            borderRadius: BorderRadius.all(Radius.circular(50)),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                blurRadius: 15,
                spreadRadius: 3,
                offset: Offset(-1, 20),
              ),
            ],
          ),
          child: MaterialButton(
            elevation: 0.0,
            shape: StadiumBorder(),

            onPressed: (){
              Get.back(closeOverlays: true);
              Get.dialog(
                CompleteReturnModal(),
                barrierDismissible: true
              );
              /* ProductDetails pd = new ProductDetails();
              for(var i = 0; i < rProducts.length; i++){
                if(rProducts[i].selected){
                  print(rProducts[i].productName);
                  pd = rProducts[i];
                  break;
                }
              }

              Navigator.of(context).pop();
              if(pd.id == null){
                _errorDialog(context, "You have not selected any product yet. Please select a product to continue.");
              }else{
                _miscDialog2(rProducts, pd);
              } */

            },

            color: mainColor,
            child: Stack(
              //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Continue",
                    style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold', color: whiteBG),
                  ),
                ),
                Align(alignment: Alignment.centerRight, child: Icon(Icons.arrow_forward_ios,size: 16, color: whiteBG)),
              ],
            ),

          ),
        )
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        borderRadius: BorderRadius.all(Radius.circular(10)),
        child: Container(
                      height: Get.height * 0.65,
                      width: Get.width * 0.8,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(topRight: Radius.circular(10), topLeft: Radius.circular(10)),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(0.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            dialogHeader(context),
                            /**Padding(
                                padding: const EdgeInsets.only(top: 15.0, left: 10, right: 10),
                                child: filterField(context),
                                ),**/

                            
                            //itemsList(context),
                            //itemListContainer(context, data.productDetails),
                          Container(

                            child: Expanded(
                              child: ListView(
                                children: List.generate(Provider.of<ReturnProvider>(context, listen: true).selectedSaleRecord!.productDetails!.length, (index) {
                                  

                                  var srr = Provider.of<ReturnProvider>(context, listen: true).selectedSaleRecord!.productDetails![index];


                                  return InkWell(
                                    onTap: (){
                                      Get.back();
                                      Provider.of<ReturnProvider>(context, listen: false).setSelectedProductDetail(srr);
                                      
                                      Get.to(() => EditReturnModal());

                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [

                                          
                                          Expanded(
                                            child: Padding(
                                              padding: const EdgeInsets.only(top: 8, right: 1, left: 8, bottom: 8),
                                              child: Container(
                                                width: MediaQuery.of(context).size.width * 0.4,
                                                child: Text("${srr.productName}", overflow: TextOverflow.fade,style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),),
                                              ),
                                            ),
                                          ),

                                         
                                        ],
                                      ),
                                    ),
                                  );
                                }),
                              ),
                            ),
                          ),

                            returnBtn(context),
                          ],
                        ),
                      ),
                    ),
      ),
    );
              
  }

}
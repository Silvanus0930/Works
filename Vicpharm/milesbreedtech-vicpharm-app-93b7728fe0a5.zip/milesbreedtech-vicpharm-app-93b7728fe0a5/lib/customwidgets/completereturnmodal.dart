import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/models/returnproductrequest.dart';
import 'package:vicpharm_app/screens/return/returnprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class CompleteReturnModal extends StatefulWidget {
  CompleteReturnModal({Key? key}) : super(key: key);

  @override
  _CompleteReturnModalState createState() => _CompleteReturnModalState();
}

class _CompleteReturnModalState extends State<CompleteReturnModal> {
  TextEditingController amtRetController = new TextEditingController();
  TextEditingController commentController = new TextEditingController();
  TextEditingController qtyController = new TextEditingController();
  TextEditingController recIdController = new TextEditingController();
  String rType = "Refund";
  List<String> rTypes = <String>["Refund", "Replace"];
  double _refundAmount = 0.0;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  Widget dialogHeader(BuildContext context) {
    return Container(
      
      width: double.infinity,
      height: Get.height * 0.07,
      decoration: BoxDecoration(
        color: mainColor,
        borderRadius: BorderRadius.only(topRight: Radius.circular(10), topLeft: Radius.circular(10)),
      ),
      child: Stack(

        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: IconButton(
              icon: Icon(Icons.close, color: whiteBG, size: 14,),
              onPressed: (){
                Navigator.of(context).pop();
              },
            ),
          ),

          Align(
            alignment: Alignment.center,
            child: Text(
              "Return Product",
              style: TextStyle(color: whiteBG, fontFamily: 'PoppinsSemiBold', fontSize: 12),
            ),
          ),

        ],
      ),
    );
  }

  Widget returnBtn(BuildContext context) => Padding(
    padding: EdgeInsets.only(top: 20, right: 20.0, bottom: 5.0),
    child: SizedBox(
        height: Get.height * 0.08,
        width: Get.width * 0.4,
        child: Container(
          decoration: BoxDecoration(

            borderRadius: BorderRadius.all(Radius.circular(50)),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                blurRadius: 15,
                spreadRadius: 3,
                offset: Offset(-1, 20),
              ),
            ],
          ),
          child: MaterialButton(
            elevation: 0.0,
            shape: StadiumBorder(),
            onPressed: (){
              Get.back();
              ReturnProductRequest oldRpr = Provider.of<ReturnProvider>(context, listen: false).rpr!;
              ReturnProductRequest rpr = ReturnProductRequest(
                quantity: oldRpr.quantity,
                salesId: Provider.of<ReturnProvider>(context, listen: false).selectedSaleRecord!.sId,
                productId: Provider.of<ReturnProvider>(context, listen: false).selectedProductDetail!.id,
                productUniqueId: "",
                returnType: rType,
                amountReturn:  _refundAmount, //amtRetController.text.isNotEmpty ? double.parse(amtRetController.text): 0.0,
                comment: commentController.text,
                reduceTheAmountOwning: Provider.of<ReturnProvider>(context, listen: false).selectedSaleRecord!.typeOfsales == "creditSales" ? true : false

              );

              Provider.of<ReturnProvider>(context, listen: false).returnProduct(rpr);


            },
            color: mainColor,
            child: Stack(
              //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Return",
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: whiteBG),
                  ),
                ),
                Align(alignment: Alignment.centerRight, child: Icon(Icons.arrow_forward_ios,size: 16, color: whiteBG)),
              ],
            ),

          ),
        )
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        borderRadius: BorderRadius.all(Radius.circular(10)),
        child: Container(
                      height: MediaQuery.of(context).size.height * 0.8,
                      width: MediaQuery.of(context).size.width * 0.8,
                      child: Padding(
                        padding: const EdgeInsets.all(0.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            dialogHeader(context),
                            
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(left: 8, top: 20.0, right: 8.0),
                                    child: Container(
                                      decoration: BoxDecoration(
                                          color: Color(0xffecf0f1),
                                          borderRadius: BorderRadius.all(Radius.circular(10))
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 10, right: 10, top: 10, bottom: 10),
                                        child: DropdownButton<String>(
                                          hint: Text("Select Return Type",
                                              style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)
                                          ),
                                          value: rType,
                                          icon: Icon(Icons.arrow_drop_down, color: grey,),
                                          elevation: 10,
                                          style: TextStyle(color: mainColor),
                                          underline: Container(
                                            height: 1,
                                            color: Colors.transparent,
                                          ),
                                          onChanged: (String? value){
                                            setState(() {
                                              print(value);
                                              rType =  value!;
                                              print(rType);
                                            });

                                          },
                                          isExpanded: true,
                                          items: rTypes.map((value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Text(value, style: TextStyle(fontSize: 12, color: black),),
                                            );
                                          }).toList(),
                                        ),
                                      ),
                                    ),
                                  ),


                                  Padding(
                                    padding: EdgeInsets.only(left: 8, top: 10.0, right: 8.0),
                                    child: TextField(
                                      controller: amtRetController,
                                      maxLines: 1,
                                      style: TextStyle(fontFamily: 'Roboto', fontSize: 13, color: Colors.black),
                                      keyboardType: TextInputType.number,
                                      inputFormatters: [
                                        CurrencyTextInputFormatter(
                                          //locale: 'ko',
                                          decimalDigits: 2,
                                          symbol: '\u{020A6}', // or to remove symbol set ''.
                                        )
                                      ],
                                      onChanged: (String? value){
                                        print(value);
                                        if(value != null && value.isNotEmpty){
                                          String _onlyDigits = value.replaceAll(RegExp('[^0-9]'), "");
                                          double? _doubleValue = 0.0;
                                          _doubleValue = double.tryParse(_onlyDigits);
                                          if(_doubleValue != null){
                                            _doubleValue = _doubleValue / 100;
                                          }else{
                                            setState(() {
                                              _refundAmount = 0.0;
                                            });
                                            return;
                                          }
                                          
                                          print(_doubleValue);
                                          print("textcontroller:");
                                          print(amtRetController.text);
                                          setState(() {
                                            _refundAmount  = _doubleValue!;
                                          });
                                          
                                        }
                                      },
                                      decoration: InputDecoration(
                                          filled: true,
                                          fillColor: Color(0xffecf0f1),
                                          border: OutlineInputBorder(
                                            borderSide: BorderSide.none,
                                            borderRadius: BorderRadius.all(Radius.circular(10)),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide.none,
                                            borderRadius: BorderRadius.all(Radius.circular(10)),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide.none,
                                            borderRadius: BorderRadius.all(Radius.circular(10)),
                                          ),
                                          
                                          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                                          hintText: "Amount Returned",
                                          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                                      ),

                                    ),
                                  ),

                                  Padding(
                                    padding: EdgeInsets.only(left: 8, top: 10.0, right: 8.0),
                                    child: TextField(
                                      controller: commentController,
                                      maxLines: 5,
                                      maxLength: 500,
                                      style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 16, color: black),
                                      decoration: InputDecoration(
                                          filled: true,
                                          fillColor: Color(0xffecf0f1),

                                          border: OutlineInputBorder(
                                            borderSide: BorderSide.none,
                                            borderRadius: BorderRadius.all(Radius.circular(10)),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide.none,
                                            borderRadius: BorderRadius.all(Radius.circular(10)),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide.none,
                                            borderRadius: BorderRadius.all(Radius.circular(10)),
                                          ),

                                          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                                          hintText: "Comments",
                                          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14, color: grey)
                                      ),

                                    ),
                                  ),
                                ],
                              ),
                            ),
                            returnBtn(context),
                          ],
                        ),
                      ),
                    ),
      ),
    );
             
  }
}
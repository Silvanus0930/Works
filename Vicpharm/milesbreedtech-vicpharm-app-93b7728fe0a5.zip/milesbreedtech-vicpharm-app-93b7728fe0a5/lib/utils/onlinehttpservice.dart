import 'package:vicpharm_app/utils/sharedprefs.dart';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:http_parser/http_parser.dart';

class OnlineHttpService {
  String baseUrl = "https://vicpharm.milesbreed.com/";

  Future<dynamic> allOnlineOrdersRequest(int page) async {

    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/OnlineSale/GetOnlineOrder?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {

      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> allApprovedOnlineOrdersRequest(int page) async {

    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/OnlineSale/GetOnlineApproveOrder?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {

      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> allTransitOnlineOrdersRequest(int page) async {

    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/OnlineSale/GetTransitOrder?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {

      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> allPackedOnlineOrdersRequest(int page) async {

    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/OnlineSale/GetPackedOrder?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {

      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> allIssuesOnlineOrdersRequest(int page) async {

    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/OnlineSale/GetIssuesOrders?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {

      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> allCompletedOnlineOrdersRequest(int page) async {

    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/OnlineSale/GetCompletedOrder?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {

      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> allCancelledOnlineOrdersRequest(int page) async {

    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/OnlineSale/GetCancelOrder?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {

      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

}
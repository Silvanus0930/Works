import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

class CurrencyInputFormatter extends TextInputFormatter {
  int? maxDigits;
  CurrencyInputFormatter({this.maxDigits});
  

  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    print(newValue.text);
    print(oldValue.text);

    if (newValue.selection.baseOffset == 0) {
      return newValue;
    }

    if (maxDigits != null && newValue.selection.baseOffset > maxDigits!) {
      return oldValue;
    }

    double? value = 0.0;

    if(newValue.text.runtimeType == String){
      value = 0.0;
    }else{
      value = double.tryParse(newValue.text);
    }

    
    final formatter = new NumberFormat("###0.00", "pt_BR");
    //String newText = "R\$ " + formatter.format(value! / 100);
    String newText = formatter.format(value! / 100);
    
     
    return newValue.copyWith(
        text: newText,
        selection: new TextSelection.collapsed(offset: newText.length));
    
  }
}
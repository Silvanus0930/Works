import 'package:flutter/material.dart';

Color mainColor = Color(0xff662D6C); // primary buttons
Color errorTextColor = Colors.red;
Color grey = Colors.grey;

Color whiteBG =  Colors.white;
Color whiteBGOp = Color.fromRGBO(255, 255, 255, 0.1);
Color badPWDColor = Color(0xFFeed72b);
Color black = Colors.black;
Color mvsblue = Color(0xFF662d6c);
Color mvsdarkyellow = Color(0xFFf2994a);
Color randomStatusColor = mvsdarkyellow;
Color randomNavigationColor = mvsdarkyellow;
Color mvsred = Color(0xFFFF0000);
Color fieldOffWhite = Color(0xffeeeeee);
Color containerborder = Color(0xFF000080);
Color darkModeColor = Color(0xFF212121);
Color drawerCircles = Color(0xffe7f6ff);
Color customcirclesColor = Color(0x12f1c40f);


Map<int, Color> cColor = {
  50: Color.fromRGBO(102, 45, 108, .1),
  100: Color.fromRGBO(102, 45, 108, .2),
  200: Color.fromRGBO(102, 45, 108, .3),
  300: Color.fromRGBO(102, 45, 108, .4),
  400: Color.fromRGBO(102, 45, 108, .5),
  500: Color.fromRGBO(102, 45, 108, .6),
  600: Color.fromRGBO(102, 45, 108, .7),
  700: Color.fromRGBO(102, 45, 108, .8),
  800: Color.fromRGBO(102, 45, 108, .9),
  900: Color.fromRGBO(102, 45, 108, 1),
};

MaterialColor materialMainColor = MaterialColor(
    0xff662D6C,
    cColor);
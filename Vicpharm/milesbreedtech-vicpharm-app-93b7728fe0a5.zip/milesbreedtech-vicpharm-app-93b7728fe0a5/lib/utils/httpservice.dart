import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:http_parser/http_parser.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/models/checkoutproduct.dart';
import 'package:vicpharm_app/models/inventory.dart';
import 'package:vicpharm_app/models/profile.dart';
import 'package:vicpharm_app/models/returnproductrequest.dart';
import 'package:vicpharm_app/models/staff.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/utils/sharedprefs.dart';

class HttpService {
  String baseUrl = "https://vicpharm.milesbreed.com/";//"https://pharmacy.vicpharm.store/";;//"https://vicpharm.milesbreed.com/";

  Future<dynamic> staffLoginRequest(String phoneNumber, String password) async {
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Staff/Login";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
            "phoneNumber": phoneNumber,
            "password": password
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.post(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json'
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> getProductsRequest() async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Product/GetProduct";
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> changePasswordRequest(String oldPassword, String newPassword) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Staff/ChangePassword";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
              "oldPassword": oldPassword,
              "newPassword": newPassword
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> getActivitiesRequest(int page) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Activity/GetActivities?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> getStaffsRequest(int page) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Staff/GetAllStaffs?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> getStaffPositionsRequest() async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Staff/GetAvailableStaffPosition";
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

 
  Future<dynamic> changeStaffPositionRequest( String staffId,  String positionId) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Staff/ChangeStaffPosition";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
              "staffId": staffId, 
              "positionId": positionId
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> actiavteDeactivateStaffRequest( String staffId,  bool active) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Staff/ActivateAndDeactivate";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
              "staffId": staffId, 
              "active": active
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> searchStaffRequest(String keywords) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Staff/SearchStaff";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
              "keywords": keywords
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> getAllRolesRequest() async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Staff/GetRoles";
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> updatePositionRequest( String positionId, List<String> roles, String positionName) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Staff/UpdatePosition";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
              "positionId": positionId,
              "roles": roles,
              "positionName" : positionName
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> createPositionRequest(List<String> roles, String positionName) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Staff/CreateStaffPosition";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
              "roles": roles,
              "positionName" : positionName
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.post(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> createAdvertRequest(String advert) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Advert/AddAdvert";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
              "advert": advert
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.post(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> getAllAdvertsRequest() async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Advert/GetAdvert";
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> deleteAdvertRequest(String advertId) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Advert/DeleteAdvert";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
              "advertId": advertId
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> getCustomersRequest(int page) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Customer/GetCustomers?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> searchCustomerRequest(String keywords) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Customer/SearchCustomer";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
              "keywords": keywords
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      //print(response);
      print("");
      print("");
      //print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> editCustomerRequest(
    String customerId,
    String fullName,
    String email,
    String address,
    String gender,
    String age) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Customer/UpdateCustomer";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
            "customerId": customerId,
            "fullName": fullName,
            "email": email,
            "address": address,
            "gender": gender,
            "age": age
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

  Future<dynamic> addCustomerRequest(
    String fullName,
    String phoneNumber,
    String email,
    String address,
    String gender,
    String age) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Customer/AddCustomer";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
            "fullName": fullName,
            "phoneNumber": phoneNumber,
            "email": email,
            "address": address,
            "gender": gender,
            "age": age
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.post(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getInventoryRequest(int page) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Inventory/GetInventory?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> saleProductRequest(CheckoutProduct cp) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Sales/AddSales";
    print(url);
    var dio = Dio();
    try {

      var jsonDetails = jsonEncode(cp.productDetails);
      print(jsonDetails);

      var body = jsonEncode(
          <String, dynamic>{
              "productDetails": cp.productDetails,
              "typeOfsales": cp.typeOfsales,
              "paymentType": cp.paymentType,
              "expectedDate": cp.expectedDate,
              "paid": cp.paid,
              "CustomerId": cp.CustomerId,
              "vat": cp.vat,
              "totalAmount": cp.totalAmount
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.post(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> searchProductRequest(String keywords) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Product/SearchProductByKeywords";
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
              "keywords": keywords
          }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getAllCategoriesRequest() async {
      print("insode http");
      String? token = await SharedPrefs.instance.retrieveString("token");
      print("the token");
      print(token);

      var url = baseUrl + "apis/v1/vicPharm/Inventory/GetCategories";
      print(url);
      var dio = Dio();
      try {
        
        dio.options.connectTimeout = 35000;
        Response response = await dio.get(
          url,
          options: Options(
              contentType: 'application/json',
              headers: {
                HttpHeaders.contentTypeHeader: 'application/json',
                HttpHeaders.acceptHeader: 'application/json',
                HttpHeaders.authorizationHeader: 'Bearer ' + token!
              }
          ),
        );
        print("this response");
        print(response.statusCode);
        print(response);
        print("");
        print("");
        print(response.data);
        return response;
      } on DioError catch (e) {
        return e.response != null ? e.response : null;
      }
  }

    Future<dynamic> addInventoryRequest(Inventory inv, String categoryId) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Inventory/AddInventory";
    Map<String, dynamic> mm = Map<String, dynamic>();
    mm['vial'] = 500.0;
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
            "name": inv.name,
            "barCode": inv.barCode,
            "description": inv.description,
            "sellingPrice": inv.sellingPrice,
            "costPrice": inv.costPrice,
            "quantity": inv.quantity,
            "unitOfMeasurement": inv.unitOfMeasurement,
            "discountUnit": inv.discountUnit,
            "discountType": inv.discountType,
            "discount":  inv.discount,
            "categoryId": categoryId,
            "shelfNumber": inv.shelfNumber,
            "inventoryTypes":"newstock",
            "expiryDate": inv.expiryDate,
            "reOrderLimit": inv.reOrderLimit,
            "limitPrice": inv.limitPrice
        }
      );
      print(body);
      
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.post(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> restockInventoryRequest(Inventory inv, String productId) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Inventory/AddInventory";
    Map<String, dynamic> mm = Map<String, dynamic>();
    mm['vial'] = 500.0;
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
            "costPrice": inv.costPrice,
            "quantity": inv.quantity,
            "productId": productId,
            "inventoryTypes":"restock",
            "expiryDate": inv.expiryDate,
        }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.post(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getSaleRecordRequest(int page) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Sales/GetSales?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getSaleRecordByDateRequest(String startDate, String endDate, int page) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Sales/GetSalesByDateRange?page=" + page.toString();

    var body = jsonEncode(
          <String, dynamic>{
            "startDate": startDate,
            "endDate": endDate
        }
      );

    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> exportSalesRecordRequest(String startDate, String endDate, String email) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Export/ExportSalesByDateRange";

    var body = jsonEncode(
          <String, dynamic>{
            "startDate": startDate,
            "endDate": endDate,
            "email": email
        }
      );

    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getCreditSaleRecordRequest(int page) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Sales/GetCreditSales?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getCreditSaleRecordByDateRequest(String startDate, String endDate, int page) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Sales/GetCreditSalesByDateRange?page=" + page.toString();

    var body = jsonEncode(
          <String, dynamic>{
            "startDate": startDate,
            "endDate": endDate
        }
      );

    print(url);
    print(body);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> payCreditSaleRequest(String debitId, double paid) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Sales/PayCreditSales";

    var body = jsonEncode(
          <String, dynamic>{
            "DebitId": debitId,
            "paid": paid
        }
      );

    print(url);
    print(body);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getSaleByIDRequest(String receiptId) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Sales/GetSalesByReceiptId";

    var body = jsonEncode(
          <String, dynamic>{
            "receiptId": receiptId
        }
      );

    print(url);
    print(body);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> returnProductRequest(ReturnProductRequest rrp) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Product/ReturnProduct";

    var body = jsonEncode(
          <String, dynamic>{
    "salesId": rrp.salesId,
    "productId": rrp.productId,
    "quantity": rrp.quantity,
    "productUniqueId": rrp.productUniqueId,
    "returnType": rrp.returnType,
    "amountReturn": rrp.amountReturn,
    "comment": rrp.comment,
    "reduceTheAmountOwning": rrp.reduceTheAmountOwning
} 
      );

    print(url);
    print(body);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getReturnProductRequest(int page) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Product/GetReturnProduct?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getExpiryProductsRequest(int page) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Product/GetExpiredProduct?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> expiryProductRequest(String comments, String productId, Map<String, dynamic> mapQty) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Product/ExpiredProduct";

    var body = jsonEncode(
          <String, dynamic>{
              "comments": comments,
              "productId": productId,
              "quantity": mapQty
          }
      );

    print(url);
    print(body);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.post(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getMiscEventsRequest(int page) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Miscellaneous/GetMiscellaneous?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> createMiscEventRequest(String comments, List<Map<String, dynamic>> mapQtys) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Miscellaneous/AddMiscellaneous";

    var body = jsonEncode(
          <String, dynamic>{
              "comments": comments,
              "productDetails": mapQtys
          }
      );

    print(url);
    print(body);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.post(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> addCategoryRequest(String name) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Inventory/AddCategory";
    Map<String, dynamic> mm = Map<String, dynamic>();
    mm['vial'] = 500.0;
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
            "name": name
        }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.post(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> addSubCategoryRequest(String name, String categoryId) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Inventory/AddSubCategoy";
    Map<String, dynamic> mm = Map<String, dynamic>();
    mm['vial'] = 500.0;
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
            "name": name,
            "categoryId": categoryId
        }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.post(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getDashboardDataRequest() async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Account/BasicSalesInfo";
    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.get(
        url,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getStaffSaleRecordRequest(int page, String staffId) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Sales/GetStaffSales?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      var body = jsonEncode(
          <String, dynamic>{
            "staffId": staffId
          }
      );
      print(body);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getStaffInventoryRecordRequest(int page, String staffId) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Inventory/GetStaffInventory?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      var body = jsonEncode(
          <String, dynamic>{
            "staffId": staffId
          }
      );
      print(body);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getStaffReturnRecordRequest(int page, String staffId) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Product/GetStaffReturnProduct?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      var body = jsonEncode(
          <String, dynamic>{
            "staffId": staffId
          }
      );
      print(body);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getStaffMiscRecordRequest(int page, String staffId) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Miscellaneous/GetStaffMiscellaneous?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {
      var body = jsonEncode(
          <String, dynamic>{
            "staffId": staffId
          }
      );
      print(body);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> getStaffExpiryProductsRequest(int page, String staffId) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Product/GetStaffExpiryProduct?page=" + page.toString();
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
            "staffId": staffId
          }
      );
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    
    Future<dynamic> EditProductRequest(Inventory inv, String productId) async {
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("insode http");
    var url = baseUrl + "apis/v1/vicPharm/Product/UpdateProduct";
    Map<String, dynamic> mm = Map<String, dynamic>();
    mm['vial'] = 500.0;
    print(url);
    var dio = Dio();
    try {

      var body = jsonEncode(
          <String, dynamic>{
            "name": inv.name,
            "description": inv.description,
            "sellingPrice": inv.sellingPrice,
            "unitOfMeasurement": inv.unitOfMeasurement,
            "discountUnit": inv.discountUnit,
            "discountType": inv.discountType,
            "discount":  inv.discount,
            "productId": productId,
            "reOrderLimit": inv.reOrderLimit,
            "limitPrice": mm
        }
      );
      print(body);
      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: ' application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> balanceSheetByDateRequest(String startDate, String endDate) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Account/GetBalanceSheetByDateRange";

    var body = jsonEncode(
          <String, dynamic>{
            "startDate": startDate,
            "endDate": endDate
        }
      );

    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> startResetPasswordRequest(String phoneNumber) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Staff/RestPassword";

    var body = jsonEncode(
          <String, dynamic>{
            "phoneNumber": phoneNumber
        }
      );

    print(url);
    print(body);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

    Future<dynamic> resetPasswordRequest(String phoneNumber, String password, String activationCode) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Staff/ConfirmRestPassword";

    var body = jsonEncode(
          <String, dynamic>{
              "phoneNumber": phoneNumber,
              "password": password,
              "activationCode": activationCode
          }
        );

    print(url);
    print(body);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

   
  Future<dynamic> updateStaffProfileRequest(Profile profile, PickedFile image) async{
     String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    Map<String, String> headers = {
      HttpHeaders.acceptHeader: 'application/json',
      HttpHeaders.contentTypeHeader: 'application/json',
      HttpHeaders.authorizationHeader: 'Bearer ' + token!
    };

    print(headers);

    print("inside hhtp request");


    var url = baseUrl + "apis/v1/vicPharm/Staff/UpdateStaffProfile";

    print(url);

    var dio = Dio();

    try{
      //return await http.put(url, headers: headers, body: body)
      //dio.options.contentType= Headers.formUrlEncodedContentType;
      dio.options.headers = {
        HttpHeaders.acceptHeader: ' application/multipart/form-data',
        HttpHeaders.contentTypeHeader: ' application/multipart/form-data',
        HttpHeaders.authorizationHeader: 'Bearer ' + token
      };

      FormData formdata;

      if(image != null){
        formdata = new FormData.fromMap({
          'age': profile.personalInfo!.age,
          'phoneNumber': profile.personalInfo!.phoneNumber,
          'email': profile.personalInfo!.email,
          'firstName': profile.personalInfo!.firstName,
          'lastName': profile.personalInfo!.lastName,
          'gender': profile.personalInfo!.gender,
          'address': profile.personalInfo!.address,
          'image': await MultipartFile.fromFile(image.path, filename: "${DateTime.now().millisecondsSinceEpoch}.png", contentType: MediaType("image", "png"))
        });
      }else{
        formdata = new FormData.fromMap({
          'age': profile.personalInfo!.age,
          'phoneNumber': profile.personalInfo!.phoneNumber,
          'email': profile.personalInfo!.email,
          'firstName': profile.personalInfo!.firstName,
          'lastName': profile.personalInfo!.lastName,
          'gender': profile.personalInfo!.gender,
          'address': profile.personalInfo!.address,
          
        });
      }
      
      print(formdata.fields);
      print(formdata.files);

      //print(image.path);
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        //"/upload",
        url,
        data: formdata,
        options: Options(contentType: 'multipart/form-data',
          headers: {

            HttpHeaders.authorizationHeader: 'Bearer ' + token
          }
        ),

        onSendProgress: (received, total) {
          if (total != -1) {
            print((received / total * 100).toStringAsFixed(0) + "%");
          }
        },
      );
      print("this response");
      print(response.data);
      print(response.statusCode);

      return response;
    }on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }

   Future<dynamic> getAllExpiryInventoryRequest() async {
      print("insode http");
      String? token = await SharedPrefs.instance.retrieveString("token");
      print("the token");
      print(token);

      var url = baseUrl + "apis/v1/vicPharm/Inventory/ExpiryInventoryInfo";
      print(url);
      var dio = Dio();
      try {
        
        dio.options.connectTimeout = 35000;
        Response response = await dio.get(
          url,
          options: Options(
              contentType: 'application/json',
              headers: {
                HttpHeaders.contentTypeHeader: 'application/json',
                HttpHeaders.acceptHeader: 'application/json',
                HttpHeaders.authorizationHeader: 'Bearer ' + token!
              }
          ),
        );
        print("this response");
        print(response.statusCode);
        print(response);
        print("");
        print("");
        print(response.data);
        return response;
      } on DioError catch (e) {
        return e.response != null ? e.response : null;
      }
  }

  Future<dynamic> soldOutRequest(String inventoryId) async {
    print("insode http");
    String? token = await SharedPrefs.instance.retrieveString("token");
    print("the token");
    print(token);

    var url = baseUrl + "apis/v1/vicPharm/Inventory/InventorySoldOut";

    var body = jsonEncode(
          <String, dynamic>{
              "inventoryId": inventoryId,
          }
        );

    print(url);
    var dio = Dio();
    try {
      
      dio.options.connectTimeout = 35000;
      Response response = await dio.put(
        url,
        data: body,
        options: Options(
            contentType: 'application/json',
            headers: {
              HttpHeaders.contentTypeHeader: 'application/json',
              HttpHeaders.acceptHeader: 'application/json',
              HttpHeaders.authorizationHeader: 'Bearer ' + token!
            }
        ),
      );
      print("this response");
      print(response.statusCode);
      print(response);
      print("");
      print("");
      print(response.data);
      return response;
    } on DioError catch (e) {
      return e.response != null ? e.response : null;
    }
  }



}

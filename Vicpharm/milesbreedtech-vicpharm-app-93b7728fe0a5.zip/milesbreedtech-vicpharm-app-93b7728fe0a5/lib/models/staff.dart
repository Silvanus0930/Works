class Staff {
  bool? active;
  bool? superAdmin;
  String? sId;
  PersonalInfo? personalInfo;
  String? phoneNumber;
  String? updatedAt;
  int? iV;
  PositionId? positionId;

  Staff(
      {this.active,
      this.superAdmin,
      this.sId,
      this.personalInfo,
      this.phoneNumber,
      this.updatedAt,
      this.iV,
      this.positionId});

  Staff.fromJson(Map<String, dynamic> json) {
    active = json['active'];
    superAdmin = json['superAdmin'];
    sId = json['_id'];
    personalInfo = json['personalInfo'] != null
        ? new PersonalInfo.fromJson(json['personalInfo'])
        : null;
    phoneNumber = json['phoneNumber'];
    updatedAt = json['updatedAt'];
    iV = json['__v'];
    positionId = json['positionId'] != null
        ? new PositionId.fromJson(json['positionId'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['active'] = this.active;
    data['superAdmin'] = this.superAdmin;
    data['_id'] = this.sId;
    if (this.personalInfo != null) {
      data['personalInfo'] = this.personalInfo!.toJson();
    }
    data['phoneNumber'] = this.phoneNumber;
    data['updatedAt'] = this.updatedAt;
    data['__v'] = this.iV;
    if (this.positionId != null) {
      data['positionId'] = this.positionId!.toJson();
    }
    return data;
  }
}

class PersonalInfo {
  String? firstName;
  String? lastName;
  String? email;
  String? address;
  String? gender;
  String? age;
  String? phoneNumber;

  PersonalInfo(
      {this.firstName,
      this.lastName,
      this.email,
      this.address,
      this.gender,
      this.age,
      this.phoneNumber});

  PersonalInfo.fromJson(Map<String, dynamic> json) {
    firstName = json['firstName'] != null ? json['firstName'] : "";
    lastName = json['lastName'] != null ? json['lastName'] : "";
    email = json['email'] != null ? json['email'] : "";
    address = json['address'] != null ? json['address'] : "";
    gender = json['gender'] != null ? json['gender'] : "";
    age = json['age'] != null ? json['age'] : "";
    phoneNumber = json['phoneNumber'] != null ? json['phoneNumber'] : "";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['email'] = this.email;
    data['address'] = this.address;
    data['gender'] = this.gender;
    data['age'] = this.age;
    data['phoneNumber'] = this.phoneNumber;
    return data;
  }
}

class PositionId {
  String? sId;
  String? positionName;

  PositionId({this.sId, this.positionName});

  PositionId.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    positionName = json['positionName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['positionName'] = this.positionName;
    return data;
  }
}
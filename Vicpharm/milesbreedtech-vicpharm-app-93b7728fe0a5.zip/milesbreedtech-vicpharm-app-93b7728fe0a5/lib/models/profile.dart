class Profile {
  String? sId;
  PersonalInfo? personalInfo;
  bool? superAdmin;

  Profile({this.sId, this.personalInfo, this.superAdmin});

  Profile.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    personalInfo = json['personalInfo'] != null
        ? new PersonalInfo.fromJson(json['personalInfo'])
        : null;
    superAdmin = json['superAdmin'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    if (this.personalInfo != null) {
      data['personalInfo'] = this.personalInfo!.toJson();
    }
    data['superAdmin'] = this.superAdmin;
    return data;
  }
}

class PersonalInfo {
  String? firstName;
  String? lastName;
  String? email;
  String? address;
  String? gender;
  String? age;
  String? profileImage;
  String? phoneNumber;

  PersonalInfo(
      {this.firstName,
      this.lastName,
      this.email,
      this.address,
      this.gender,
      this.age,
      this.profileImage,
      this.phoneNumber});

  PersonalInfo.fromJson(Map<String, dynamic> json) {
    firstName = json['firstName'];
    lastName = json['lastName'];
    email = json['email'];
    address = json['address'];
    gender = json['gender'];
    age = json['age'];
    profileImage = json['profileImage'];
    phoneNumber = json['phoneNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['email'] = this.email;
    data['address'] = this.address;
    data['gender'] = this.gender;
    data['age'] = this.age;
    data['profileImage'] = this.profileImage;
    data['phoneNumber'] = this.phoneNumber;
    return data;
  }
}
class ManagerPosition {
  List<String>? roles;
  String? sId;
  String? positionName;

  ManagerPosition({this.roles, this.sId, this.positionName});

  ManagerPosition.fromJson(Map<String, dynamic> json) {
    roles = json['roles'].cast<String>();
    sId = json['_id'];
    positionName = json['positionName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['roles'] = this.roles;
    data['_id'] = this.sId;
    data['positionName'] = this.positionName;
    return data;
  }
}
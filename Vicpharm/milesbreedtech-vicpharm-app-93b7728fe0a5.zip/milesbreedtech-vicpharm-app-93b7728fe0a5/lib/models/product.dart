import 'package:vicpharm_app/models/category.dart';

class Product {
  List<String>? unitOfMeasurement;
  List<String>? barCode;
  List<Category>? category;
  String? sId;
  String? name;
  String? description;
  bool? status;
  Map<String, dynamic>? limitPrice;
  Map<String, dynamic>? sellingPrice;
  Map<String, dynamic>? costPrice;
  Map<String, dynamic>? quantity;
  Map<String, dynamic>? sellQuantity = Map<String, dynamic>();
  String? expiryDate;
  Map<String, dynamic>? discountUnit;
  Map<String, dynamic>? discountType;
  Map<String, dynamic>? discount;
  Map<String, dynamic>? reOrderLimit;
  double? totalSellingPrice;
  double? totalLimitPrice;
  String? createdAt;

  Product(
      {this.unitOfMeasurement,
      this.status,
      this.barCode,
      this.totalLimitPrice = 0.0,
      this.sId,
      this.category,
      this.totalSellingPrice = 0.0,
      this.sellQuantity,
      this.name,
      this.description,
      this.limitPrice,
      this.sellingPrice,
      this.costPrice,
      this.quantity,
      this.expiryDate,
      this.discountUnit,
      this.discountType,
      this.discount,
      this.reOrderLimit,
      this.createdAt,});

}
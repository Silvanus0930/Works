import 'package:vicpharm_app/models/salerecord.dart';

class ExpiryProduct {
  String? sId;
  StaffId? staffId;
  ProductId? productId;
  Map<String, dynamic>? quantity;
  String? comment;
  String? expiedDate;
  String? createdAt;

  ExpiryProduct(
      {this.sId,
      this.staffId,
      this.productId,
      this.quantity,
      this.comment,
      this.expiedDate,
      this.createdAt});

  
}

class ProductId {
  String? sId;
  String? name;

  ProductId({this.sId, this.name});

  ProductId.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['name'] = this.name;
    return data;
  }
}


import 'package:vicpharm_app/models/category.dart';

class Inventory {
  List<String>? unitOfMeasurement;
  List<String>? barCode;
  List<Category>? category;
  String? sId;
  String? name;
  String? description;
  String? shelfNumber;
  Map<String, dynamic>? limitPrice;
  Map<String, dynamic>? sellingPrice;
  Map<String, dynamic>? costPrice;
  Map<String, dynamic>? quantity;
  int? previousQuantity;
  String? expiryDate;
  bool? soldOut;
  Map<String, dynamic>? availableQuantity;
  Map<String, dynamic>? discountUnit;
  Map<String, dynamic>? discountType;
  Map<String, dynamic>? discount;
  StaffId? staffId;
  String? inventoryTypes;
  Map<String, dynamic>? reOrderLimit;
  String? createdAt;
  String? updatedAt;
  int? iV;

  Inventory(
      {this.unitOfMeasurement,
      this.barCode,
      this.sId,
      this.category,
      this.name,
      this.soldOut,
      this.description,
      this.limitPrice,
      this.sellingPrice,
      this.costPrice,
      this.shelfNumber,
      this.quantity,
      this.previousQuantity,
      this.expiryDate,
      this.availableQuantity,
      this.discountUnit,
      this.discountType,
      this.discount,
      this.staffId,
      this.inventoryTypes,
      this.reOrderLimit,
      this.createdAt,
      this.updatedAt,
      this.iV});

  
}


class StaffId {
  bool? active;
  bool? superAdmin;
  String? sId;
  PersonalInfo? personalInfo;
  String? phoneNumber;
  String? positionId;

  StaffId(
      {this.active,
      this.superAdmin,
      this.sId,
      this.personalInfo,
      this.phoneNumber,
      this.positionId});

  StaffId.fromJson(Map<String, dynamic> json) {
    active = json['active'];
    superAdmin = json['superAdmin'];
    sId = json['_id'];
    personalInfo = json['personalInfo'] != null
        ? new PersonalInfo.fromJson(json['personalInfo'])
        : null;
    phoneNumber = json['phoneNumber'];
    positionId = json['positionId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['active'] = this.active;
    data['superAdmin'] = this.superAdmin;
    data['_id'] = this.sId;
    if (this.personalInfo != null) {
      data['personalInfo'] = this.personalInfo!.toJson();
    }
    data['phoneNumber'] = this.phoneNumber;
    data['positionId'] = this.positionId;
    return data;
  }
}

class PersonalInfo {
  String? firstName;
  String? lastName;
  String? email;
  String? address;
  String? gender;
  String? age;
  String? phoneNumber;

  PersonalInfo(
      {this.firstName,
      this.lastName,
      this.email,
      this.address,
      this.gender,
      this.age,
      this.phoneNumber});

  PersonalInfo.fromJson(Map<String, dynamic> json) {
    firstName = json['firstName'];
    lastName = json['lastName'];
    email = json['email'];
    address = json['address'];
    gender = json['gender'];
    age = json['age'];
    phoneNumber = json['phoneNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['email'] = this.email;
    data['address'] = this.address;
    data['gender'] = this.gender;
    data['age'] = this.age;
    data['phoneNumber'] = this.phoneNumber;
    return data;
  }
}
import 'package:vicpharm_app/models/salerecord.dart';

class Misc {
  String? sId;
  StaffId? staffId;
  List<ProductDetails>? productDetails;
  String? comments;
  double? totalAmount;
  String? createdAt;

  Misc(
      {this.sId,
      this.staffId,
      this.productDetails,
      this.comments,
      this.totalAmount,
      this.createdAt});


}


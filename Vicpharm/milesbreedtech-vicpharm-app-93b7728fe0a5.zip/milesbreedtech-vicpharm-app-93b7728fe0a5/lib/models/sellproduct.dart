class SellProduct {
  List<Map>? productDetails;
  String? typeOfsales;
  String? paymentType;
  String? expectedDate;
  int? paid;
  String? customerId;

  SellProduct(
      {this.productDetails,
      this.typeOfsales,
      this.paymentType,
      this.expectedDate,
      this.paid,
      this.customerId});

}
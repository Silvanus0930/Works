class CreditSalerecord {
  List<ProductDetailsC>? productDetails;
  List<Paid>? paid;
  bool? active;
  String? sId;
  StaffIdC? staffId;
  double? totalAmount;
  String? salesId;
  String? expectedDate;
  double? remainingAmount;
  CustomerIdC? customerId;
  String? createdAt;

  CreditSalerecord(
      {this.productDetails,
      this.paid,
      this.active,
      this.sId,
      this.staffId,
      this.totalAmount,
      this.salesId,
      this.expectedDate,
      this.remainingAmount,
      this.customerId,
      this.createdAt});

}

class ProductDetailsC {
  String? id;
  Map<String, dynamic>? quantity;
  Map<String, dynamic>? sellingPrice;
  double? totalAmount;
  String? productName;

  ProductDetailsC(
      {this.id,
      this.quantity,
      this.sellingPrice,
      this.totalAmount,
      this.productName});

  
}



class Paid {
  double? amount;
  String? date;
  String? salesRep;

  Paid({this.amount, this.date, this.salesRep});

  Paid.fromJson(Map<String, dynamic> json) {
    amount = json['amount'].toDouble();
    date = json['Date'];
    salesRep = json['salesRep'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['amount'] = this.amount;
    data['Date'] = this.date;
    data['salesRep'] = this.salesRep;
    return data;
  }
}

class StaffIdC {
  bool? active;
  bool? superAdmin;
  String? sId;
  PersonalInfo? personalInfo;
  String? phoneNumber;

  StaffIdC(
      {this.active,
      this.superAdmin,
      this.sId,
      this.personalInfo,
      this.phoneNumber});

  StaffIdC.fromJson(Map<String, dynamic> json) {
    active = json['active'];
    superAdmin = json['superAdmin'];
    sId = json['_id'];
    personalInfo = json['personalInfo'] != null
        ? new PersonalInfo.fromJson(json['personalInfo'])
        : null;
    phoneNumber = json['phoneNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['active'] = this.active;
    data['superAdmin'] = this.superAdmin;
    data['_id'] = this.sId;
    if (this.personalInfo != null) {
      data['personalInfo'] = this.personalInfo!.toJson();
    }
    data['phoneNumber'] = this.phoneNumber;
    return data;
  }
}

class PersonalInfo {
  String? firstName;
  String? lastName;
  String? email;
  String? address;
  String? phoneNumber;

  PersonalInfo(
      {this.firstName,
      this.lastName,
      this.email,
      this.address,
      this.phoneNumber});

  PersonalInfo.fromJson(Map<String, dynamic> json) {
    firstName = json['firstName'];
    lastName = json['lastName'];
    email = json['email'];
    address = json['address'];
    phoneNumber = json['phoneNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['email'] = this.email;
    data['address'] = this.address;
    data['phoneNumber'] = this.phoneNumber;
    return data;
  }
}

class CustomerIdC {
  bool? retailer;
  String? sId;
  PersonalInfoC? personalInfo;
  String? fullName;
  String? phoneNumber;

  CustomerIdC(
      {this.retailer,
      this.sId,
      this.personalInfo,
      this.fullName,
      this.phoneNumber});

  CustomerIdC.fromJson(Map<String, dynamic> json) {
    retailer = json['retailer'];
    sId = json['_id'];
    personalInfo = json['personalInfo'] != null
        ? new PersonalInfoC.fromJson(json['personalInfo'])
        : null;
    fullName = json['fullName'];
    phoneNumber = json['phoneNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['retailer'] = this.retailer;
    data['_id'] = this.sId;
    if (this.personalInfo != null) {
      data['personalInfo'] = this.personalInfo!.toJson();
    }
    data['fullName'] = this.fullName;
    data['phoneNumber'] = this.phoneNumber;
    return data;
  }
}

class PersonalInfoC {
  String? fullName;
  String? email;
  String? address;
  String? phoneNumber;
  String? gender;
  String? age;

  PersonalInfoC(
      {this.fullName,
      this.email,
      this.address,
      this.phoneNumber,
      this.gender,
      this.age});

  PersonalInfoC.fromJson(Map<String, dynamic> json) {
    fullName = json['fullName'];
    email = json['email'];
    address = json['address'];
    phoneNumber = json['phoneNumber'];
    gender = json['gender'];
    age = json['age'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['fullName'] = this.fullName;
    data['email'] = this.email;
    data['address'] = this.address;
    data['phoneNumber'] = this.phoneNumber;
    data['gender'] = this.gender;
    data['age'] = this.age;
    return data;
  }
}
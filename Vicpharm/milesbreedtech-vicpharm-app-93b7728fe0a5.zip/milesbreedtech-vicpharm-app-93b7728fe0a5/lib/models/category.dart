class Category {
  List<SubCategories>? subCategories;
  String? sId;
  String? name;
  List<Productx>? product;

  Category({this.subCategories, this.sId, this.name, this.product});

  Category.fromJson(Map<String, dynamic> json) {
    if (json['product'] != null) {
      product = [];
      json['product'].forEach((v) {
        product!.add(new Productx.fromJson(v));
      });
    }
    if (json['subCategories'] != null) {
      subCategories = [];
      json['subCategories'].forEach((v) {
        subCategories!.add(new SubCategories.fromJson(v));
      });
    }
    sId = json['_id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
     if (this.product != null) {
      data['product'] = this.product!.map((v) => v.toJson()).toList();
    }
    if (this.subCategories != null) {
      data['subCategories'] =
          this.subCategories!.map((v) => v.toJson()).toList();
    }
    data['_id'] = this.sId;
    data['name'] = this.name;
    return data;
  }
}

class Productx {
  String? sId;
  String? name;

  Productx({this.sId, this.name});

  Productx.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['name'] = this.name;
    return data;
  }
}

class SubCategories {
  String? sId;
  String? name;

  SubCategories({this.sId, this.name});

  SubCategories.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['name'] = this.name;
    return data;
  }
}
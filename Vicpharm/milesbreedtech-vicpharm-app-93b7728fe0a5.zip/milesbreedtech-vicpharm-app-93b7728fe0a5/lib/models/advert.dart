class Advert {
  String? sId;
  String? advert;

  Advert({this.sId, this.advert});

  Advert.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    advert = json['advert'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['advert'] = this.advert;
    return data;
  }
}
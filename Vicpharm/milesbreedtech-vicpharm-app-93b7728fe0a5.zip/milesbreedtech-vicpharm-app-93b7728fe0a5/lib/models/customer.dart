class Customer {
  bool? retailer;
  String? sId;
  String? staffId;
  PersonalInfo? personalInfo;
  String? fullName;
  String? phoneNumber;
  String? createdAt;
  String? updatedAt;
  int? iV;

  Customer(
      {this.retailer,
      this.sId,
      this.staffId,
      this.personalInfo,
      this.fullName,
      this.phoneNumber,
      this.createdAt,
      this.updatedAt,
      this.iV});

  Customer.fromJson(Map<String, dynamic> json) {
    retailer = json['retailer'];
    sId = json['_id'];
    staffId = json['staffId'];
    personalInfo = json['personalInfo'] != null
        ? new PersonalInfo.fromJson(json['personalInfo'])
        : null;
    fullName = json['fullName'];
    phoneNumber = json['phoneNumber'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    iV = json['__v'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['retailer'] = this.retailer;
    data['_id'] = this.sId;
    data['staffId'] = this.staffId;
    if (this.personalInfo != null) {
      data['personalInfo'] = this.personalInfo!.toJson();
    }
    data['fullName'] = this.fullName;
    data['phoneNumber'] = this.phoneNumber;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    data['__v'] = this.iV;
    return data;
  }
}

class PersonalInfo {
  String? fullName;
  String? email;
  String? address;
  String? phoneNumber;
  String? gender;
  String? age;

  PersonalInfo(
      {this.fullName,
      this.email,
      this.address,
      this.phoneNumber,
      this.gender,
      this.age});

  PersonalInfo.fromJson(Map<String, dynamic> json) {
    fullName = json['fullName'] != null ? json['fullName'] : "";
    email = json['email'] != null ? json['email'] : "";
    address = json['address'] != null ? json['address'] : "";
    phoneNumber = json['phoneNumber'] != null ? json['phoneNumber'] : "";
    gender = json['gender'] != null ? json['gender'] : "";
    age = json['age'] != null ? json['age'] : "";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['fullName'] = this.fullName;
    data['email'] = this.email;
    data['address'] = this.address;
    data['phoneNumber'] = this.phoneNumber;
    data['gender'] = this.gender;
    data['age'] = this.age;
    return data;
  }
}
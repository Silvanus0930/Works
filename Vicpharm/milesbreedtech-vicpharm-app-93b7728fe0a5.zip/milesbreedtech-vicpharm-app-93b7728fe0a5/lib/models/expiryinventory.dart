class ExpiryInventory {
  String? sId;
  String? name;
  String? expiryDate;

  ExpiryInventory({this.sId, this.name, this.expiryDate});

  ExpiryInventory.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
    expiryDate = json['expiryDate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['name'] = this.name;
    data['expiryDate'] = this.expiryDate;
    return data;
  }
}
class OnlineOrder {
  bool? prescriptionProduct;
  bool? prescriptionProductApprove;
  bool? customerConfirmDelivery;
  List<ProductDetails>? productDetails;
  bool? storeApproval;
  bool? itemPacked;
  bool? dispatcherApproval;
  bool? pickup;
  bool? deliveryCompleted;
  bool? storePickUp;
  String? paymentStatus;
  String? fulfil;
  String? status;
  String? itemStatus;
  bool? issues;
  double? paymentOnDeliveryFee;
  List<String>? comment;
  bool? active;
  String? sId;
  String? invoiceId;
  double? totalAmount;
  DeliveryLocation? deliveryLocation;
  ContactPerson? contactPerson;
  double? shippingFee;
  String? distance;
  double? vat;
  double? vatPercent;
  double? discount;
  double? subTotalAmount;
  String? store;
  String? createdAt;
  String? prescriptionUri;
  String? customerId;
  String? paymentReference;

  OnlineOrder(
      {this.prescriptionProduct,
        this.prescriptionProductApprove,
        this.customerConfirmDelivery,
        this.productDetails,
        this.storeApproval,
        this.itemPacked,
        this.dispatcherApproval,
        this.pickup,
        this.deliveryCompleted,
        this.storePickUp,
        this.paymentStatus,
        this.fulfil,
        this.status,
        this.itemStatus,
        this.issues,
        this.paymentOnDeliveryFee,
        this.comment,
        this.active,
        this.sId,
        this.invoiceId,
        this.totalAmount,
        this.deliveryLocation,
        this.contactPerson,
        this.shippingFee,
        this.distance,
        this.vat,
        this.vatPercent,
        this.discount,
        this.subTotalAmount,
        this.store,
        this.createdAt,
        this.prescriptionUri,
        this.customerId,
        this.paymentReference});

  OnlineOrder.fromJson(Map<String, dynamic> json) {
    prescriptionProduct = json['prescriptionProduct'];
    prescriptionProductApprove = json['prescriptionProductApprove'];
    customerConfirmDelivery = json['customerConfirmDelivery'];
    if (json['productDetails'] != null) {
      productDetails = [];
      json['productDetails'].forEach((v) {
        productDetails!.add(new ProductDetails.fromJson(v));
      });
    }
    storeApproval = json['storeApproval'];
    itemPacked = json['itemPacked'];
    dispatcherApproval = json['dispatcherApproval'];
    pickup = json['pickup'];
    deliveryCompleted = json['deliveryCompleted'];
    storePickUp = json['storePickUp'];
    paymentStatus = json['paymentStatus'];
    fulfil = json['fulfil'];
    status = json['Status'];
    itemStatus = json['itemStatus'];
    issues = json['issues'];
    paymentOnDeliveryFee = json['PaymentOnDeliveryFee'] != null ? json['PaymentOnDeliveryFee'].toDouble() : 0.0;
    comment = json['comment'].cast<String>();
    active = json['active'];
    sId = json['_id'];
    invoiceId = json['invoiceId'];
    totalAmount = json['totalAmount'] != null ? json['totalAmount'].toDouble() : 0.0;
    deliveryLocation = json['deliveryLocation'] != null
        ? new DeliveryLocation.fromJson(json['deliveryLocation'])
        : null;
    contactPerson = json['contactPerson'] != null
        ? new ContactPerson.fromJson(json['contactPerson'])
        : null;
    shippingFee = json['shippingFee'] != null ? json['shippingFee'].toDouble() : 0.0;
    distance = json['distance'];
    vat = json['vat'] != null ? json['vat'].toDouble() : 0.0;
    vatPercent = json['vatPercent'] != null ? json['vatPercent'].toDouble() : 0.0;
    discount = json['discount'] != null ? json['discount'].toDouble() : 0.0;
    subTotalAmount = json['subTotalAmount'] != null ?  json['subTotalAmount'].toDouble() : 0.0;
    store = json['store'];
    createdAt = json['createdAt'];
    prescriptionUri = json['prescriptionUri'];
    customerId = json['customerId'];
    paymentReference = json['paymentReference'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['prescriptionProduct'] = this.prescriptionProduct;
    data['prescriptionProductApprove'] = this.prescriptionProductApprove;
    data['customerConfirmDelivery'] = this.customerConfirmDelivery;
    if (this.productDetails != null) {
      data['productDetails'] =
          this.productDetails!.map((v) => v.toJson()).toList();
    }
    data['storeApproval'] = this.storeApproval;
    data['itemPacked'] = this.itemPacked;
    data['dispatcherApproval'] = this.dispatcherApproval;
    data['pickup'] = this.pickup;
    data['deliveryCompleted'] = this.deliveryCompleted;
    data['storePickUp'] = this.storePickUp;
    data['paymentStatus'] = this.paymentStatus;
    data['fulfil'] = this.fulfil;
    data['Status'] = this.status;
    data['itemStatus'] = this.itemStatus;
    data['issues'] = this.issues;
    data['PaymentOnDeliveryFee'] = this.paymentOnDeliveryFee;
    data['comment'] = this.comment;
    data['active'] = this.active;
    data['_id'] = this.sId;
    data['invoiceId'] = this.invoiceId;
    data['totalAmount'] = this.totalAmount;
    if (this.deliveryLocation != null) {
      data['deliveryLocation'] = this.deliveryLocation!.toJson();
    }
    if (this.contactPerson != null) {
      data['contactPerson'] = this.contactPerson!.toJson();
    }
    data['shippingFee'] = this.shippingFee;
    data['distance'] = this.distance;
    data['vat'] = this.vat;
    data['vatPercent'] = this.vatPercent;
    data['discount'] = this.discount;
    data['subTotalAmount'] = this.subTotalAmount;
    data['store'] = this.store;
    data['createdAt'] = this.createdAt;
    data['prescriptionUri'] = this.prescriptionUri;
    data['customerId'] = this.customerId;
    data['paymentReference'] = this.paymentReference;
    return data;
  }
}

class ProductDetails {
  String? name;
  double? discount;
  String? imageurl;
  int? quantity;
  String? unitOfMeasurement;
  double? sellingPrice;
  double? totalAmount;
  double? subTotalAmount;
  String? sId;

  ProductDetails(
      {this.name,
        this.discount,
        this.imageurl,
        this.quantity,
        this.unitOfMeasurement,
        this.sellingPrice,
        this.totalAmount,
        this.subTotalAmount,
        this.sId});

  ProductDetails.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    //discount = json['discount'] != null ? json['discount'].toDouble() : 0.0;
    imageurl = json['Imageurl'];
    quantity = json['quantity'];
    unitOfMeasurement = json['unitOfMeasurement'];
    sellingPrice = json['sellingPrice'] != null ? json['sellingPrice'].toDouble() : 0.0;
    totalAmount = json['totalAmount'] != null ? json['totalAmount'].toDouble() : 0.0;
    subTotalAmount = json['subTotalAmount'] != null ? json['subTotalAmount'].toDouble() : 0.0;
    sId = json['_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['discount'] = this.discount;
    data['Imageurl'] = this.imageurl;
    data['quantity'] = this.quantity;
    data['unitOfMeasurement'] = this.unitOfMeasurement;
    data['sellingPrice'] = this.sellingPrice;
    data['totalAmount'] = this.totalAmount;
    data['subTotalAmount'] = this.subTotalAmount;
    data['_id'] = this.sId;
    return data;
  }
}

class DeliveryLocation {
  String? country;
  String? state;
  String? street;
  String? formattedAddress;
  String? locationName;
  double? longitude;
  double? latitude;

  DeliveryLocation(
      {this.country,
        this.state,
        this.street,
        this.formattedAddress,
        this.locationName,
        this.longitude,
        this.latitude});

  DeliveryLocation.fromJson(Map<String, dynamic> json) {
    country = json['country'];
    state = json['state'];
    street = json['street'];
    formattedAddress = json['formatted_address'];
    locationName = json['locationName'];
    longitude = 0.0;
    if(json['longitude'].runtimeType == String){
      longitude = double.tryParse(json['longitude']);
    }else if(json['longitude'].runtimeType == int){
      longitude = json['longitude'].toDouble();
    }

    latitude = 0.0;
    if(json['latitude'].runtimeType == String){
      longitude = double.tryParse(json['latitude']);
    }else if(json['latitude'].runtimeType == int){
      longitude = json['latitude'].toDouble();
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['country'] = this.country;
    data['state'] = this.state;
    data['street'] = this.street;
    data['formatted_address'] = this.formattedAddress;
    data['locationName'] = this.locationName;
    data['longitude'] = this.longitude;
    data['latitude'] = this.latitude;
    return data;
  }
}

class ContactPerson {
  String? name;
  String? phoneNumber;

  ContactPerson({this.name, this.phoneNumber});

  ContactPerson.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    phoneNumber = json['phoneNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['phoneNumber'] = this.phoneNumber;
    return data;
  }
}
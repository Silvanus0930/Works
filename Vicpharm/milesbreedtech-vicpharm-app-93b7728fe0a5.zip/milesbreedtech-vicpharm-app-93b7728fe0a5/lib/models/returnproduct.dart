import 'package:vicpharm_app/models/salerecord.dart';

class ReturnProduct {
  List<ProductDetails>? productDetail;
  String? sId;
  String? salesId;
  String? comment;
  String? returnType;
  double? amountReturn;
  Map<String, dynamic>? returnQuantity;
  
  
  String? productId;
  StaffId? staffId;
  String? createdAt;

  ReturnProduct(
      {this.productDetail,
      this.sId,
      this.salesId,
      this.comment,
      this.returnType,
      this.amountReturn,
      this.returnQuantity,
      this.productId,
      this.staffId,
      this.createdAt});

 
}


  
class TopSelling {
  Map<String, dynamic>? quantity;
  Map<String, dynamic>? sellingPrice;
  double? totalSales;
  String? productName;

  TopSelling(
      {this.quantity, this.sellingPrice, this.totalSales, this.productName});

  
}

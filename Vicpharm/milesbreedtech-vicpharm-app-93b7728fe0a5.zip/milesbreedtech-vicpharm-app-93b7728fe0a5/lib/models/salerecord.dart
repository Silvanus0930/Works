class SaleRecord {
  List<ProductDetails>? productDetails;
  String? sId;
  String? receiptId;
  StaffId? staffId;
  String? typeOfsales;
  CustomerId? customerId;
  double? totalAmount;
  double? vat;
  String? createdAt;
  List<PaymentType>? paymentType;

  SaleRecord(
      {this.productDetails,
      this.sId,
      this.createdAt,
      this.paymentType,
      this.receiptId,
      this.staffId,
      this.typeOfsales,
      this.customerId,
      this.totalAmount,
      this.vat});

  SaleRecord.fromJson(Map<String, dynamic> json) {   
   
    sId = json['_id'];
    receiptId = json['receiptId'];
    staffId =
        json['staffId'] != null ? new StaffId.fromJson(json['staffId']) : null;
   
    typeOfsales = json['typeOfsales'];
    if (json['paymentType'] != null) {
      paymentType = [];
      json['paymentType'].forEach((v) {
        paymentType!.add(new PaymentType.fromJson(v));
      });
    }
    customerId = json['CustomerId'] != null
        ? new CustomerId.fromJson(json['CustomerId'])
        : null;
    totalAmount = json['totalAmount'];
    vat = json['vat'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();    
    
    data['_id'] = this.sId;
    data['receiptId'] = this.receiptId;
    if (this.staffId != null) {
      data['staffId'] = this.staffId!.toJson();
    }
    if (this.paymentType != null) {
      data['paymentType'] = this.paymentType!.map((v) => v.toJson()).toList();
    }
    data['typeOfsales'] = this.typeOfsales;
    if (this.customerId != null) {
      data['CustomerId'] = this.customerId!.toJson();
    }
    data['totalAmount'] = this.totalAmount;
    data['vat'] = this.vat;
    return data;
  }
}

class ProductDetails {
  String? id;
  Map<String, dynamic>? quantity;
  Map<String, dynamic>? sellingPrice;
  double? totalAmount;
  String? productName;
  

  ProductDetails(
      {this.id,
      this.quantity,
      this.sellingPrice,
      this.totalAmount,
      this.productName});

  
}


class StaffId {
  bool? active;
  bool? superAdmin;
  String? sId;
  PersonalInfo? personalInfo;
  String? phoneNumber;
  String? positionId;

  StaffId(
      {this.active,
      this.superAdmin,
      this.sId,
      this.personalInfo,
      this.phoneNumber,
      this.positionId});

  StaffId.fromJson(Map<String, dynamic> json) {
    active = json['active'];
    superAdmin = json['superAdmin'];
    sId = json['_id'];
    personalInfo = json['personalInfo'] != null
        ? new PersonalInfo.fromJson(json['personalInfo'])
        : null;
    phoneNumber = json['phoneNumber'];
    positionId = json['positionId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['active'] = this.active;
    data['superAdmin'] = this.superAdmin;
    data['_id'] = this.sId;
    if (this.personalInfo != null) {
      data['personalInfo'] = this.personalInfo!.toJson();
    }
    data['phoneNumber'] = this.phoneNumber;
    data['positionId'] = this.positionId;
    return data;
  }
}

class PersonalInfo {
  String? firstName;
  String? lastName;
  String? email;
  String? address;
  String? gender;
  String? age;
  String? phoneNumber;

  PersonalInfo(
      {this.firstName,
      this.lastName,
      this.email,
      this.address,
      this.gender,
      this.age,
      this.phoneNumber});

  PersonalInfo.fromJson(Map<String, dynamic> json) {
    firstName = json['firstName'];
    lastName = json['lastName'];
    email = json['email'];
    address = json['address'];
    gender = json['gender'];
    age = json['age'];
    phoneNumber = json['phoneNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['email'] = this.email;
    data['address'] = this.address;
    data['gender'] = this.gender;
    data['age'] = this.age;
    data['phoneNumber'] = this.phoneNumber;
    return data;
  }
}

class CustomerId {
  bool? retailer;
  String? sId;
  PersonalInfo? personalInfo;
  String? fullName;
  String? phoneNumber;

  CustomerId(
      {this.retailer,
      this.sId,
      this.personalInfo,
      this.fullName,
      this.phoneNumber});

  CustomerId.fromJson(Map<String, dynamic> json) {
    retailer = json['retailer'];
    sId = json['_id'];
    personalInfo = json['personalInfo'] != null
        ? new PersonalInfo.fromJson(json['personalInfo'])
        : null;
    fullName = json['fullName'];
    phoneNumber = json['phoneNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['retailer'] = this.retailer;
    data['_id'] = this.sId;
    if (this.personalInfo != null) {
      data['personalInfo'] = this.personalInfo!.toJson();
    }
    data['fullName'] = this.fullName;
    data['phoneNumber'] = this.phoneNumber;
    return data;
  }
}

class PaymentType {
  String? paymentType;
  double? amount;

  PaymentType({this.paymentType, this.amount});

  PaymentType.fromJson(Map<String, dynamic> json) {
    paymentType = json['paymentType'];
    amount = json['amount'].runtimeType == String ? double.tryParse(json['amount']) :json['amount'].toDouble();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['paymentType'] = this.paymentType;
    data['amount'] = this.amount;
    return data;
  }
}
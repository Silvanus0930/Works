class Activity {
  String? sId;
  StaffId? staffId;
  String? event;
  String? createdAt;

  Activity({this.sId, this.staffId, this.event, this.createdAt});

  Activity.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    staffId =
        json['staffId'] != null ? new StaffId.fromJson(json['staffId']) : null;
    event = json['event'];
    createdAt = json['createdAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    if (this.staffId != null) {
      data['staffId'] = this.staffId!.toJson();
    }
    data['event'] = this.event;
    data['createdAt'] = this.createdAt;
    return data;
  }
}

class StaffId {
  String? sId;
  PersonalInfo? personalInfo;
  String? phoneNumber;
  int? iV;

  StaffId({this.sId, this.personalInfo, this.phoneNumber, this.iV});

  StaffId.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    personalInfo = json['personalInfo'] != null
        ? new PersonalInfo.fromJson(json['personalInfo'])
        : null;
    phoneNumber = json['phoneNumber'];
    iV = json['__v'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    if (this.personalInfo != null) {
      data['personalInfo'] = this.personalInfo!.toJson();
    }
    data['phoneNumber'] = this.phoneNumber;
    data['__v'] = this.iV;
    return data;
  }
}

class PersonalInfo {
  String? firstName;
  String? lastName;
  String? email;
  String? address;
  String? phoneNumber;

  PersonalInfo(
      {this.firstName,
      this.lastName,
      this.email,
      this.address,
      this.phoneNumber});

  PersonalInfo.fromJson(Map<String, dynamic> json) {
    firstName = json['firstName'];
    lastName = json['lastName'];
    email = json['email'];
    address = json['address'];
    phoneNumber = json['phoneNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['email'] = this.email;
    data['address'] = this.address;
    data['phoneNumber'] = this.phoneNumber;
    return data;
  }
}
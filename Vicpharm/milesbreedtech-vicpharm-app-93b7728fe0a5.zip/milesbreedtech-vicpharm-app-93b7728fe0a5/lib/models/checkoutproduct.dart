class CheckoutProduct {
  List<ProductDetails>? productDetails;
  String? typeOfsales;
  String? paymentType;
  String? expectedDate;
  double? paid;
  String? CustomerId;
  String? cid;
  double? vat;
  double? totalAmount;

  CheckoutProduct({
    this.productDetails,
    this.totalAmount,
    this.typeOfsales,
    this.paymentType,
    this.vat,
    this.expectedDate = "",
    this.paid = 0,
    this.CustomerId,
    this.cid
  });
}


class ProductDetails {
  String? id;
  Map<String, dynamic>? quantity;
  Map<String, dynamic>? sellingPrice;
  double? totalAmount;
  //List<Map<String, String>>? productUniqueId;
  String? name;

  ProductDetails({
    this.id,
    this.quantity,
    this.sellingPrice,
    this.totalAmount,
   // this.productUniqueId,
    this.name
  });

  Map toJson() => {
        'id': id,
        'quantity': quantity,
        'sellingPrice': sellingPrice,
        'totalAmount': totalAmount,
       // 'quantity': quantity,
      };
}
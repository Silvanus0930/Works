class ReturnProductRequest {
  String? salesId;
  String? productId;
  Map<String, dynamic>? quantity;
  String? productUniqueId;
  String? returnType;
  double? amountReturn;
  String? comment;
  bool? reduceTheAmountOwning;

  ReturnProductRequest(
      {this.salesId,
      this.productId,
      this.quantity,
      this.productUniqueId,
      this.returnType,
      this.amountReturn,
      this.comment,
      this.reduceTheAmountOwning});

}



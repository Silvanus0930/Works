import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/services.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:rxdart/subjects.dart';

import 'package:vicpharm_app/screens/advert/advertprovider.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/auth/loginscreen.dart';
import 'package:vicpharm_app/screens/customer/customerprovider.dart';
import 'package:vicpharm_app/screens/expiration/expiryprovider.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/screens/landing/landingprovider.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/screens/misc/miscprovider.dart';
import 'package:vicpharm_app/screens/online/onlineprovider.dart';
import 'package:vicpharm_app/screens/return/returnprovider.dart';
import 'package:vicpharm_app/screens/sales/salesprovider.dart';
import 'package:vicpharm_app/screens/staff/staffprovider.dart';
import 'package:vicpharm_app/utils/dissmisskeyboard.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

final ThemeData kIOSTheme = new ThemeData(
    primarySwatch: materialMainColor,
    primaryColor: mainColor,
    primaryIconTheme: IconThemeData(color: Colors.white),
    primaryColorBrightness: Brightness.light,
    visualDensity: VisualDensity.adaptivePlatformDensity,
    fontFamily: 'PoppinsRegular'

);

final ThemeData kDefaultTheme = new ThemeData(
    primarySwatch: materialMainColor,
    primaryColor: mainColor,
    accentColor: mainColor,
    primaryIconTheme: IconThemeData(color: Colors.white),
    primaryColorBrightness: Brightness.dark,
    visualDensity: VisualDensity.adaptivePlatformDensity,
    fontFamily: 'PoppinsRegular'

);

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

/// Streams are created so that app can respond to notification-related events
/// since the plugin is initialised in the `main` function
final BehaviorSubject<ReceivedNotification> didReceiveLocalNotificationSubject =
    BehaviorSubject<ReceivedNotification>();

final BehaviorSubject<String?> selectNotificationSubject =
    BehaviorSubject<String?>();

const MethodChannel platform = MethodChannel('dexterx.dev/flutter_local_notifications_example');

class ReceivedNotification {
  ReceivedNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.payload,
  });

  final int id;
  final String? title;
  final String? body;
  final String? payload;
}

String? selectedNotificationPayload;

Future<NotificationAppLaunchDetails?> prepareNotification() async{
   final NotificationAppLaunchDetails? notificationAppLaunchDetails = await flutterLocalNotificationsPlugin.getNotificationAppLaunchDetails();

    //String initialRoute = HomePage.routeName;

    if (notificationAppLaunchDetails?.didNotificationLaunchApp ?? false) {
      selectedNotificationPayload = notificationAppLaunchDetails!.payload;
      //initialRoute = SecondPage.routeName;
    }

    const AndroidInitializationSettings initializationSettingsAndroid =   AndroidInitializationSettings('ic_launcher');

    /// Note: permissions aren't requested here just to demonstrate that can be
    /// done later
    final IOSInitializationSettings initializationSettingsIOS =
        IOSInitializationSettings(
            requestAlertPermission: false,
            requestBadgePermission: false,
            requestSoundPermission: false,
            onDidReceiveLocalNotification:
                (int id, String? title, String? body, String? payload) async {
              didReceiveLocalNotificationSubject.add(ReceivedNotification(
                  id: id, title: title, body: body, payload: payload));
            });

  
    final InitializationSettings initializationSettings = InitializationSettings(
        android: initializationSettingsAndroid,
        iOS: initializationSettingsIOS);

    await flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onSelectNotification: (String? payload) async {
      if (payload != null) {
        debugPrint('notification payload: $payload');
      }
      selectedNotificationPayload = payload;
      selectNotificationSubject.add(payload);
    });

   
    return notificationAppLaunchDetails;
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  configLoading();
     
  SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: mainColor,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light,
        systemNavigationBarColor: mainColor,
      )
  );
  runApp(
      MultiProvider(providers: [
        ChangeNotifierProvider(create: (context) => AuthProvider()),
        ChangeNotifierProvider(create: (context) => LandingProvider()),
        ChangeNotifierProvider(create: (context) => StaffProvider()), 
        ChangeNotifierProvider(create: (context) => AdvertProvider()),
        ChangeNotifierProvider(create: (context) => CustomerProvider()),  
        ChangeNotifierProvider(create: (context) => InventoryProvider()), 
        ChangeNotifierProvider(create: (context) => SalesProvider()),
        ChangeNotifierProvider(create: (context) => ReturnProvider()), 
        ChangeNotifierProvider(create: (context) => ExpiryProvider()),
        ChangeNotifierProvider(create: (context) => MiscProvider()),
        ChangeNotifierProvider(create: (context) => OnlineProvider()),
      ],
        child: MyApp(),
      )
  );

}



void configLoading() {
  EasyLoading.instance
    
    ..maskType = EasyLoadingMaskType.custom
    ..displayDuration = const Duration(milliseconds: 2000)
    ..indicatorType = EasyLoadingIndicatorType.hourGlass
    ..loadingStyle = EasyLoadingStyle.custom
    ..indicatorSize = 45.0
    ..radius = 10.0
    ..progressColor = Colors.yellow
    ..backgroundColor = mainColor
    ..indicatorColor = Colors.white
    ..textColor = Colors.white
    ..maskColor = Colors.blue.withOpacity(0.5)
    ..userInteractions = true
    ..dismissOnTap = false;
}

class MyApp extends StatelessWidget {
  
  void setNotif( BuildContext context) async{
    Provider.of<AuthProvider>(context, listen: false).setNotificaton((await prepareNotification())!);
  }

  @override
  Widget build(BuildContext context) {
    setNotif(context);
    return DismissKeyboard(
      child: GetMaterialApp(
        title: 'VicPharm',
        theme: Platform.isIOS ? kIOSTheme : kDefaultTheme,
        home: LoginScreen(),
        builder: EasyLoading.init(),
      ),
    );
  }
}


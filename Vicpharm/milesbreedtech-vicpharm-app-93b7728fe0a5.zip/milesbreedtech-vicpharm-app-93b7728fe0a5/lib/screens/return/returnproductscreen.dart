import 'package:flutter/material.dart';
import 'package:flutter_money_formatter/flutter_money_formatter.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/customwidgets/AlternateContainer.dart';
import 'package:vicpharm_app/customwidgets/initiatereturnmodal.dart';
import 'package:vicpharm_app/models/returnproduct.dart';
import 'package:vicpharm_app/screens/activities/activitiesscreen.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/screens/return/foundreturnscreen.dart';
import 'package:vicpharm_app/screens/return/returnprovider.dart';

import 'package:vicpharm_app/utils/projectcolors.dart';

class ReturnProductScreen extends StatefulWidget {
  ReturnProductScreen({Key? key}) : super(key: key);

  @override
  _ReturnProductScreenState createState() => _ReturnProductScreenState();
}

class _ReturnProductScreenState extends State<ReturnProductScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  //final RefreshController _refreshController = RefreshController();
  String storeCurrency = "";
  var _controller = ScrollController();
  int currentPageNumber = 0;
  ActivitiesLoadMoreStatus loadMoreStatus = ActivitiesLoadMoreStatus.STABLE;
  var currencyFormat = new NumberFormat.currency(locale: "en_US", symbol: "\u{020A6} ");

  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => Provider.of<ReturnProvider>(context, listen: false).setFutureList(
      Provider.of<ReturnProvider>(context, listen: false).populateReturnRecords(1)
      )
    );
  }

   AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Return Record",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 16,),
      onPressed: () {
        Get.offAll(() => LandingScreen());
      }
    ),


  );

  bool onNotification(ScrollNotification notification) {
      if (notification is ScrollUpdateNotification) {
        if (_controller.position.maxScrollExtent > _controller.offset &&
            _controller.position.maxScrollExtent - _controller.offset <=
                50) {
          if (loadMoreStatus != null && loadMoreStatus == ActivitiesLoadMoreStatus.STABLE) {
            loadMoreStatus = ActivitiesLoadMoreStatus.LOADING;
            if(currentPageNumber != Provider.of<ReturnProvider>(context, listen: false).returnTotalPage){
              currentPageNumber = currentPageNumber + 1;
            Provider.of<ReturnProvider>(context, listen: false).populateReturnRecords(currentPageNumber);
            }
            
          }
        }
      }
      return true;
}
  

  Widget returnRecordBox(BuildContext context){
    return Expanded(
      child: FutureBuilder<List<ReturnProduct>?>(
        future: Provider.of<ReturnProvider>(context, listen: true).futureReturnProduct,
        builder: (context, snapshot){
          if(snapshot.hasError){
            return AlternateContainer(text: "Error occurred retrieving data...");
          }else if (snapshot.connectionState == ConnectionState.waiting){
            return AlternateContainer(text: "Loading....");
          }
          else if(snapshot.data == null){
            return AlternateContainer(text: "No Record found.....");
          }
          else if(snapshot.connectionState == ConnectionState.done){
            if(snapshot.data!.length == 0){
              return AlternateContainer(text: "No Record found");
            }else{
              return NotificationListener(
              onNotification: onNotification,
              child: SmartRefresher(
                enablePullDown: true,
                  //scrollController: controller,
                  controller: Provider.of<ReturnProvider>(context, listen: true).refreshController,
                    header: WaterDropMaterialHeader(
                      backgroundColor: mainColor,
                    ),
                    onRefresh: (){
                      Provider.of<ReturnProvider>(context, listen: false).setFutureList(
      Provider.of<ReturnProvider>(context, listen: false).populateReturnRecords(1));
                    },
                child: ListView.builder(
                  controller: _controller,
                  itemCount:  snapshot.data!.length,
                  itemBuilder: (BuildContext context, index) {
                    //return itemContainer(context, returnRecords[index]);
                    return itemContainer(context, snapshot.data![index]);
                  },
                ),
              ),
            );
          
            }
          }
          else{
            return AlternateContainer(text: "Unknown error occurred. Please refresh");
          }
        }
        
      ),
    );
  }

  Widget itemContainer(BuildContext context, ReturnProduct rp){
   
    
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 8, left: 20, right: 20),
      child: InkWell(
        onTap: (){
          //Provider.of<ReturnProvider>(context, listen: false).setSelectedReturnProduct(rp);
          
        },
        child: Container(
          height: Get.height * 0.15,
          width: Get.width * 0.9,
          decoration: BoxDecoration(
              color: Color(0x0d1c63ba),
              borderRadius: BorderRadius.all(Radius.circular(20))
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 20, left: 20),
                child: Text("${rp.productDetail![0].productName}" + ", ....", overflow: TextOverflow.ellipsis, style:  TextStyle(fontSize: 14, fontFamily: 'PoppinsSemiBold'),),
              ),

              Padding(
                padding: const EdgeInsets.only( right: 20, left: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('', overflow: TextOverflow.ellipsis, style:  TextStyle(fontSize: 12, color: grey),),
                    Text(currencyFormat.format(rp.amountReturn ?? 0.0), style:  TextStyle(fontSize: 12, color: mvsblue, fontFamily: 'Roboto'),)
                  ],
                ),
              ),
              
              Padding(
                padding: const EdgeInsets.only(right: 20, left: 20),
                child: Divider(thickness: 2, color: Color(0xb21c63ba),),
              ),

              Padding(
                padding: const EdgeInsets.only(right: 20, left: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("${rp.productDetail!.length} item(s) returned", overflow: TextOverflow.ellipsis, style:  TextStyle(fontSize: 12)),
                    Text(Jiffy(rp.createdAt).yMd, style:  TextStyle(fontSize: 12))
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget mainLayer(BuildContext context) => Container(
      height: Get.height,
      width: Get.width,
      color: whiteBG,
      child: Column(
        children: [

          SizedBox(height: 5,),
          returnRecordBox(context),
        ],
      )

    //child: contentStack(context),
  );

 @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          backgroundColor: whiteBG,
          appBar: appbar(context),
          body: mainLayer(context),
          floatingActionButton: FloatingActionButton.extended(
            label: Text(
              "Initiate Return",
              maxLines: 1,
              style: TextStyle(color: whiteBG, fontSize: 12),
            ),
            onPressed: (){
              Get.dialog(
                InitiateReturnModal(),
                barrierDismissible: true
              );
              //_startReturnDialog();
            },
            elevation: 5,
            backgroundColor: mainColor,

          ),

        )
    );
  }
}


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/models/returnproduct.dart';
import 'package:vicpharm_app/models/returnproductrequest.dart';
import 'package:vicpharm_app/models/salerecord.dart';
import 'package:vicpharm_app/screens/return/foundreturnscreen.dart';
import 'package:vicpharm_app/screens/return/returnproductscreen.dart';
import 'package:vicpharm_app/utils/httpservice.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';

class ReturnProvider with ChangeNotifier {
  final HttpService _httpService = new HttpService();
  List<SaleRecord>? _saleRecords = [];
  SaleRecord? _selectedSaleRecord;
  ProductDetails? _selectedProductDetail;
  ReturnProductRequest? _rpr;
  RefreshController _refreshController = RefreshController();

  RefreshController get refreshController => _refreshController;
  List<ReturnProduct>? _returnproducts = [];
  ReturnProduct? _selectedReturnProduct;
  int? _returnTotalPage;
  Future<List<ReturnProduct>?>? _futureReturnProduct;

  Future<List<ReturnProduct>?>? get futureReturnProduct => _futureReturnProduct;
  List<ReturnProduct>? get returnProducts => _returnproducts;
  ReturnProduct? get selectedReturnProduct => _selectedReturnProduct;
  int? get returnTotalPage => _returnTotalPage;

  List<SaleRecord>? get saleRecords => _saleRecords;
  SaleRecord? get selectedSaleRecord => _selectedSaleRecord;
  ProductDetails? get selectedProductDetail => _selectedProductDetail;
  ReturnProductRequest? get rpr => _rpr;

  setSelectedReturnProduct(ReturnProduct rp){
    _selectedReturnProduct = rp;
  }

  setRpr(ReturnProductRequest sr){
   _rpr = sr;
  }

  setSelectesSaleRecord(SaleRecord sr){
    _selectedSaleRecord = sr;
  }

  setSelectedProductDetail(ProductDetails pd){
    _selectedProductDetail = pd;
  }

  void populateSales(String receiptId) async{
    print("step 1");
    var data = await getSaleByID(receiptId);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _saleRecords!.clear();
    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        String receiptId = data[i]['receiptId'];
        String createdAt = data[i]['createdAt'];
        var totalAmount = data[i]['totalAmount'] ?? 0.0;
        print("tm1: ${totalAmount}");
        var vat = data[i]['vat'] != null ? data[i]['vat'].toDouble() : 0.0;
        print("var: ${vat}");
        List<PaymentType> paymentTypes = [];
        for(var ik = 0; ik < data[i]['paymentType'].length; ik++){
          PaymentType pt = PaymentType.fromJson(data[i]['paymentType'][ik]);
          paymentTypes.add(pt);
        }
        StaffId staffId = StaffId.fromJson(data[i]['staffId']);
        CustomerId cusId = CustomerId.fromJson(data[i]['CustomerId']);

        var productDetailsJson = data[i]['productDetails'];
        print("len of prod details: ${productDetailsJson.runtimeType}");
        print("type ${productDetailsJson.length}");
        List<ProductDetails> productDetails = [];

        for (var j = 0; j < productDetailsJson.length; j++) {
          print("for seling price map");
          Map<String, dynamic> sellingPrice = Map<String, dynamic>();
          sellingPrice.addAll(productDetailsJson[j]['sellingPrice']);
          print("sellig price: ${sellingPrice}");

          Map<String, dynamic> quantity = Map<String, dynamic>();
          quantity.addAll(productDetailsJson[j]['quantity']);

          double tm = productDetailsJson[j]['totalAmount'].toDouble();
          print("tm3 ${tm}");
          String productName = productDetailsJson[j]['productName'];
          String id = productDetailsJson[j]['id'];

          ProductDetails pds = ProductDetails(
            sellingPrice: sellingPrice,
            quantity: quantity,
            totalAmount: tm,
            productName: productName,
            id: id
          );

          productDetails.add(pds);
        }

        SaleRecord cust = SaleRecord(
          productDetails: productDetails,
          customerId: cusId,
          paymentType: paymentTypes,
          vat: vat,
          totalAmount: totalAmount.toDouble(),
          receiptId: receiptId,
          createdAt: createdAt,
          sId: sId,
          staffId: staffId,
        ); 

        print(cust);
        
        _saleRecords!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        //throw(e);
      }
            
                
    }
    LoadingControl.dismissLoading();
    Get.to(() => FoundReturnScreen());
  }

  Future<List<dynamic>?> getSaleByID(String receiptId) async{
    LoadingControl.showLoading();
    final response = await _httpService.getSaleByIDRequest(receiptId);
    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["sales"];    
           
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  returnProduct(ReturnProductRequest rrp) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.returnProductRequest(rrp);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Product Return posted successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         

      Get.offAll(ReturnProductScreen());
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  setFutureList(Future<List<ReturnProduct>?>? st){
    _futureReturnProduct = st;
    notifyListeners();
  }


  
  Future<List<ReturnProduct>?> populateReturnRecords(int page) async{
    print("step 1");
    var data = await getReturnProducts(page);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _returnproducts!.clear();

    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        String salesId = data[i]['salesId'];
        String createdAt = data[i]['createdAt'];
        String comment = data[i]['comment'];
        String returnType = data[i]['returnType'];
        double amountReturn = data[i]['amountReturn'].toDouble();

        //String productId = data[i]['productId'];

        
        StaffId staffId = StaffId.fromJson(data[i]['staffId']);
        //CustomerId cusId = CustomerId.fromJson(data[i]['CustomerId']);

        Map<String, dynamic> returnQuantity = Map<String, dynamic>();
        returnQuantity.addAll(data[i]['returnQuantity']);
        print("returnQuantity: ${returnQuantity}");

        var productDetailsJson = data[i]['productDetail'];
        print("len of prod details: ${productDetailsJson.runtimeType}");
        print("type ${productDetailsJson.length}");
        List<ProductDetails> productDetails = [];

        for (var j = 0; j < productDetailsJson.length; j++) {
          print("for seling price map");
          Map<String, dynamic> sellingPrice = Map<String, dynamic>();
          sellingPrice.addAll(productDetailsJson[j]['sellingPrice']);
          print("sellig price: ${sellingPrice}");

          Map<String, dynamic> quantity = Map<String, dynamic>();
          quantity.addAll(productDetailsJson[j]['quantity']);

          double tm = productDetailsJson[j]['totalAmount'].toDouble();
          print("tm3 ${tm}");
          String productName = productDetailsJson[j]['productName'];
          String id = productDetailsJson[j]['id'];

          ProductDetails pds = ProductDetails(
            sellingPrice: sellingPrice,
            quantity: quantity,
            totalAmount: tm,
            productName: productName,
            id: id
          );

          productDetails.add(pds);
        }

        ReturnProduct cust = ReturnProduct(
          productDetail: productDetails,
          salesId: salesId,
          returnQuantity: returnQuantity,
          amountReturn: amountReturn,
          createdAt: createdAt,
          sId: sId,
          returnType: returnType,
          comment: comment,
          staffId: staffId,
        ); 

        print(cust);
        
        _returnproducts!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        //throw(e);
        _refreshController.loadFailed();
      }
            
                
    }
    _refreshController.loadComplete();
    return _returnproducts;
  }


  Future<List<dynamic>?> getReturnProducts(int page) async{
   
    final response = await _httpService.getReturnProductRequest(page);
    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["Products"];    
      _returnTotalPage = (payload['totalItems']/50).ceil(); 
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  Future<List<ReturnProduct>?> populateStaffReturnRecords(int page, String staffId) async{
    print("step 1");
    var data = await getStaffReturnProducts(page, staffId);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _returnproducts!.clear();

    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        String salesId = data[i]['salesId'];
        String createdAt = data[i]['createdAt'];
        String comment = data[i]['comment'];
        String returnType = data[i]['returnType'];
        double amountReturn = data[i]['amountReturn'].toDouble();

        //String productId = data[i]['productId'];

        
        StaffId staffId = StaffId.fromJson(data[i]['staffId']);
        //CustomerId cusId = CustomerId.fromJson(data[i]['CustomerId']);

        Map<String, dynamic> returnQuantity = Map<String, dynamic>();
        returnQuantity.addAll(data[i]['returnQuantity']);
        print("returnQuantity: ${returnQuantity}");

        var productDetailsJson = data[i]['productDetail'];
        print("len of prod details: ${productDetailsJson.runtimeType}");
        print("type ${productDetailsJson.length}");
        List<ProductDetails> productDetails = [];

        for (var j = 0; j < productDetailsJson.length; j++) {
          print("for seling price map");
          Map<String, dynamic> sellingPrice = Map<String, dynamic>();
          sellingPrice.addAll(productDetailsJson[j]['sellingPrice']);
          print("sellig price: ${sellingPrice}");

          Map<String, dynamic> quantity = Map<String, dynamic>();
          quantity.addAll(productDetailsJson[j]['quantity']);

          double tm = productDetailsJson[j]['totalAmount'].toDouble();
          print("tm3 ${tm}");
          String productName = productDetailsJson[j]['productName'];
          String id = productDetailsJson[j]['id'];

          ProductDetails pds = ProductDetails(
            sellingPrice: sellingPrice,
            quantity: quantity,
            totalAmount: tm,
            productName: productName,
            id: id
          );

          productDetails.add(pds);
        }

        ReturnProduct cust = ReturnProduct(
          productDetail: productDetails,
          salesId: salesId,
          returnQuantity: returnQuantity,
          amountReturn: amountReturn,
          createdAt: createdAt,
          sId: sId,
          returnType: returnType,
          comment: comment,
          staffId: staffId,
        ); 

        print(cust);
        
        _returnproducts!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        //throw(e);
      }
            
                
    }
    return _returnproducts;
  }


  Future<List<dynamic>?> getStaffReturnProducts(int page, String staffId) async{
   
    final response = await _httpService.getStaffReturnRecordRequest(page, staffId);
    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["Products"];    
      _returnTotalPage = (payload['totalItems']/50).ceil(); 
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

}
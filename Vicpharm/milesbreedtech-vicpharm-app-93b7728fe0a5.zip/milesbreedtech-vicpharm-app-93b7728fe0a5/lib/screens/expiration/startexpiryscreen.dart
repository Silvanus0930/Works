import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/expiration/expiryprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class StartExpiryScreen extends StatefulWidget {
  StartExpiryScreen({Key? key}) : super(key: key);

  @override
  _StartExpiryScreenState createState() => _StartExpiryScreenState();
}

class _StartExpiryScreenState extends State<StartExpiryScreen> {
  Map<String, dynamic> expQty = Map<String, dynamic>();
  Map<String, dynamic> expQtyReal = Map<String, dynamic>();
  List<TextEditingController>? _controllers = [];
  TextEditingController commentController = TextEditingController();

  @override
  void initState() { 
    super.initState();
    //_controllers =  List.generate(Provider.of<ExpiryProvider>(context, listen: false).selectedproduct!.unitOfMeasurement!.length - 1, (index) => TextEditingController());
  }

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Select Product",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 16,),
      onPressed: () => Get.back(),
    ),


  );
  
  Widget descField(BuildContext context) => TextFormField(
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: commentController,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        minLines: 5,
        maxLines: 8,
        keyboardType: TextInputType.text,
        textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
        
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Comment",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
       

      );
  
  
  Widget saveBtn() {

    return Padding(
      padding: EdgeInsets.only(left: 20, right: 20.0, top: 20,  bottom: 20.0),
      child: SizedBox(
          height: Get.height * 0.08,
          width: Get.width * 0.5,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: () {
                
                print(expQty);
                expQty.entries.forEach((el) { 
                  if(el.value > 0 && el.value != null){
                    expQtyReal[el.key] = el.value;
                  }
                });


                print(expQtyReal);
                print(Provider.of<ExpiryProvider>(context, listen: false).selectedproduct!.sId!);
                Provider.of<ExpiryProvider>(context, listen: false).expiryproductData(
                  "${commentController.text.isEmpty ? "" : commentController.text}", 
                  Provider.of<ExpiryProvider>(context, listen: false).selectedproduct!.sId!, 
                  expQtyReal
                );
              },
              color: mainColor,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Save",
                      style: TextStyle(fontSize: 14,
                      fontFamily: 'PoppinsSemiBold',
                      color: Colors.white
                    ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.save, size: 16, color: Colors.amber)
                  ),
                ],
              ),

            ),
          )
      ),
    );
  }



  Widget mainContainer(BuildContext context){

    var prs = Provider.of<ExpiryProvider>(context, listen: true).selectedproduct;

    return Container(
      width: Get.width,
      height: Get.height,
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Text("${prs!.name!.capitalizeFirst}", style: TextStyle(fontSize: 14, fontFamily: 'PoppinsSemiBold'),),
                ),

                SizedBox(height: 20,),

                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: prs.quantity!.entries.map((e) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Column(
                        children: [
                          e.key.toString().contains("upDated")
                          ? Container()
                          : Text("${e.key}"),

                          e.key.toString().contains("upDated")
                          ? Container()
                          : Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                              child: TextField(
                                //controller: _controllers![index],
                                onEditingComplete: () => FocusScope.of(context).nextFocus(),
                                
                                style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12, color: Colors.black),
                                keyboardType: TextInputType.numberWithOptions(decimal: true),
                                decoration: InputDecoration(
                                filled: true,
                                fillColor: Color(0xffecf0f1),
                                border: OutlineInputBorder(
                                  borderSide: BorderSide.none,
                                  borderRadius: BorderRadius.all(Radius.circular(10)),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide.none,
                                  borderRadius: BorderRadius.all(Radius.circular(10)),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide.none,
                                  borderRadius: BorderRadius.all(Radius.circular(10)),
                                ),
                                floatingLabelBehavior: FloatingLabelBehavior.never,
                                errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                                hintText: "Quantity",
                                hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                          ),
                
                                onChanged: (String value){
                               
                                    expQty[e.key] = value.isNotEmpty ? double.parse(value) : 0;
                                    //Provider.of<InventoryProvider>(context, listen: false).setMapCostPrice(invp.measurements![index], double.parse(costPriceControllers[index].text));
                        
                                },
                              ),
                            ),


                        ],
                      ),
                    );
                  }
                  ).toList(),
                ),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: descField(context),
                ),
                
                saveBtn()
              ],
            ),
      )
       
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: appbar(context),
        body: mainContainer(context),
      ) 
    );
  }
}
import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/expiration/expiryprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class ExpirationProductDetailScreen extends StatelessWidget {
  const ExpirationProductDetailScreen({Key? key}) : super(key: key);

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Item Details",
      style: TextStyle(color: mainColor, fontFamily: 'Poppins-SemiBold'),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Navigator.of(context).pop(),
    ),
  );

  Widget fieldContainer(BuildContext context, Widget text, String field, Widget icon, bool show){
    return Padding(
      padding: const EdgeInsets.only(top: 5, bottom: 5, left: 20, right: 20),
      child: Container(
        width: MediaQuery.of(context).size.width,
        //height: MediaQuery.of(context).size.height * 0.08,
        decoration: BoxDecoration(
            border: Border.all(color: grey, width: 2)
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.topLeft,
                child: Text(field, maxLines: 1, style: TextStyle(color: mvsblue, fontSize: 12),),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.bottomLeft,
                child: text
              ),
            ),

          
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    String firstname = "${Provider.of<ExpiryProvider>(context, listen: false).selectedExpiredProduct!.staffId!.personalInfo!.firstName}";//data.staffId.personalInfo.firstName == null ? "" : data.staffId.personalInfo.firstName;
    String lastname = "${Provider.of<ExpiryProvider>(context, listen: false).selectedExpiredProduct!.staffId!.personalInfo!.lastName}";//data.staffId.personalInfo.lastName == null ? "" : data.staffId.personalInfo.lastName;
    //String middlename = "Oko";//data.staffId.personalInfo.lastName == null ? "" : data.staffId.personalInfo.middleName;
    String role = Provider.of<ExpiryProvider>(context, listen: false).selectedExpiredProduct!.staffId!.superAdmin == null ? "Admin" : "Staff";//data.staffId.position == null ? "" : data.staffId.position;

    String name = firstname + " " + lastname;
    //Provider.of<ExpiryProvider>(context, listen: false).selectedExpiredProduct!
    var nameWidget = Text(name, maxLines: 1, style: TextStyle(color: grey, fontSize: 12, fontFamily: 'PoppinsSemiBold'),);

    //var prodWidget = Text(Provider.of<ExpiryProvider>(context, listen: false).selectedExpiredProduct!., maxLines: 1, style: TextStyle(color: grey, fontSize: 12, fontFamily: 'PoppinsSemiBold'),);
    
    var qtyColumn = Column(
      children: Provider.of<ExpiryProvider>(context, listen: false).selectedExpiredProduct!.quantity!.entries.map((e) => 
        Text("${e.key}: ${e.value}", maxLines: 1, style: TextStyle(color: grey, fontSize: 12, fontFamily: 'PoppinsSemiBold'),)
      ).toList()
    );

    var createDateWidget = Text(Jiffy(Provider.of<ExpiryProvider>(context, listen: false).selectedExpiredProduct!.createdAt).yMd, maxLines: 1, style: TextStyle(color: grey, fontSize: 12, fontFamily: 'PoppinsSemiBold'),);
    var expiredDateWidget = Text(Jiffy(Provider.of<ExpiryProvider>(context, listen: false).selectedExpiredProduct!.expiedDate).yMd, maxLines: 1, style: TextStyle(color: grey, fontSize: 12, fontFamily: 'PoppinsSemiBold'),);
    

    return SafeArea(
      child: Scaffold(
        appBar: appbar(context),
        backgroundColor: whiteBG,
        body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20,),
                //fieldContainer(context, nameWidget, "Item name", Icon(Icons.assignment_turned_in), true),
                fieldContainer(context, qtyColumn, "Quantity", Icon(Icons.card_travel), true),
                fieldContainer(context, createDateWidget, "Date Created", Icon(Icons.calendar_today), true),
                fieldContainer(context, expiredDateWidget, "Date Expired", Icon(Icons.calendar_today), true),
                fieldContainer(context, nameWidget, "Created by (" + role +")", Icon(Icons.person), false),
                //fieldContainer(context, data.staffId.personalInfo.firstName "John Aswaju (Manager)", "Created by (Cashier | Manager | Owner)"),


              ],
            ),
          ),
        ),

      ),
    );
  }

}
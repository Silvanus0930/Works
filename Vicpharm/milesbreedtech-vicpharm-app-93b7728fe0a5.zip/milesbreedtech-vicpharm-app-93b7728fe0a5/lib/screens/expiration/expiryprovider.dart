import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/models/category.dart';
import 'package:vicpharm_app/models/expiryproduct.dart';
import 'package:vicpharm_app/models/product.dart';
import 'package:vicpharm_app/models/returnproduct.dart';
import 'package:vicpharm_app/models/salerecord.dart';
import 'package:vicpharm_app/screens/expiration/expirationproductsscreen.dart';
import 'package:vicpharm_app/screens/expiration/selectproductscreen.dart';
import 'package:vicpharm_app/screens/expiration/startexpiryscreen.dart';
import 'package:vicpharm_app/utils/httpservice.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';

class ExpiryProvider with ChangeNotifier {
  final HttpService _httpService = new HttpService();
  List<ExpiryProduct>? _expiryProducts = [];
  ExpiryProduct? _selectedExpiryProduct;
  Future<List<ExpiryProduct>?>? _futureExpiryProduct;
  int? _expiryProductTotalPage;
  List<Product>? _products = [];
  Product? _selectedProduct;
  RefreshController _refreshController = RefreshController();

  RefreshController get refreshController => _refreshController;
  List<Product>? get products => _products;
  Product? get selectedproduct => _selectedProduct;
  Future<List<ExpiryProduct>?>? get futureExpiryProduct => _futureExpiryProduct;
  int? get expiryProductTotalPage => _expiryProductTotalPage;
  ExpiryProduct? get selectedExpiredProduct => _selectedExpiryProduct;
  List<ExpiryProduct>? get expiryProducts => _expiryProducts;

  setFutureList(Future<List<ExpiryProduct>?>? ft){
    _futureExpiryProduct = ft;
    notifyListeners();
  }

  setSelectedExpiryProduct(ExpiryProduct ep){
    _selectedExpiryProduct = ep;
  }

   setSelectedProduct(Product cust){
    if(cust != null){
      _selectedProduct = cust;
    }
  }


  Future<List<ExpiryProduct>?> populateExpiryProducts(int page) async{
    print("step 1");
    var data = await getExpiryProducts(page);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _expiryProducts!.clear();
    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        String comment = data[i]['comment'];
        String createdAt = data[i]['createdAt'];
        String expiedDate = data[i]['expiedDate'];

        ProductId productId = ProductId.fromJson(data[i]['productId']);
        StaffId staffId = StaffId.fromJson(data[i]['staffId']);
        //CustomerId cusId = CustomerId.fromJson(data[i]['CustomerId']);

        Map<String, dynamic> quantity = Map<String, dynamic>();
        quantity.addAll(data[i]['quantity']);

      
        ExpiryProduct cust = ExpiryProduct(
          comment: comment,
          productId: productId,
          createdAt: createdAt,
          sId: sId,
          staffId: staffId,
          expiedDate: expiedDate,
          quantity: quantity
        ); 

        print(cust);
        
        _expiryProducts!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        //throw(e);
        _refreshController.loadFailed();
      }
            
                
    }
    _refreshController.loadComplete();
    return _expiryProducts;
  }

  Future<List<dynamic>?> getExpiryProducts(int page) async{
   
    final response = await _httpService.getExpiryProductsRequest(page);
    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["Products"];    
           
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

 Future<List<Product>?> populateSearchProduct(String query) async{
    var data = await searchProduct(query);
    if(data == null){
      LoadingControl.dismissLoading();
      return null;
    }
    print("staff length: ${data.length}" );
    _products!.clear();
    print("staff length:2 ${_products!.length}" );

    for(var i = 0; i < data.length; i++){
      try {
        List<String> unitOfMeasurement = [];
        unitOfMeasurement = data[i]['unitOfMeasurement'].cast<String>();
        List<String> barCode = data[i]['barCode'].cast<String>();
        
       
        
        // gather category array data
        var catData = data[i]['category'];
        List<Category> categories = [];
        for(var j = 0; j < catData.length; j++){
          try {
            Category cat = Category.fromJson(catData[j]);
            categories.add(cat);
          } catch (e) {
            print(e);
          }
        }
        print("steping2 ${i}");

        String sId = data[i]['_id'];
        String name = data[i]['name'];

        Map<String, dynamic> limitPrice = Map<String, dynamic>();
        limitPrice.addAll(data[i]['limitPrice']);

        Map<String, dynamic> sellingPrice = Map<String, dynamic>();
        sellingPrice.addAll(data[i]['sellingPrice']);

        Map<String, dynamic> costPrice = Map<String, dynamic>();
        costPrice.addAll(data[i]['costPrice']);

        Map<String, dynamic> quantity = Map<String, dynamic>();
        quantity.addAll(data[i]['quantity']);

        Map<String, dynamic> discountUnit = Map<String, dynamic>();
        discountUnit.addAll(data[i]['discountUnit']);

        Map<String, dynamic> discountType = Map<String, dynamic>();
        discountType.addAll(data[i]['discountType']);

        Map<String, dynamic> discount = Map<String, dynamic>();
        discount.addAll(data[i]['discount']);

        Map<String, dynamic> reOrderLimit = Map<String, dynamic>();
        reOrderLimit.addAll(data[i]['reOrderLimit']);

        String expiryDate = data[i]['expiryDate'];
        bool status =  data[i]['status'];
        String createdAt = data[i]['createdAt'];

        Product cust = Product(
          unitOfMeasurement: unitOfMeasurement,
          barCode: barCode,
          category: categories,
          sId: sId,
          name: name,
          status: status,
          limitPrice: limitPrice,
          sellingPrice: sellingPrice,
          costPrice: costPrice,
          quantity: quantity,
          sellQuantity: Map<String, dynamic>(),
          discountUnit: discountUnit,
          discountType: discountType,
          discount: discount,
          reOrderLimit: reOrderLimit,
          expiryDate: expiryDate,
          createdAt: createdAt,
        ); 

        print(cust);
        
        _products!.add(cust); 
        print(cust);
      } catch (e) {
        print(e);
      }           
                
    }
    print("is it here");
    LoadingControl.dismissLoading();
    if(_products!.length > 0){
      Get.to(() => SelectProductScreen());
    }else{
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "No Product found....", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _products;
  }

 
 Future<List<dynamic>?> searchProduct(String query) async{
    LoadingControl.showLoading();
    final response = await _httpService.searchProductRequest(query);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){  

      var data = payload['Product'];
      return data;
       
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  expiryproductData(String comments, String productId, Map<String, dynamic> mapQty) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.expiryProductRequest(comments, productId, mapQty);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Product expired successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         

      Get.offAll(() => ExpirationProductsScreen());
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  Future<List<ExpiryProduct>?> populateStaffExpiryProducts(int page, String staffId) async{
    print("step 1");
    var data = await getStaffExpiryProducts(page, staffId);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _expiryProducts!.clear();
    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        String comment = data[i]['comment'];
        String createdAt = data[i]['createdAt'];
        String expiedDate = data[i]['expiedDate'];

        ProductId productId = ProductId.fromJson(data[i]['productId']);
        StaffId staffId = StaffId.fromJson(data[i]['staffId']);
        //CustomerId cusId = CustomerId.fromJson(data[i]['CustomerId']);

        Map<String, dynamic> quantity = Map<String, dynamic>();
        quantity.addAll(data[i]['quantity']);

      
        ExpiryProduct cust = ExpiryProduct(
          comment: comment,
          productId: productId,
          createdAt: createdAt,
          sId: sId,
          staffId: staffId,
          expiedDate: expiedDate,
          quantity: quantity
        ); 

        print(cust);
        
        _expiryProducts!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        //throw(e);
      }
            
                
    }
    return _expiryProducts;
  }

  Future<List<dynamic>?> getStaffExpiryProducts(int page, String staffId) async{
   
    final response = await _httpService.getStaffExpiryProductsRequest(page, staffId);
    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["Products"];    
           
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
    else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }


}
import 'package:flutter/material.dart';
import 'package:flutter_app_badger/flutter_app_badger.dart';
import 'package:get/get.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/expiration/expiryprovider.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class ExpiryInventoryScreen extends StatefulWidget {
  @override
  _ExpiryInventoryScreenState createState() => _ExpiryInventoryScreenState();
}

class _ExpiryInventoryScreenState extends State<ExpiryInventoryScreen> {
  final RefreshController _refreshController = RefreshController();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  var _controller = ScrollController();
  
  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => initData()
    );

    
  }

  initData () async {
    LoadingControl.showSnackBar(
        "NOTE!!!!", 
        "Tapping on any of the products will make it unavailable in the Inventory", 
        Icon(Icons.notification_important, color: Colors.orange,)
      );

      FlutterAppBadger.removeBadge();
  }

  



  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Products to Expire",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 16,),
      onPressed: () => Get.offAll(() => LandingScreen()),
    ),


  );
  
  
  
  
 
  Widget mainLayer(BuildContext context) => Container(
      height: Get.height,
      width: Get.width,
      color: whiteBG,
      child: SmartRefresher(
                   enablePullDown: true,
                  //scrollController: controller,
                  controller: Provider.of<AuthProvider>(context, listen: true).refreshController,
                    header: WaterDropMaterialHeader(
                      backgroundColor: mainColor,
                    ),
                    onRefresh: (){
                      Provider.of<AuthProvider>(context, listen: false).getExpiryInventories();
                    },
                   child: ListView.builder(
                    controller: _controller,
                    itemCount: Provider.of<AuthProvider>(context, listen: true).expiryInventories.length,
                    itemBuilder: (BuildContext context, index){
                      var ei = Provider.of<AuthProvider>(context, listen: true).expiryInventories[index];
                      return Padding(
                              padding: const EdgeInsets.only(top: 8, bottom: 8, left: 20, right: 20),
                              child: Container(
                                //height: MediaQuery.of(context).size.height * 0.1,
                                width: MediaQuery.of(context).size.width * 0.9,
                                decoration: BoxDecoration(
                                    color: Color(0xffe0d5e2),
                                    borderRadius: BorderRadius.all(Radius.circular(20))
                                ),
                                child: ListTile(
                                  onTap: (){
                                    Get.defaultDialog(
                                      title: "NOTE!!!!",
                                      titleStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14, color: mainColor),
                                      content: Text("You are about expire this product. It may not be available for sales after this operation. Do you wish to continue?",
                                                    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12),),
                                      actions: [
                                        InkWell(
                                          onTap: (){
                                            Get.back();
                                          },
                                          child: Text("Cancel", style: TextStyle( decoration: TextDecoration.underline, color: mvsred, fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
                                        ),

                                        SizedBox(width: 100,),

                                        InkWell(
                                          onTap: (){
                                            Get.back();
                                            Provider.of<AuthProvider>(context, listen: false).inventorySoldOut(ei.sId!);
                                          },
                                          child: Text("Continue", style: TextStyle(color: mainColor, fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
                                        ),
                                      ]

                                    );
                                    
                                    
                                    
                                  },
                                  title: Text("${ei.name}", maxLines: 1, style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14, color: mainColor),),
                                  subtitle: Text("${Jiffy(ei.expiryDate).yMMMEdjm}", maxLines: 1, style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12),),
                                  trailing: Icon(Icons.arrow_forward_ios, color: mainColor, size: 16,),
                                )
                              ),
                            );
                      
                    },
                  ),
                 ),
              

  );
  
  @override
  Widget build(BuildContext context) {
    
    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          backgroundColor: whiteBG,
          appBar: appbar(context),
          body: mainLayer(context),
          
        )
    );
  }

}
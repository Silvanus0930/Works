import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/expiration/expiryprovider.dart';
import 'package:vicpharm_app/screens/expiration/startexpiryscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class SelectProductScreen extends StatefulWidget {
  SelectProductScreen({Key? key}) : super(key: key);

  @override
  _SelectProductScreenState createState() => _SelectProductScreenState();
}

class _SelectProductScreenState extends State<SelectProductScreen> {

    AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Select Product",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 16,),
      onPressed: () => Get.back(),
    ),


  );
  
  @override
  Widget build(BuildContext context) {
    return SafeArea(
       child: Scaffold(
         appBar: appbar(context),
         body: ListView.builder(
           itemCount: Provider.of<ExpiryProvider>(context, listen: true).products!.length,
           itemBuilder: (BuildContext context, int index) {
             var pss = Provider.of<ExpiryProvider>(context, listen: true).products;
           return Padding(
             padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
             child: ListTile(
               onTap: (){
                 Provider.of<ExpiryProvider>(context, listen: false).setSelectedProduct(pss![index]);
                 Get.to(() => StartExpiryScreen());
               },
               title: Text("${pss![index].name}", style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12),),
                trailing: Icon(Icons.arrow_forward_ios_rounded, color: mainColor,),
             ),
            );
          },
         ),
       )
    );
  }
}
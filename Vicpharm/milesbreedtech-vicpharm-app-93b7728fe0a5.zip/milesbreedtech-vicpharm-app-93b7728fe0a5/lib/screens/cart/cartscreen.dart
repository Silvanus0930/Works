import 'package:flutter/material.dart';
import 'package:flutter_money_formatter/flutter_money_formatter.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/customwidgets/editquantitymodal.dart';
import 'package:vicpharm_app/models/product.dart';
import 'package:vicpharm_app/screens/cart/checkoutscreen.dart';
import 'package:vicpharm_app/screens/cart/customercart.dart';
import 'package:vicpharm_app/screens/landing/landingprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class CartScreen extends StatefulWidget {
  CartScreen({Key? key}) : super(key: key);

  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Cart: ${Provider.of<LandingProvider>(context, listen: true).cartProducts!.length}",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 16,),
      onPressed: () {
        Navigator.of(context).pop();

      },
    ),
    actions: [
      IconButton(
          onPressed: (){
            Provider.of<LandingProvider>(context, listen: false).clearCartProducts();
          },
          icon: Icon(Icons.delete, color: mvsred),
        ),
      
    ]
  );

  Widget proceedBtn(BuildContext context) {
    FlutterMoneyFormatter fmf_up = FlutterMoneyFormatter(
                            amount: Provider.of<LandingProvider>(context, listen: true).calculateTotalPriceInCart(),
                            settings: MoneyFormatterSettings(
                              symbol: "NGN",
                              thousandSeparator: ',',
                              decimalSeparator: '.',
                              symbolAndNumberSeparator: ' ',
                              fractionDigits: 2,

                            ));
    
    return Padding(
      padding: EdgeInsets.only(top: 15, right: 20.0, bottom: 20.0),
      child: SizedBox(
          height: Get.height * 0.08,
          width: Get.width * 0.55,

          child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(50)),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    blurRadius: 15,
                    spreadRadius: 3,
                    offset: Offset(-1, 20),
                  ),
                ],
              ),
              child: MaterialButton(
                elevation: 0.0,
                shape: StadiumBorder(),

                onPressed: () {
                  Get.to(() => CustomerCartScreen());

                },

                color: mainColor,
                child: Stack(
                  // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Align(
                        alignment: Alignment.center,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              "Proceed",
                              style: TextStyle(fontSize: 12,
                                  fontFamily: 'PoppinsBold',
                                  color: whiteBG),
                            ),

                           Text(
                                  "${fmf_up.output.symbolOnLeft}",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: whiteBG, fontFamily: 'PoppinsSemiBold'),
                                                
                            ),
                          ],
                        )
                    ),
                    Align(
                        alignment: Alignment.centerRight,
                        child: Icon(
                            Icons.arrow_forward_ios, size: 12, color: whiteBG)),
                  ],
                ),

              ),
            ),
         
      ),
    );
  }

  Widget categoryWidget(String cat){
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.1,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: mainColor.withOpacity(0.3),
          //border: Border.all(color: Colors.red, width: 1.0)
        ),
        child: Center(
          child: Text(
            cat.substring(0, 1).toUpperCase(),
            style: TextStyle(
                fontFamily: 'PoppinsBold',
                fontSize: 28,
                color:  mainColor),
          ),
        ),
      ),
    );
  }


  Widget cartItemsList(BuildContext context){
    //var data = Provider.of<CartProvider>(context, listen: false);
    var cartProducts = Provider.of<LandingProvider>(context, listen: true).cartProducts;
    return SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: Get.height * 0.75,
              child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: cartProducts!.length,
                      itemBuilder: (BuildContext context, i){
                        
                        FlutterMoneyFormatter fmf = FlutterMoneyFormatter(
                            amount: Provider.of<LandingProvider>(context, listen: true).cartProducts![i].totalSellingPrice,
                            settings: MoneyFormatterSettings(
                              symbol: "NGN" ,
                              thousandSeparator: ',',
                              decimalSeparator: '.',
                              symbolAndNumberSeparator: ' ',
                              fractionDigits: 2,

                            ));

                        return Dismissible(
                          key: Key( cartProducts[i].sId!),
                          onDismissed: (direction) {
                            Product deleteCPD = cartProducts[i];
                            Provider.of<LandingProvider>(context, listen: false).removeCartProduct(i);
                          },
                          child: Padding(
                                  padding: const EdgeInsets.only(top: 8.0, left: 20, right: 20, bottom: 8),
                                  child: Column(
                                    children: [
                                      Container(
                                        width: MediaQuery.of(context).size.width,
                                        height: MediaQuery.of(context).size.height * 0.13,
                                        color: Color(0xffecf0f1),
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(
                                                width: MediaQuery.of(context).size.width * 0.5,
                                                child: Row(
                                                  children: [
                                                    categoryWidget("${cartProducts[i].name}"),
                                                    Column(
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                            child: Text("${cartProducts[i].name}".capitalizeFirst!, overflow: TextOverflow.ellipsis, style: TextStyle(color: Color(0xff979797), fontSize: 12, fontFamily: 'PoppinsRegular'),)),
                                                        SizedBox(height: 10,),
                                                        Text(fmf.output.symbolOnLeft, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontFamily: 'Roboto', color: Color(0xff4f4f4f), fontSize: 12),),
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              ),
                                             
                                            ],
                                          ),
                                        ),
                                      ),

                                      Column(
                                        children: List.generate(cartProducts[i].unitOfMeasurement!.length, (j) => 
                                          Container(
                                                width: Get.width,
                                                child: ListTile(
                                                  onTap: (){
                                                    Get.dialog(EditQtyModal(productIndex: i, measureKey: cartProducts[i].unitOfMeasurement![j],));
                                                  },
                                                  title: Text("${cartProducts[i].unitOfMeasurement![j]}", overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 14, fontFamily: 'PoppinsSemiBold'),  ),
                                                  subtitle: Text("Quantity", overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'), ),
                                                  trailing: Text("${cartProducts[i].sellQuantity![cartProducts[i].unitOfMeasurement![j]] ?? 0.0}", overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'), ),
                                                ),
                                              )
                                        ),
                                      ),

                                      SizedBox(height: 10,),

                                      Column(
                                        children: List.generate(cartProducts[i].unitOfMeasurement!.length, (j) => 
                                          Container(
                                                width: Get.width,
                                                child: ListTile(
                                                  onTap: (){},
                                                  title: Text("${cartProducts[i].unitOfMeasurement![j]}", overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 14, fontFamily: 'PoppinsSemiBold'),),
                                                  subtitle: Text("Selling Price", overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),),
                                                  trailing: Text("NGN ${cartProducts[i].sellingPrice![cartProducts[i].unitOfMeasurement![j]] ?? 0.0}", overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),),
                                                ),
                                              )
                                        ),
                                      ),

                                      
                                  
                                    ],
                                ) //
                              ),
                            
                        );
                      }
                  )
                
            ),

            proceedBtn(context)
            //cartProvider.cartItems.length > 0 ? proceedBtn(context) : Container()
          ],
        )

    );
  }


  Widget mainLayer(BuildContext context) => Container(
    height: MediaQuery.of(context).size.height,
    width: MediaQuery.of(context).size.width,
    child: cartItemsList(context),
  );

  @override
  Widget build(BuildContext context) {
    //var cartProvider = Provider.of<CartProvider>(context);
    //sumTotal();
    return GestureDetector(
      onTap: (){
        FocusScopeNode currentFocus = FocusScope.of(context);
        if(!currentFocus.hasPrimaryFocus) {
          currentFocus.unfocus();
        }
      },
      child: SafeArea(
          child: Scaffold(
            key: _scaffoldKey,
            appBar: appbar(context),
            body: mainLayer(context),

          )
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter_money_formatter/flutter_money_formatter.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/customwidgets/datetimefields.dart';
import 'package:vicpharm_app/screens/cart/sellsuccessscreen.dart';
import 'package:vicpharm_app/screens/landing/landingprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class CheckOutScreen extends StatefulWidget {
  CheckOutScreen({Key? key}) : super(key: key);

  @override
  _CheckOutScreenState createState() => _CheckOutScreenState();
}

class _CheckOutScreenState extends State<CheckOutScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  List<String> paymentMtds = <String>["Cash", "Transfer", "POS"];
  String? paymentMtd;

  List<String> saleOptions = <String>["Full sale", "Debt sale"];
  String? saleOption;
  String saleType = "";
  String paymentPlan = "";

  bool debtSale = false;
  bool customerExist = false;
  TextEditingController expiryDateController = new TextEditingController();
  TextEditingController amtPaidController = TextEditingController();

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Check out",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      onPressed: (){
        Navigator.of(context).pop();
      },
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
    ),
    actions: [

    ],

  );

  Widget orderSumText(String text) => Padding(
    padding: const EdgeInsets.only(top: 30, left: 20, right: 20),
    child: Text(
      text,
      style: TextStyle(color: mvsblue, fontSize: 16),
    ),
  );

  Widget bodyDivider(Color color){
    return Padding(
      padding: const EdgeInsets.only(top: 5, left: 20, right: 20),
      child: Divider(
        thickness: 1,
        color: color,
      ),
    );
  }

  Widget sellItemList(BuildContext context){
    var chProduct = Provider.of<LandingProvider>(context, listen: true).checkoutProduct;
    return Column(
        children: List.generate(chProduct!.productDetails!.length, (index) {
          FlutterMoneyFormatter  fmf = FlutterMoneyFormatter(
              amount: chProduct.productDetails![index].totalAmount,//cartProvider.cartItems[index].sellingPrice != null ? cartProvider.cartItems[index].sellingPrice.toDouble() : 0.0,
              settings: MoneyFormatterSettings(
                symbol: "NGN",
                thousandSeparator: ',',
                decimalSeparator: '.',
                symbolAndNumberSeparator: ' ',
                fractionDigits: 2,
              ));
          

          FlutterMoneyFormatter  fmfT = FlutterMoneyFormatter(
              amount: 5,//cartProvider.calcNoDiscount(
                //index,
                 // cartProvider.cartItems[index].discount != null ? cartProvider.cartItems[index].discount : "0",
                 // cartProvider.cartItems[index].discountUnit != null ? cartProvider.cartItems[index].discountUnit : "0",
               //   cartProvider.cartItems[index].discountType != null ? cartProvider.cartItems[index].discountType : ""
             // ),//cartProvider.cartItems[index].totalPrice != null ?  cartProvider.cartItems[index].totalPrice : 0.0,
              settings: MoneyFormatterSettings(
                symbol: "NGN",
                thousandSeparator: ',',
                decimalSeparator: '.',
                symbolAndNumberSeparator: ' ',
                fractionDigits: 2,
              ));
          MoneyFormatterOutput  fot = fmfT.output;
          
          return Container(
            width: double.infinity,
            //height: MediaQuery.of(context).size.height * 0.1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.6,
                  child: Padding(
                    padding: EdgeInsets.only(top: 5, left: 20),
                    child: Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            "${chProduct.productDetails![index].name}",//cartProvider.cartItems[index].productName,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 14,fontFamily: 'PoppinsSemiBold'),
                          ),
                          SizedBox(height: 5,),
                          Column(
                            children: chProduct.productDetails![index].quantity!.entries.map((e) => 
                            SizedBox(
                              width: Get.width * 0.4,
                              child: Row(
                                children: [
                                  Text("${e.key}: ",
                                    maxLines: 1,
                                    style: TextStyle(fontSize: 14, color: grey, fontFamily: 'PoppinsRegular'),
                                  ),

                                  Text("${e.value}",
                                    maxLines: 1,
                                    style: TextStyle(fontSize: 14, color: grey, fontFamily: 'PoppinsRegular'),
                                  ),
                                ],
                              ),
                            )
                          ).toList(),
                          )
                        
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 5, right: 20),
                  child: Container(
                    child: Center(
                      child: Text(fmf.output.symbolOnLeft,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 14, color: grey,fontFamily: 'PoppinsRegular'),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
      );
    

  }

  Widget vatRow(){
    Provider.of<LandingProvider>(context, listen: false).retrieveVat();
    Provider.of<LandingProvider>(context, listen: false).calculateVatTotal(Provider.of<LandingProvider>(context, listen: false).vat!);
     FlutterMoneyFormatter  fmf = FlutterMoneyFormatter(
              amount: Provider.of<LandingProvider>(context, listen: true).vatTotal,//cartProvider.cartItems[index].sellingPrice != null ? cartProvider.cartItems[index].sellingPrice.toDouble() : 0.0,
              settings: MoneyFormatterSettings(
                symbol: "NGN",
                thousandSeparator: ',',
                decimalSeparator: '.',
                symbolAndNumberSeparator: ' ',
                fractionDigits: 2,
              ));

    return Padding(
      padding: const EdgeInsets.only(top: 5, left: 20, right: 20),
      child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "VAT",
              style: TextStyle(color: Color(0xff979797), fontFamily: 'PoppinsSemiBold', fontSize: 12),
            ),

            Text(
                  "(${Provider.of<LandingProvider>(context, listen: true).vat} %) " + "${fmf.output.symbolOnLeft}",
                  style: TextStyle(color: Color(0xff979797), fontFamily: 'PoppinsRegular', fontSize: 12),
            )
          ],
        ),
     
    );
  }

  Widget totalRow(){
    FlutterMoneyFormatter  fmf = FlutterMoneyFormatter(
              amount: Provider.of<LandingProvider>(context, listen: true).normalTotal,//cartProvider.cartItems[index].sellingPrice != null ? cartProvider.cartItems[index].sellingPrice.toDouble() : 0.0,
              settings: MoneyFormatterSettings(
                symbol: "NGN",
                thousandSeparator: ',',
                decimalSeparator: '.',
                symbolAndNumberSeparator: ' ',
                fractionDigits: 2,
              ));
    return Padding(
      padding: const EdgeInsets.only(top: 5, left: 20, right: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Total",
            style: TextStyle(color: black, fontFamily: 'PoppinsSemiBold', fontSize: 12),
          ),

          Text(
                "${fmf.output.symbolOnLeft}",
                style: TextStyle(color: black, fontFamily: 'Roboto', fontSize: 12),
              )
        ],
      ),
    );
  }

  Widget selectText(String text) => Padding(
    padding: const EdgeInsets.only(top: 20, left: 20, right: 20),
    child: Text(
      text,
      style: TextStyle(color: grey, fontSize: 14),
    ),
  );

  Widget paymentSelect(BuildContext context){
    return Padding(
      padding: EdgeInsets.only(left: 20, top: 10.0, right: 20.0),
      child: DropdownButton<String>(
          hint: Text("Select payment method",
              style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)
          ),
          value: paymentMtd,
          icon: Icon(Icons.arrow_drop_down, color: mainColor,),
          elevation: 10,
          style: TextStyle(color: mainColor),
          underline: Container(
            height: 2,
            color: grey,
          ),
          onChanged: (String? value){
            setState(() {
              print(value);
              paymentMtd =  value;
              print(paymentMtd);
              if(paymentMtd!= null && paymentMtd == "manager"){

              }else{

              }
            });

          },
          isExpanded: true,
          items: paymentMtds.map((value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value, style: TextStyle(fontSize: 12, color: black),),
            );
          }).toList(),
        ),
      
    );
  }

  Widget sellOptionSelect(BuildContext context){
    return Padding(
      padding: EdgeInsets.only(left: 20, top: 10.0, right: 20.0),
      child: DropdownButton<String>(
          hint: Text("Select sale option",
              style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)
          ),
          value: saleOption,
          icon: Icon(Icons.arrow_drop_down, color: mainColor,),
          elevation: 10,
          style: TextStyle(color: mainColor),
          underline: Container(
            height: 2,
            color: grey,
          ),
          onChanged: (String? value){
            setState(() {
              print(value);
              saleOption=  value;
              print(saleOption);
              if(saleOption != null && saleOption == "Debt sale"){
                saleType = "DebitSales";
                setState(() {
                  debtSale = true;
                });
              }else{
                saleType = "Full sale";
                setState(() {
                  debtSale = false;
                });
              }
            });
          },
          isExpanded: true,
          items: saleOptions.map((value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value, style: TextStyle(fontSize: 12, color: black, fontFamily: 'PoppinsSemiBold'),),
            );
          }).toList(),
        ),
   
    );
  }

  TextFormField amtPaidField(BuildContext context) {

    return TextFormField(

      style: TextStyle(
          fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      controller: amtPaidController,
      enableSuggestions: true,
      autocorrect: true,
      keyboardType: TextInputType.numberWithOptions(decimal: true),
      textInputAction: TextInputAction.done,
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),
          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          suffixIcon: Icon(Icons.monetization_on, color: Colors.grey, size: 16,),
          prefix: Text("NGN"),
          prefixStyle: TextStyle(
              fontFamily: 'Roboto', fontSize: 12, color: black),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),

          hintText: "Amount Paid",
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

    );
  }

  Widget openCusAddBtn(BuildContext context){
    return FlatButton(
        color: Colors.transparent,
        onPressed: (){
          //_addeditcustomerDialog();
        },
        child: Text(
          "Click to add customer details",
          style: TextStyle(color: Colors.black54, decoration: TextDecoration.underline, fontFamily: 'PoppinsSemiBold'),
        ),
      );
    
  }
  
  Widget customerList(BuildContext context) {
    String fname = "Ade";//selectedCustomer.firstName != null ? selectedCustomer.firstName : "";
    String lname = "Musa";//selectedCustomer.lastName != null ? selectedCustomer.lastName : "";
    String name = fname + " " + lname;
    return Container(
      //height: 200,
      child:  Column(
        children: [
          Padding(
            padding: EdgeInsets.only(top: 5, left: 20, right: 20),

            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 5.0,bottom: 5.0),
                  child: Text(
                    name,
                    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey),
                  ),
                ),

               // Padding(
               //   padding: const EdgeInsets.only(top: 5.0),
              //    child: Text(Customer.allCustomers[0].firstName + " " + Customer.allCustomers[0].lastName,
             //       style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14),),
            //    ),
                Divider(
                  thickness: 1,
                  color: grey,
                ),
              ],
            ),

          ),
          Padding(
            padding: EdgeInsets.only(top: 5, left: 20, right: 20),

            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 5.0,bottom: 5.0),
                  child: Text(
                    "Ade",
                    //selectedCustomer.phoneNumber != null ? selectedCustomer.phoneNumber : "",
                    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey),
                  ),
                ),

             //   Padding(
            //      padding: const EdgeInsets.only(top: 5.0),
            //      child: Text(Customer.allCustomers[0].phoneNumber,
            //       style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14),),
            //    ),
                Divider(
                  thickness: 1,
                  color: grey,
                ),
              ],
            ),

          ),
        ],
      )
    );
  }

  Widget addFieldBtn(BuildContext context){
    return FlatButton(
        color: Colors.transparent,
        onPressed: (){
          //addAdditionalFieldDialog();
        },
        child: Text(
          "Add field +",
          style: TextStyle(color: Colors.black54, decoration: TextDecoration.underline, fontFamily: 'PoppinsSemiBold'),
        ),
      );
   
  }

  Widget uniqueDetailList(BuildContext context){
    return Container(

        child: ListView.builder(
          shrinkWrap: true,
          itemCount: 2,//upds.length,
            itemBuilder: (BuildContext contx, i){
              //return additionalRow(context, upds[i], i);
              return additionalRow(context,  i);
            }
        ),

    );
  }
  
  Widget additionalRow(BuildContext context, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
      child: Container(
        height: 60,
        decoration: BoxDecoration(
          color: Color(0xffeaf0f3),
          borderRadius: const BorderRadius.all(
            const Radius.circular(8.0),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.2,
                  child: Text(
                    "code",
                    //uniqueProductDetail.key + "::",
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle( fontSize: 12, fontFamily: 'PoppinsRegular'),),
              ),
              SizedBox(width: 10,),
              Expanded(child: Text(
                "run",
                //uniqueProductDetail.value,
                overflow: TextOverflow.ellipsis,
                style: TextStyle( fontSize: 12, fontFamily: 'PoppinsRegular'),),

              ),

              IconButton(
                onPressed: (){
                  setState(() {
                    //upds.removeAt(index);
                  });
                },

                icon: Icon(Icons.delete_forever,color:  Colors.red,),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget sellBtn(BuildContext context) {
    // var authProvider = Provider.of<AuthProvider>(context, listen: false);
   // var cartProvider = Provider.of<CartProvider>(context, listen: false);
   // AppDatabase appDatabase = Provider.of<AppDatabase>(context, listen: false);
   return Padding(
      padding: EdgeInsets.only(top: 15, right: 20.0, bottom: 20.0),
      child: SizedBox(
          height: MediaQuery
              .of(context)
              .size
              .height * 0.08,
          width: MediaQuery
              .of(context)
              .size
              .width * 0.4,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 20),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),

              onPressed: () {
                
                var lProvider = Provider.of<LandingProvider>(context, listen: false);
                lProvider.checkoutProduct!.typeOfsales = saleOption == "Full sale" ? "fullPayment" : "creditSales";//"Full sale", "Debt sale"
                lProvider.checkoutProduct!.paymentType = paymentMtd;
                lProvider.checkoutProduct!.expectedDate = expiryDateController.text;
                lProvider.checkoutProduct!.vat = lProvider.vatTotal;
                lProvider.checkoutProduct!.totalAmount = lProvider.normalTotal;
                lProvider.checkoutProduct!.paid = debtSale ? 
                amtPaidController.text.isEmpty 
                ? 0.0 
                : double.tryParse(amtPaidController.text)
                : 0.0; 
                lProvider.saleProduct(lProvider.checkoutProduct!);
                //Get.to(() => SellSuccessScreen());
              },
              color: mainColor,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Sell now",
                      style: TextStyle(fontSize: 12,
                          fontFamily: 'PoppinsRegular',
                          color: whiteBG),
                    ),
                  ),
                  //SizedBox(width: 20,),
                  Align(alignment: Alignment.centerRight,
                      child: Icon(
                          Icons.arrow_forward_ios, size: 16, color: whiteBG)),
                ],
              ),

            ),
          )
      ),
    );
  }

  
  Widget mainContainer(BuildContext context){
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          orderSumText("Order Summary"),
          bodyDivider(Color(0xfff2994a)),
          sellItemList(context),
          vatRow(),
          bodyDivider(grey),
          totalRow(),
          //orderSumText("Payment Option"),
          bodyDivider(Color(0xfff2994a)),
          selectText("Select payment option"),
          paymentSelect(context),
          //orderSumText("Sale Option"),
          //bodyDivider(Color(0xfff2994a)),
          selectText("Select sale option"),
          sellOptionSelect(context),
          debtSale ? Padding(
            padding: const EdgeInsets.only(top: 5, left: 20, right: 20),
            child: AndroidDateTimeField(expiryDateController: expiryDateController, label: "Expected Payment Date"),
          ) : Container(),
          debtSale ? Padding(
            padding: const EdgeInsets.only(top: 5, left: 20, right: 20),
            child: amtPaidField(context)
          ) : Container(),

          
          //orderSumText("Customer Details (Optional)" ),
          //bodyDivider(Color(0xfff2994a)),
          //openCusAddBtn(context),
          //customerList(context),
          //orderSumText("Additional item information" ),
          //bodyDivider(Color(0xfff2994a)),
          //addFieldBtn(context),
          //uniqueDetailList(context),

          //additionalRow(context),

          Align(
            alignment: Alignment.center,
            child: sellBtn(context)
          ),

        ],
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {

    return SafeArea(
      child: Scaffold(
        key: _scaffoldKey,
        appBar: appbar(context),
        body: mainContainer(context)
      ),
    );
  }
}
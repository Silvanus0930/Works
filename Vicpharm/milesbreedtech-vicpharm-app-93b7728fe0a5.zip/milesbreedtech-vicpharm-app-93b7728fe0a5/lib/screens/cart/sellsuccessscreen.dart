import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/cart/printscreen.dart';
import 'package:vicpharm_app/screens/landing/landingprovider.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class SellSuccessScreen extends StatefulWidget {
  SellSuccessScreen({Key? key}) : super(key: key);

  @override
  _SellSuccessScreenState createState() => _SellSuccessScreenState();
}

class _SellSuccessScreenState extends State<SellSuccessScreen> {

  Widget printBtn(BuildContext context) {

    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.7,
      height: MediaQuery.of(context).size.height * 0.08,
      child: ElevatedButton(
        style: ButtonStyle(
            shape: MaterialStateProperty.all(StadiumBorder()),
            backgroundColor: MaterialStateProperty.all<Color>(mainColor)
        ),
        onPressed: (){
            Get.to(() => PrintScreen());
          /* Navigator.pushReplacement(
              context,
              BouncyPageRoute(widget: PrintPage(rec: receipt, cpds: cpds,))); */


        },
        child: Stack(
          children: [
            Align(
              alignment: Alignment.center,
              child: Text("Print receipt", style: TextStyle(color: whiteBG, fontSize: 12, fontFamily: 'PoppinsRegular'),),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Icon(Icons.arrow_forward_ios, color: whiteBG, size: 12)
            ),
          ],
        )
      ),
    );
  }

  Widget homeBtn(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.7,
      height: MediaQuery.of(context).size.height * 0.08,
      child: ElevatedButton(
          style: ButtonStyle(
            shape: MaterialStateProperty.all(StadiumBorder()),
            backgroundColor: MaterialStateProperty.all<Color>(mainColor)
          ),
         
          onPressed: (){
            Provider.of<LandingProvider>(context, listen: false).clearCartProducts();
            //var cartProvider = Provider.of<CartProvider>(context, listen: false);
            //cartProvider.clearCart();
            Get.to(() => LandingScreen());
           

          },
          child: Stack(
            children: [
              Align(
                alignment: Alignment.center,
                child: Text("Back to Main menu", style: TextStyle(color: whiteBG, fontSize: 12, fontFamily: 'PoppinsRegular'),),
              ),

              Align(
                  alignment: Alignment.centerRight,
                  child: Icon(Icons.arrow_forward_ios, color: whiteBG, size: 14,)
              ),
            ],
          )
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      
      child: WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
          backgroundColor: whiteBG,
          body: Container(
            width: double.infinity,
            height: double.infinity,
            color: whiteBG,
            child: Column(

              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.08,
                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.9,
                  height: MediaQuery.of(context).size.height * 0.55,
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(20))
                    ),
                    child:  Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      //mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(height: 10,),
                        SizedBox(
                          height: 280,
                          width: MediaQuery.of(context).size.width,
                          child: Container(
                            decoration: BoxDecoration(
                              //color: Colors.red,
                              image: DecorationImage(
                                image: AssetImage("assets/images/success.png"),
                                //fit: BoxFit.fill
                              )
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.center,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text("Transcation Successful",
                                style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)),
                          ),
                        ), 
                        SizedBox(height: 30,),

                      ],
                    )
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.05,
                ),
                //printBtn(context),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.05,
                ),
                homeBtn(context)
              ],

            ),
          ),
        ),
      ),
    );
  }
}
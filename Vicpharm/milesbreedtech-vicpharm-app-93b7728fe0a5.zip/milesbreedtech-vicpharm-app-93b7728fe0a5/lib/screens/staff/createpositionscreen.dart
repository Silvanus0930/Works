import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/models/managerposition.dart';
import 'package:vicpharm_app/screens/staff/staffprovider.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class CreatePosition extends StatefulWidget {
  CreatePosition({Key? key}) : super(key: key);

  @override
  _CreatePositionState createState() => _CreatePositionState();
}

class _CreatePositionState extends State<CreatePosition> {
  TextEditingController nameController = TextEditingController();

   @override
  void initState() { 
    super.initState();
    Provider.of<StaffProvider>(context, listen: false).setManagerPosition(new ManagerPosition());
    Provider.of<StaffProvider>(context, listen: false).retrieveRoles();
  }

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Edit Position",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),

    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Navigator.of(context).pop(),
    ),

    
  );

  Widget searchField(BuildContext context) => TextField(
    
        
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: nameController,
        style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.text,
        textInputAction: TextInputAction.search,
        
        
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Position Name",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        

      );
  
   Widget saveBtn(BuildContext context) => Align(
    alignment: Alignment.center,
    child: Padding(
      padding: EdgeInsets.only(top: 20.0, right: 20.0, bottom: 20.0),
      child: SizedBox(
          height: MediaQuery.of(context).size.height * 0.08,
          width: MediaQuery.of(context).size.width * 0.5,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 20),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: () async{
                if(nameController.text.isEmpty){
                  LoadingControl.showSnackBar(
                    "Ouchs!!!", 
                    "Position Name is required", 
                    Icon(Icons.error, color: Colors.red,)
                  );
                  return;
                }
                List<String> data = await Provider.of<StaffProvider>(context, listen: false).populateSortedRoles();
                Provider.of<StaffProvider>(context, listen: false).createPosition(
                  nameController.text,
                  data
                );
              },

              color: mainColor,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Save",
                      style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold', color: whiteBG),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.arrow_forward_ios, size: 12, color: whiteBG)
                  ),
                ],
              ),

            ),
          )
      ),
    ),
  );

  
  Widget mainContainer(BuildContext context){

    return Container(
      color: whiteBG,
      width: Get.width,
      height: Get.height,      
      child: SingleChildScrollView(
        
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: searchField(context),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Text(
                "Select Roles for this positiomn",
                style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black)
              ),
            ),

            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: List.generate(Provider.of<StaffProvider>(context, listen: true).roleDatas!.length, (i) => ListTile(
                onTap: (){
                    
                    Provider.of<StaffProvider>(context, listen: false).checkSelectedRoles(i);
                    print(Provider.of<StaffProvider>(context, listen: false).roleDatas![i].selected );
                  },
                leading: Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Provider.of<StaffProvider>(context, listen: false).roleDatas![i].selected! ? mainColor : Colors.white,
                      border: Border.all(color: mainColor),
                      shape: BoxShape.circle
                    ),
                  ),
                
                title: Text(
                  "${Provider.of<StaffProvider>(context, listen: false).roleDatas![i].role}",
                  style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12, color: Colors.black)
                ),
              )).toList()
            ),

            saveBtn(context)
          ],
        ),
      ),
    );
  }

  
  
   @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: appbar(context),
        backgroundColor: whiteBG,
        body: mainContainer(context),
      ),
    );
  }

}
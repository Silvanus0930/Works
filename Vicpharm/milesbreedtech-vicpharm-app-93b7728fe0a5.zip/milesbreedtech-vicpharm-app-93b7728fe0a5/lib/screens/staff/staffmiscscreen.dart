import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/customwidgets/AlternateContainer.dart';
import 'package:vicpharm_app/models/misc.dart';
import 'package:vicpharm_app/screens/activities/activitiesscreen.dart';
import 'package:vicpharm_app/screens/misc/miscprovider.dart';
import 'package:vicpharm_app/screens/staff/staffprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class StaffMiscScreen extends StatefulWidget {
  @override
  _StaffMiscScreenState createState() => _StaffMiscScreenState();
}

class _StaffMiscScreenState extends State<StaffMiscScreen> {
  final RefreshController _refreshController = RefreshController();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  var _controller = ScrollController();
  TextEditingController searchController = new TextEditingController();
  int currentPageNumber = 0;
  ActivitiesLoadMoreStatus loadMoreStatus = ActivitiesLoadMoreStatus.STABLE;

  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => Provider.of<MiscProvider>(context, listen: false).setFutureList(
      Provider.of<MiscProvider>(context, listen: false).populateStaffMiscRecords(1, Provider.of<StaffProvider>(context, listen: false).selectedStaff!.sId!))
      
    );
  }

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Staff Misc. Event Records",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 16,),
      onPressed: () => Get.back(),
    ),


  );


  bool onNotification(ScrollNotification notification) {
      if (notification is ScrollUpdateNotification) {
        if (_controller.position.maxScrollExtent > _controller.offset &&
            _controller.position.maxScrollExtent - _controller.offset <=
                50) {
          if (loadMoreStatus != null && loadMoreStatus == ActivitiesLoadMoreStatus.STABLE) {
            loadMoreStatus = ActivitiesLoadMoreStatus.LOADING;
            if(currentPageNumber != Provider.of<MiscProvider>(context, listen: false).miscTotalPage){
              currentPageNumber = currentPageNumber + 1;
            Provider.of<MiscProvider>(context, listen: false).populateStaffMiscRecords(currentPageNumber, Provider.of<StaffProvider>(context, listen: false).selectedStaff!.sId!);
            }
            
          }
        }
      }
      return true;
}
  
  Widget transferRecordBox(BuildContext context){
    return Expanded(
      child: SmartRefresher(
        controller: _refreshController,
        header: WaterDropMaterialHeader(
          backgroundColor: mainColor,
        ),
        onRefresh: (){
          //page = 1;
          //salesrecords.clear();
          //retrRecords2(page);
          //reterieveExpRecFromServer(page);
        },
        child: FutureBuilder<List<Misc>?>(
          future: Provider.of<MiscProvider>(context, listen: true).futureMisc,
          builder: (context, snapshot){
            if(snapshot.hasError){
              return AlternateContainer(text: "Error occurred retrieving data...");
            }else if (snapshot.connectionState == ConnectionState.waiting){
              return AlternateContainer(text: "Loading....");
            }
            else if(snapshot.data == null){
              return AlternateContainer(text: "No Record found.....");
            }
            else if(snapshot.connectionState == ConnectionState.done){
               return NotificationListener(
                 onNotification: onNotification,
                 child: ListView.builder(
            controller: _controller,
            itemCount: snapshot.data!.length,
            itemBuilder: (BuildContext context, index){
              return InkWell(
                  onTap: (){
                    Provider.of<MiscProvider>(context, listen: false).setSelectedMisc(snapshot.data![index]);
                    //Get.to(() => ExpirationProductDetailScreen()); 
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(top: 8, bottom: 8, left: 20, right: 20),
                    child: Container(
                      height: MediaQuery.of(context).size.height * 0.15,
                      width: MediaQuery.of(context).size.width * 0.9,
                      decoration: BoxDecoration(
                          color: Color(0x0d1c63ba),
                          borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 10.0, right: 5, left: 20),
                            child: Text("${snapshot.data![index].productDetails![0].productName}", maxLines: 1, style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(top: 1.0, right: 20, left: 20),
                            child: Divider(thickness: 2, color: Color(0xb21c63ba),),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(top: 1.0, right: 20, left: 20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                 Text( "${snapshot.data![index].productDetails!.length} were affected", style:  TextStyle(fontSize: 12, fontFamily: 'Poppinsegular')),
                                
                                Text(Jiffy(snapshot.data![index].createdAt).yMd, style:  TextStyle(fontSize: 12, fontFamily: 'Poppinsegular'))
                              ],
                            ),
                          ),

                        ],
                      ),
                    ),
                  ),
              );
            },
          ),
               );
        
            }
            else{
              return AlternateContainer(text: "Unknown error occurred. Please refresh");
            }

          },
        
        ),
      ),
    );
  }

  
  Widget mainLayer(BuildContext context) => Container(
      height: Get.height,
      width: Get.width,
      color: whiteBG,
      child: Column(
        children: [
        
          SizedBox(height: 10,),
          transferRecordBox(context),
        ],
      )

  );
  
  @override
  Widget build(BuildContext context) {
    
    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          backgroundColor: whiteBG,
          appBar: appbar(context),
          body: mainLayer(context),
          

        )
    );
  }
}
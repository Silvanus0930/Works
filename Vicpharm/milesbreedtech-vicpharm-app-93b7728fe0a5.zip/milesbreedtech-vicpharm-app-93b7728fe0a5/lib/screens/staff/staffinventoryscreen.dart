import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/customwidgets/AlternateContainer.dart';
import 'package:vicpharm_app/models/inventory.dart';
import 'package:vicpharm_app/screens/activities/activitiesscreen.dart';
import 'package:vicpharm_app/screens/inventory/inventorydetailsscreen.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/screens/staff/staffprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class StaffInventoryScreen extends StatefulWidget {
  @override
  _StaffInventoryScreenState createState() => _StaffInventoryScreenState();
}

class _StaffInventoryScreenState extends State<StaffInventoryScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final RefreshController _refreshController = RefreshController();
  ScrollController controller = ScrollController();
  ActivitiesLoadMoreStatus loadMoreStatus = ActivitiesLoadMoreStatus.STABLE;
   int currentPageNumber = 1;

  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => Provider.of<InventoryProvider>(context, listen: false).setFutureList(Provider.of<InventoryProvider>(context, listen: false).populateStaffInventory(
      1,
      Provider.of<StaffProvider>(context, listen: false).selectedStaff!.sId!
      )));
  }
  
   AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Staff Inventory Records",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold',fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Navigator.of(context).pop(),
    ),


  );

  bool onNotification(ScrollNotification notification) {
  if (notification is ScrollUpdateNotification) {
    if (controller.position.maxScrollExtent > controller.offset &&
        controller.position.maxScrollExtent - controller.offset <=
            50) {
      if (loadMoreStatus != null && loadMoreStatus == ActivitiesLoadMoreStatus.STABLE) {
        loadMoreStatus = ActivitiesLoadMoreStatus.LOADING;
        if(currentPageNumber != Provider.of<InventoryProvider>(context, listen: false).inventoryTotalPage){
          currentPageNumber = currentPageNumber + 1;
        Provider.of<InventoryProvider>(context, listen: false).populateStaffInventory(
          currentPageNumber,
          Provider.of<StaffProvider>(context, listen: false).selectedStaff!.sId!
          );
        }
        
      }
    }
  }
  return true;
}
  

   Widget mainCustomerList(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0),
      child: SmartRefresher(
        controller: _refreshController,
        header: WaterDropMaterialHeader(
          backgroundColor: mainColor,
        ),
        onRefresh: (){
          //page = 1;
          //invProducts.clear();
          //retrRecords2(page);
        },
        child: FutureBuilder<List<Inventory>?>(
          future: Provider.of<InventoryProvider>(context, listen: true).futureInventories,
          builder: (context, AsyncSnapshot<List<Inventory>?>? snapshot){
            if(snapshot!.hasError){
                return AlternateContainer(text: "Error occurred retrieving data...");
            }else if (snapshot.connectionState == ConnectionState.waiting){
                return AlternateContainer(text: "Loading....");
            }
            else if(snapshot.data == null){
              return AlternateContainer(text: "No Record found.....");
            }
            else if(snapshot.connectionState == ConnectionState.done){
              return NotificationListener(
                onNotification: onNotification,
                child: ListView.builder(
                  controller: controller,
                  physics: BouncingScrollPhysics(),
                  itemCount: snapshot.data!.length, //invProducts.length,
                  itemBuilder: (BuildContext context, index){
                  
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                      child: InkWell(
                          onTap: (){
                            Provider.of<InventoryProvider>(context, listen: false).setSelectedInventory(snapshot.data![index]);
                            Get.to(() => InventoryDetailScreen());   
                          },
                          child: Container(
                            width: Get.width * 0.95,
                            //color: Colors.deepPurple,
                            decoration: BoxDecoration(
                              color: Color(0x0d1c63ba),
                              borderRadius: BorderRadius.all(Radius.circular(20.0),),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(left: 20.0, right: 10.0, top: 5.0, bottom: 5),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                    Padding(
                                      padding: EdgeInsets.only(top: 5, right: 20, bottom: 15),
                                      child: Container(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              "${snapshot.data![index].name}",//invProducts[index] == null ? "" : invProducts[index].name ,
                                              style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12),),
                                            Text(
                                              "${snapshot.data![index].category!.length > 0 ? snapshot.data![index].category![0].name : ""}",//invProducts[index].category.isEmpty ? "" : invProducts[index].category[0].name,
                                              style: TextStyle(fontFamily: 'PoppinsSemiBold', color: grey, fontSize: 12))
                                          ],
                                        ),
                                      ),
                                    ),

                                    Padding(
                                      padding: EdgeInsets.only(top: 5, right: 20, bottom: 15),
                                      child: Container(

                                        child: Align(
                                            alignment: Alignment.center,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "Quantity",//invProducts[index].quantity.toString(),
                                                  style: TextStyle(fontFamily: 'PoppinsSemiBold', color: mvsblue, fontSize: 12,),
                                                ),
                                                   
                                                Column(
                                                  children: snapshot.data![index].quantity!.entries.map((e) => 
                                                    Text(
                                                      "${e.key}: " + "${e.value}",//invProducts[index].quantity.toString(),
                                                      style: TextStyle(fontFamily: 'PoppinsRegular', color: mvsblue, fontSize: 12,),
                                                    )
                                                  ).toList()
                                                  
                                                ),
                                              ],
                                            ),

                                        ),
                                      ),

                                    )
                                ]
                              )
                            
                            )
                          )
                      ),
                    );
                      
                
                  },
                ),
              );
        
            }
            else{
              return AlternateContainer(text: "Loading....");
            }
          }
        
        ),
      )
    );
  }

  
  Widget mainLayer(BuildContext context) => Container(
    height: MediaQuery.of(context).size.height,
    width: MediaQuery.of(context).size.width,
    color: whiteBG,
    child: Column(
      children: [
        Expanded(
          child:  mainCustomerList(context),
        ),
      ],
    ),

    //child: contentStack(context),
  );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          backgroundColor: whiteBG,
          appBar: appbar(context),
          body: mainLayer(context),
          floatingActionButton: FloatingActionButton(
            onPressed: () {
              /*Navigator.push(
                  _scaffoldKey.currentContext,
                  BouncyPageRoute(widget: AddProduct(fromEdit: false,))
              ); */


            },
            child: Icon(Icons.add,),
            backgroundColor: mainColor,
          ), 
        )
    );
  }
}
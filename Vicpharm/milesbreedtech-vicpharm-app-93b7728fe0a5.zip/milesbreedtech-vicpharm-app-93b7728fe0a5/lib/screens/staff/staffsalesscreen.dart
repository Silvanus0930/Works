import 'package:flutter/material.dart';
import 'package:flutter_money_formatter/flutter_money_formatter.dart';
import 'package:get/get.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/customwidgets/AlternateContainer.dart';
import 'package:vicpharm_app/models/salerecord.dart';
import 'package:vicpharm_app/screens/activities/activitiesscreen.dart';
import 'package:vicpharm_app/screens/sales/salesdetailsscreen.dart';
import 'package:vicpharm_app/screens/sales/salesprovider.dart';
import 'package:vicpharm_app/screens/staff/staffprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class StaffSalesScreen extends StatefulWidget {
  @override
  _StaffSalesScreenState createState() => _StaffSalesScreenState();
}

class _StaffSalesScreenState extends State<StaffSalesScreen> {
                

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final RefreshController _refreshController = RefreshController();
  final ScrollController scrollController = new ScrollController();
  ActivitiesLoadMoreStatus loadMoreStatus = ActivitiesLoadMoreStatus.STABLE;
   var _controller = ScrollController();

  final _searchController = TextEditingController();  
  int currentPageNumber = 1;

 @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => initData());
    
  }

  initData() async {
    Provider.of<SalesProvider>(context, listen: false).clearSalesList();

    Provider.of<SalesProvider>(context, listen: false).setStaffFutureList(
      Provider.of<SalesProvider>(context, listen: false).populateStaffSaleRecord(
        1,
        Provider.of<StaffProvider>(context, listen: false).selectedStaff!.sId!
      )
    );
  }

   AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Staff Sales Record",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Navigator.of(context).pop(),
    ),
  
  );


   
    bool onNotification(ScrollNotification notification) {
      if (notification is ScrollUpdateNotification) {
        if (_controller.position.maxScrollExtent > _controller.offset &&
            _controller.position.maxScrollExtent - _controller.offset <=
                50) {
          if (loadMoreStatus != null && loadMoreStatus == ActivitiesLoadMoreStatus.STABLE) {
            loadMoreStatus = ActivitiesLoadMoreStatus.LOADING;
            if(currentPageNumber != Provider.of<SalesProvider>(context, listen: false).saleRecordTotalPage){
              currentPageNumber = currentPageNumber + 1;
            Provider.of<SalesProvider>(context, listen: false).populateStaffSaleRecord(currentPageNumber, Provider.of<StaffProvider>(context, listen: false).selectedStaff!.sId!);
            }
            
          }
        }
      }
      return true;
}
  

  Widget recordBox(BuildContext context){
      return NotificationListener(
        onNotification: onNotification,
        child: FutureBuilder<List<SaleRecord>?>(
          future: Provider.of<SalesProvider>(context, listen: true).futureSaleRecord,
          builder: (context, snapshot){
            if(snapshot.hasError){
                  return AlternateContainer(text: "Error occurred retrieving data...");
              }else if (snapshot.connectionState == ConnectionState.waiting){
                  return AlternateContainer(text: "Loading....");
              }
              else if(snapshot.data == null){
                return AlternateContainer(text: "No Customer found.....");
              }
              else if(snapshot.connectionState == ConnectionState.done){
                return ListView.builder(
                          controller: _controller,
                            itemCount: snapshot.data!.length,
                            itemBuilder: (BuildContext context, index){
                              FlutterMoneyFormatter  fmf = FlutterMoneyFormatter(
                                  amount: snapshot.data![index].totalAmount,//salesrecords[index] != null ? salesrecords[index].totalAmount: 0.0,
                                  settings: MoneyFormatterSettings(
                                    symbol: "NGN",
                                    thousandSeparator: ',',
                                    decimalSeparator: '.',
                                    symbolAndNumberSeparator: ' ',
                                    fractionDigits: 2,
                                  ));
                              
                              
                              return InkWell(
                                onTap: (){
                                  Provider.of<SalesProvider>(context, listen: false).setSelectedSaleRecord(snapshot.data![index]);
                                Get.to(() => SalesDetailScreen());
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 8, bottom: 8, left: 20, right: 20),
                                  child: Container(
                                    height: Get.height * 0.2,
                                    width: Get.width * 0.9,
                                    decoration: BoxDecoration(
                                        color: Color(0x0c662d6c),
                                        borderRadius: BorderRadius.all(Radius.circular(20))
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(top: 10.0, right: 5, left: 20),
                                          child: Container(child: Text(Jiffy(snapshot.data![index].createdAt).fromNow(), maxLines: 1, overflow: TextOverflow.ellipsis, style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold'),)),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(top: 5.0, right: 20, left: 20),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Expanded(child: Text("${snapshot.data![index].productDetails![0].productName} " + "...", overflow: TextOverflow.ellipsis, style:  TextStyle(fontSize: 12, color: grey),)),
                                              Expanded(child: Text(fmf.output.symbolOnLeft, textAlign: TextAlign.right, style:  TextStyle(fontSize: 12, color: mvsblue, fontFamily: 'Roboto'),))
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(top: 1.0, right: 20, left: 20),
                                          child: Divider(thickness: 2, color: Color(0xb3662d6c),),
                                        ),

                                        Padding(
                                          padding: const EdgeInsets.only(top: 1.0, right: 20, left: 20),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text("${snapshot.data![index].productDetails!.length}".toString() + " items sold", style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular')),
                                              Text(Jiffy(snapshot.data![index].createdAt).yMd, style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'))
                                            ],
                                          ),
                                        ),

                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          );
        
              }
              else{
                return AlternateContainer(text: "Unknown error occurred. Please refresh");
              }
          },
          
        ),
      );

    }


  Widget salesRecordBox(BuildContext context){
    return Expanded(
      child: SmartRefresher(
              controller: _refreshController,
              header: WaterDropMaterialHeader(
                backgroundColor: mainColor,
              ),
              onRefresh: (){
                //page = 1;
                //salesrecords.clear();
                //retrRecords2(page);
              },
              child: recordBox(context)
            )

      );

  }
  

  Widget mainLayer(BuildContext context) => Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: whiteBG,
      child: Column(
        children: [
          SizedBox(height: 10,),
          salesRecordBox(context),
        
        ],
      )

    //child: contentStack(context),
  );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          backgroundColor: whiteBG,
          appBar: appbar(context),
          body: mainLayer(context),

        )
    );
  }
}
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/staff/createpositionscreen.dart';
import 'package:vicpharm_app/screens/staff/editstaffpositionscreen.dart';
import 'package:vicpharm_app/screens/staff/staffprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class StaffPositionsScreen extends StatefulWidget {
  StaffPositionsScreen({Key? key}) : super(key: key);

  @override
  _StaffPositionsScreenState createState() => _StaffPositionsScreenState();
}

class _StaffPositionsScreenState extends State<StaffPositionsScreen> {

  @override
  void initState() { 
    super.initState();
    Provider.of<StaffProvider>(context, listen: false).retrieveStaffPositions();
  }

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Staff Positions",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),

    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Navigator.of(context).pop(),
    ),

    
  );

  FloatingActionButton fab(BuildContext context){
    return FloatingActionButton(
      onPressed: (){
        Get.to(() => CreatePosition());
      },
      child: Icon(Icons.add, color: whiteBG,),
                backgroundColor: mainColor,
        );
  }
  
  Widget mainContainer(BuildContext context){
    return Container(
      color: whiteBG,
      width: Get.width,
      height: Get.height,      
      child: ListView.builder(
        itemCount: Provider.of<StaffProvider>(context, listen: true).managerPositions.length,
        itemBuilder: (BuildContext context, int index) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Container(
            width: Get.width,
            decoration: BoxDecoration(
              color: mainColor.withOpacity(0.3),
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: ListTile(
                onTap: (){
                  Provider.of<StaffProvider>(context, listen: false).setManagerPosition(
                    Provider.of<StaffProvider>(context, listen: false).managerPositions[index]
                  );
                  Get.to(() => EditStaffScreen());
                },
                leading: Text(
                  "${Provider.of<StaffProvider>(context, listen: true).managerPositions[index].positionName}",
                  style: TextStyle(color: Colors.black, fontSize: 12, fontFamily: 'PoppinsRegular'),
                ),
                trailing: Text(
                  "${Provider.of<StaffProvider>(context, listen: true).managerPositions[index].roles!.length} role(s)",
                  style: TextStyle(color: Colors.black, fontSize: 12, fontFamily: 'PoppinsRegular'),
                ),
              ),
            ),
          ),
        );
       },
      ),
    );
  }

  
   @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: appbar(context),
        backgroundColor: whiteBG,
        body: mainContainer(context),
        floatingActionButton: fab(context),
      ),
    );
  }

}
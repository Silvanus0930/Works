import 'dart:io';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/models/managerposition.dart';
import 'package:vicpharm_app/models/staff.dart';
import 'package:vicpharm_app/screens/staff/staffexpiryscreen.dart';
import 'package:vicpharm_app/screens/staff/staffinventoryscreen.dart';
import 'package:vicpharm_app/screens/staff/staffmiscscreen.dart';
import 'package:vicpharm_app/screens/staff/staffprovider.dart';
import 'package:vicpharm_app/screens/staff/staffreturnscreen.dart';
import 'package:vicpharm_app/screens/staff/staffsalesscreen.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class StaffDetailScreen extends StatefulWidget {
  //Staff? staff;
  StaffDetailScreen({Key? key}) : super(key: key);

  @override
  _StaffDetailScreenState createState() => _StaffDetailScreenState();
}

class _StaffDetailScreenState extends State<StaffDetailScreen> {
  TextEditingController fnameController= new TextEditingController();
  TextEditingController lnameController = new TextEditingController();
  TextEditingController phoneController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();

  @override
  initState(){
    super.initState();
    fnameController.text = Provider.of<StaffProvider>(context, listen: false).selectedStaff!.personalInfo!.firstName!;
    lnameController.text = Provider.of<StaffProvider>(context, listen: false).selectedStaff!.personalInfo!.lastName!;
    phoneController.text = Provider.of<StaffProvider>(context, listen: false).selectedStaff!.phoneNumber!;
    emailController.text = Provider.of<StaffProvider>(context, listen: false).selectedStaff!.personalInfo!.email!;
    Provider.of<StaffProvider>(context, listen: false).retrieveStaffPositions();
    
  }

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Edit Staff",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      onPressed: (){
        Navigator.of(context).pop();
      },
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
    ),
    
  );

  TextFormField fnameField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: fnameController,
    enabled: false,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.text,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.person, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "First Name",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  TextFormField lnameField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: lnameController,
    enabled: false,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.text,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,

    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.person, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Last Name",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  TextFormField phoneField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: phoneController,
    enabled: false,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.number,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,

    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.phone_in_talk, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Phone Number",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  TextFormField emailField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: emailController,
    enabled: false,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.emailAddress,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,

    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.mail, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Email Address",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );
  
  Widget saveStaffBtn(BuildContext context) => Align(
    alignment: Alignment.center,
    child: Padding(
      padding: EdgeInsets.only(top: 20.0, right: 20.0, bottom: 20.0),
      child: SizedBox(
          height: MediaQuery.of(context).size.height * 0.08,
          width: MediaQuery.of(context).size.width * 0.5,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 20),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: (){
                if(Provider.of<StaffProvider>(context, listen: false).selectedManagerPosition == null){
                  LoadingControl.showSnackBar(
                    "Ouchs!!!", 
                    "Please select a Staff Position", 
                    Icon(Icons.error, color: Colors.red,)
                  );
                  return;
                }else if(Provider.of<StaffProvider>(context, listen: false).selectedStaff == null){
                  LoadingControl.showSnackBar(
                    "Ouchs!!!", 
                    "No Staff was selected. Please rectify this.", 
                    Icon(Icons.error, color: Colors.red,)
                  );
                  return;
                }
                Provider.of<StaffProvider>(context, listen: false).changeStaffPosition();
              },

              color: mainColor,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Save",
                      style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold', color: whiteBG),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.arrow_forward_ios, size: 12, color: whiteBG)
                  ),
                ],
              ),

            ),
          )
      ),
    ),
  );

  Widget userRole(BuildContext context){
    return Padding(
      padding: EdgeInsets.only(left: 20, top: 10.0, right: 20.0),
      child: Container(
        decoration: BoxDecoration(
            color: Color(0xffecf0f1),
            borderRadius: BorderRadius.all(Radius.circular(10))
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: DropdownButton<ManagerPosition>(
            hint: Text("Select User Position",
                style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)
            ),
            value: Provider.of<StaffProvider>(context, listen: true).selectedManagerPosition,
            icon: Icon(Icons.arrow_drop_down, color: grey,),
            elevation: 10,
            style: TextStyle(color: mainColor),
            underline: Container(
              height: 1,
              color: Colors.transparent,
            ),
            onChanged: (ManagerPosition? value){
              Provider.of<StaffProvider>(context, listen: false).setManagerPosition(value!);
              
            },
            isExpanded: true,
            items: Provider.of<StaffProvider>(context, listen: true).managerPositions.map((value) {
              return DropdownMenuItem<ManagerPosition>(
                value: value,
                child: Text(value.positionName!, style: TextStyle(fontSize: 12, color: black),),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
  
  Widget buttonBarRow(BuildContext context){
    return SizedBox(
      width: Get.width,
      height: Get.height * 0.5,
      child: ListView(
        shrinkWrap: true,
        scrollDirection: Axis.vertical,
        children: [
          SizedBox(
            width: 100,
            child: ElevatedButton(
              onPressed: (){
                Get.to(() => StaffSalesScreen());
              }, 
              child: Text("Sales", style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold', color: whiteBG),)
            ),
          ),

          SizedBox(
            width: 100,
            child: ElevatedButton(
              onPressed: (){
                Get.to(() => StaffInventoryScreen());
              }, 
              child: Text("Inventory", style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold', color: whiteBG),)
            ),
          ),

          SizedBox(
            width: 100,
            child: ElevatedButton(
              onPressed: (){
                Get.to(() => StaffExpiryScreen());
              }, 
              child: Text("Expiry", style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold', color: whiteBG),)
            ),
          ),

          SizedBox(
            width: 100,
            child: ElevatedButton(
              onPressed: (){
                Get.to(() => StaffReturnScreen());
              }, 
              child: Text("Return", style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold', color: whiteBG),)
            ),
          ),

          SizedBox(
            width: 100,
            child: ElevatedButton(
              onPressed: (){
                Get.to(() => StaffMiscScreen());
              }, 
              child: Text("Misc.", style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold', color: whiteBG),)
            ),
          ),

          SizedBox(
            width: 100,
            child: ElevatedButton(
              onPressed: (){
                Provider.of<StaffProvider>(context, listen: false).activateDeactiveStaff(
                  Provider.of<StaffProvider>(context, listen: false).selectedStaff!.active! ? false : true
                );
              }, 
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(
                  Provider.of<StaffProvider>(context, listen: true).selectedStaff!.active!
                  ? Colors.red
                  : Colors.green
                )
              ),
              //Provider.of<StaffProvider>(context, listen: false)
              child: Text("${Provider.of<StaffProvider>(context, listen: true).selectedStaff!.active! ? "Deactivate" : "Activate"}", style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold', color: whiteBG),)
            ),
          ),
        ],
      ),
    );
  }

  Widget mainContainer(BuildContext context){
    return Container(
      color: whiteBG,
      width: Get.width,
      height: Get.height,      
      child: SingleChildScrollView(
        
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
              child: fnameField(context),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
              child: lnameField(context),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
              child: phoneField(context),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
              child: emailField(context),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
              child: Divider(
                color: mainColor,
                height: 5,
                thickness: 5,
              ),
            ),

            
            Padding(
              padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
              child: userRole(context),
            ),

            saveStaffBtn(context),

            Padding(
              padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
              child: Divider(
                color: mainColor,
                height: 5,
                thickness: 5,
              ),
            ),


            Padding(
              padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
              child: buttonBarRow(context),
            ),
          ],
        ),
      ),
    );
  }

  
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: appbar(context),
        backgroundColor: whiteBG,
        body: mainContainer(context)
      ),
    );
  }
}
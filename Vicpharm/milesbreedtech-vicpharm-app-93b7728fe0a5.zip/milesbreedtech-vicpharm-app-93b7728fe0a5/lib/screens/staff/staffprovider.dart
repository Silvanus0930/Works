import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/models/managerposition.dart';
import 'package:vicpharm_app/models/staff.dart';
import 'package:vicpharm_app/utils/httpservice.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';

class StaffProvider with ChangeNotifier {
  final HttpService _httpService = new HttpService();
  List<Staff> _staffs = [];
  Future<List<Staff>?>? _futureStaff;
  Staff? _selectedStaff;
  List<ManagerPosition> _managerPositions = [];
  ManagerPosition? _selectedManagerPosition;
  List<String>? _staffRoles = [];
  List<RoleData>? _roleDatas = [];
  RefreshController _refreshController = RefreshController();

  RefreshController get refreshController => _refreshController;

  List<RoleData>? get roleDatas => _roleDatas; 
  List<String>? get staffRoles => _staffRoles;
  late int? _staffsTotalPage;
  List<Staff> get staffs => _staffs;
  Staff? get selectedStaff => _selectedStaff;
  int? get staffsTotalPage =>  _staffsTotalPage;
  List<ManagerPosition> get managerPositions => _managerPositions;
  ManagerPosition? get selectedManagerPosition => _selectedManagerPosition;
  Future<List<Staff>?>? get futureStaff => _futureStaff;

  setRoleData(){
    _roleDatas!.clear();
    for (var i = 0; i < _staffRoles!.length; i++) {
      RoleData rd = RoleData(
        role: _staffRoles![i],
      );
      if(_selectedManagerPosition!.roles != null){
        for (var j = 0; j < _selectedManagerPosition!.roles!.length; j++) {
        if(_selectedManagerPosition!.roles![j] == _staffRoles![i]){
          rd.selected = true;
        }
      }
      
      }
      
      _roleDatas!.add(rd);
    }
    
  }

  checkSelectedRoles(int i){
    _roleDatas![i].selected = _roleDatas![i].selected! ? false : true;
    //_roleDatas![i].selected = selected;
    notifyListeners();
    
  }

  setFutureList(Future<List<Staff>?>? st){
    _futureStaff = st;
    notifyListeners();
  }

  setSelectedStaff(Staff? staff){
    if(staff != null){
      _selectedStaff = staff;
    }
  }

  setManagerPosition(ManagerPosition mpp){
    //if(mpp != null){
      _selectedManagerPosition = mpp;
      notifyListeners();
    //}
  }

  Future<List<Staff>?> populateStaffs(int page) async{
    var data = await retrieveStaffs(page);
    if(data == null){
      return null;
    }
    print("staff length: ${data.length}" );
    _staffs.clear();
    for(var i = 0; i < data.length; i++){
        final Staff acti = Staff.fromJson(data[i]); 
        _staffs.add(acti);
        
    }
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _staffs;
  }

  Future<List<Staff>?> populateSearchStaff(String query) async{
    var data = await searchStaff(query);
    if(data == null){
      return null;
    }
    print("staff length: ${data.length}" );
    _staffs.clear();
    print("staff length:2 ${_staffs.length}" );
    for(var i = 0; i < data.length; i++){
        final Staff acti = Staff.fromJson(data[i]); 
        _staffs.add(acti);
    }
    //_futureStaff = _staffs as Future<List<Staff>>;
    _refreshController.loadComplete();
    return _staffs;
  }


  Future<List<dynamic>?> retrieveStaffs(int page) async{
    
    final response = await _httpService.getStaffsRequest(page);

    if(response == null){
      
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 201){     
      
      var data = payload["staffs"];    
      _staffsTotalPage = (payload['totalItems']/50).ceil();  
      
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  retrieveStaffPositions() async{
    LoadingControl.showLoading();
    final response = await _httpService.getStaffPositionsRequest();

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 201){     
      
      var data = payload["ManagersPosition"];   
      _managerPositions.clear(); 
      for (var i = 0; i < data.length; i++) {
        try {
          ManagerPosition mp = ManagerPosition.fromJson(data[i]);
          _managerPositions.add(mp);
          if(mp.sId == _selectedStaff!.positionId!.sId){
            setManagerPosition(mp);
            notifyListeners();
          }
        } catch (e) {
          print(e);
        }
      }  
      
      LoadingControl.dismissLoading();
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  changeStaffPosition() async{
    LoadingControl.showLoading();
    final response = await _httpService.changeStaffPositionRequest(_selectedStaff!.sId!, _selectedManagerPosition!.sId!);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Staff Position changed successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );
         
      
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  activateDeactiveStaff(bool active) async{
    LoadingControl.showLoading();
    final response = await _httpService.actiavteDeactivateStaffRequest(_selectedStaff!.sId!, active);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      _selectedStaff!.active = active;
      _staffs.forEach((st) {
        if(st.sId == _selectedStaff!.sId){
          st.active = active;
        }
       });
      LoadingControl.showSnackBar(
        "Success!!!", 
        active ? "Staff activated successfully" : "Staff deactivated successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );
         
      
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  Future<List<dynamic>?> searchStaff(String query) async{
    //LoadingControl.showLoading();
    final response = await _httpService.searchStaffRequest(query);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){  

      var data = payload['staffs'];
      return data;
       
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  retrieveRoles() async{
    LoadingControl.showLoading();
    final response = await _httpService.getAllRolesRequest();

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 201){     
      
      var data = payload["Role"];   
      _staffRoles!.clear(); 
      for (var i = 0; i < data.length; i++) {
        try {
          _staffRoles!.add(data[i]);          
          
        } catch (e) {
          print(e);
        }
        setRoleData();
      }  
      
      LoadingControl.dismissLoading();
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  
  Future<List<String>> populateSortedRoles() async{
    List<String> datas = [];
    for (var i = 0; i < _roleDatas!.length; i++) {
      if(_roleDatas![i].selected!){
        datas.add(_roleDatas![i].role!);
      }
    }

    return datas;
  }

  Future<List<String>> populateSortedRolesNew() async{
    List<String> datas = [];
    for (var i = 0; i < _roleDatas!.length; i++) {
      if(_roleDatas![i].selected!){
        datas.add(_roleDatas![i].role!);
      }
    }

    return datas;
  }

  updatePosition(String name, List<String> roles) async{
    LoadingControl.showLoading();
    //print(_selectedManagerPosition!.sId!);
    final response = await _httpService.updatePositionRequest(
      _selectedManagerPosition!.sId!, 
      roles, 
      name
    );

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Position updated successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );
         
      
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  createPosition(String name, List<String> roles) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.createPositionRequest(
      roles, 
      name
    );

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Position created successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         
      
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

}
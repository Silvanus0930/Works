import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/customwidgets/AlternateContainer.dart';
import 'package:vicpharm_app/models/staff.dart';
import 'package:vicpharm_app/screens/activities/activitiesscreen.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/screens/staff/staffdetailscreen.dart';
import 'package:vicpharm_app/screens/staff/staffpositionsscreen.dart';
import 'package:vicpharm_app/screens/staff/staffprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';
import 'package:searchfield/searchfield.dart';

class StaffScreen extends StatefulWidget {
  StaffScreen({Key? key}) : super(key: key);

  @override
  _StaffScreenState createState() => _StaffScreenState();
}

class _StaffScreenState extends State<StaffScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final RefreshController _refreshController = RefreshController();
  final ScrollController scrollController = new ScrollController();
  ActivitiesLoadMoreStatus loadMoreStatus = ActivitiesLoadMoreStatus.STABLE;

  final _searchController = TextEditingController();  
  int currentPageNumber = 1;

  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => initData());
  }

  initData() async{
    Provider.of<AuthProvider>(context, listen: false).retrieveProfile();
    Provider.of<StaffProvider>(context, listen: false).setFutureList(Provider.of<StaffProvider>(context, listen: false).populateStaffs(1));
    
  }

  @override
  void dispose() { 
    _searchController.dispose();
    super.dispose();
  }

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Staffs",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),

    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Get.offAll(LandingScreen())
    ),

    actions: [
      true ?  SizedBox(
        width: MediaQuery.of(context).size.width * 0.3,
        child: ElevatedButton(
            style: ButtonStyle(
              elevation: MaterialStateProperty.all(0),
              backgroundColor: MaterialStateProperty.all(whiteBG),
              shape: MaterialStateProperty.all(CircleBorder(side: BorderSide(width: 2, color: Colors.transparent, style: BorderStyle.none))),
            ),
            
            onPressed: (){
              Get.to(() => StaffPositionsScreen());
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.description, color: mainColor, size: 24),
                SizedBox(
                  width: 50,
                  child: Text('Edit Positions',
                    maxLines: 2,
                    style: TextStyle(color: mainColor, fontSize: 10, fontFamily: 'PoppinsSemiBold'),
                  ),
                )
              ],
            )
        ),
      ) : Container()
    ],
  );

 
  Widget mainStafflist(BuildContext context) =>
      FutureBuilder<List<Staff>?>(
        future: Provider.of<StaffProvider>(context, listen: true).futureStaff,
          //future: Provider.of<StaffProvider>(context, listen: true).populateStaffs(currentPageNumber),
          builder: (context, snapshot){
            if(snapshot.hasError){
              return AlternateContainer(text: "Error occurred retrieving data...");
            }else if (snapshot.connectionState == ConnectionState.waiting){
              return AlternateContainer(text: "Loading....");
            }
            
            else if(snapshot.connectionState == ConnectionState.done){
              return snapshot.hasData == true && snapshot.data!.length == 0 ?
              AlternateContainer(text: "No Staff found") :
              SmartRefresher(
                enablePullDown: true,
                  //scrollController: controller,
                  controller: Provider.of<StaffProvider>(context, listen: true).refreshController,
                    header: WaterDropMaterialHeader(
                      backgroundColor: mainColor,
                    ),
                    onRefresh: (){
                      Provider.of<StaffProvider>(context, listen: false).setFutureList(Provider.of<StaffProvider>(context, listen: false).populateStaffs(1));
                    },
                child: ListView.builder(
                  itemCount: snapshot.data!.length,
                    itemBuilder: (BuildContext context, index){
                    //Key kk = ValueKey("$index");
                    GlobalKey kk = GlobalKey(debugLabel: "$index");
                    String fname = (snapshot.data![index].personalInfo!.firstName != null ? snapshot.data![index].personalInfo!.firstName : "")!;
                    String lname = (snapshot.data![index].personalInfo!.lastName != null ? snapshot.data![index].personalInfo!.lastName : "")!;
                    String posit = (snapshot.data![index].positionId != null ? snapshot.data![index].positionId!.positionName : '')! ;
                      return Padding(
                        //key: kk,
                        //
                        padding: const EdgeInsets.all(8.0),
                        child: InkWell(
                          onTap: (){
                            Provider.of<StaffProvider>(context, listen: false).setSelectedStaff(snapshot.data![index]);
                            Get.to(() => StaffDetailScreen());
                          },
                          key: kk,
                          child: Container(
                                    width: MediaQuery.of(context).size.width * 0.95,
                                    //color: Colors.deepPurple,
                                    decoration: BoxDecoration(
                                      color: mainColor.withOpacity(0.3),
                                      borderRadius: BorderRadius.all(Radius.circular(20.0),),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 20.0, right: 10.0, top: 10.0),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Text(fname + " " + lname,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14),),
                                              /*Text(snapshot.data![index].personalInfo!.email!,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12),),*/
                                              Text("${posit.toUpperCase()}",
                                                  overflow: TextOverflow.ellipsis,
                                                  style: TextStyle(fontFamily: 'PoppinsSemiBold', color: mainColor, fontSize: 14))
                                            ],
                                          ),
                                          snapshot.data![index].active == true ? Icon(Icons.verified_user, size: 32, color: mvsdarkyellow,) : snapshot.data![index].active == false ? Icon(Icons.verified_user, size: 32, color: grey,) : Icon(Icons.verified_user, size: 32, color: mvsred,),
                                        ],
                                      ),
                                    ),
                                  ),
                               
                        ),
                      );

                    }
                ),
              );
            }
            else{
              return AlternateContainer(text: "Loading....");
            }
          }

      );

  Widget searchField(BuildContext context) => TextField(
    
        
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: _searchController,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.text,
        textInputAction: TextInputAction.search,
        onChanged: (String? query) async {
          if(query != null){
            if(query.isEmpty){
              Provider.of<StaffProvider>(context, listen: false).setFutureList(Provider.of<StaffProvider>(context, listen: false).populateStaffs(1));
            }else{
              Provider.of<StaffProvider>(context, listen: false).setFutureList(Provider.of<StaffProvider>(context, listen: false).populateSearchStaff(query));
              
            }
          }
        },
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            suffixIcon: Icon(Icons.search, color: Colors.grey, size: 16,),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Search for Staff here",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        

      );
  
  
  Widget mainContainer(BuildContext context){
    return Container(
      color: whiteBG,
      width: Get.width,
      height: Get.height,      
      child: Column(
        children: [
          SizedBox(
            height: Get.height * 0.1,
            width: Get.width,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: searchField(context),
            )
          ),

          Expanded(
            child: mainStafflist(context),
          )
        ],
      )
    );
  }


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: appbar(context),
        backgroundColor: whiteBG,
        body: mainContainer(context)
      ),
    );
  }
}
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/models/customer.dart';
import 'package:vicpharm_app/screens/customer/customerscreen.dart';
import 'package:vicpharm_app/utils/httpservice.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';

class CustomerProvider with ChangeNotifier {
  final HttpService _httpService = new HttpService();
  List<Customer>? _customers = [];
  Customer? _selectedCustomer;
  Future<List<Customer>?>? _futureCustomer;
  int? _customerTotalPage;
  RefreshController _refreshController = RefreshController();

  RefreshController get refreshController => _refreshController;

  List<Customer>? get customers => _customers;
  Customer? get selectedCustomer => _selectedCustomer;
  Future<List<Customer>?>? get futureCustomer => _futureCustomer;
  int? get customerTotalPage => _customerTotalPage;

  setFutureList(Future<List<Customer>?>? st){
    print("object");
    st!.then((value) {
      print(">>>>>>>>>>");
      print(value);
      print("<<<<<<<<<<<<");
    });
    print("object1");
    _futureCustomer = st;
    notifyListeners();
  }

  setSelectedCustomer(Customer cust){
    if(cust != null){
      _selectedCustomer = cust;
      print(jsonEncode(_selectedCustomer!));
    }
  }

  Future<List<Customer>?> populateCustomers(int page) async{
    var data = await retrieveCustomers(page);
    if(data == null){
      return null;
    }
    print("customer length: ${data.length}" );
    _customers!.clear();
    for(var i = 0; i < data.length; i++){
        final Customer cust = Customer.fromJson(data[i]); 
        _customers!.add(cust);
        
    }
    _refreshController.loadComplete();
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _customers;
  }

  Future<List<Customer>?> populateSearchCustomer(String query) async{
    var data = await searchCustomer(query);
    if(data == null){
      return null;
    }
    print("****************");
    print("customer length: ${data.length}" );
    _customers!.clear();
    print("staff length:2 ${_customers!.length}" );
    for(var i = 0; i < data.length; i++){
        final Customer acti = Customer.fromJson(data[i]); 
        _customers!.add(acti);
    }
    //_futureStaff = _staffs as Future<List<Staff>>;
    return _customers!;
  }

  Future<List<dynamic>?> retrieveCustomers(int page) async{
    
    final response = await _httpService.getCustomersRequest(page);

    if(response == null){
      
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){     
      
      var data = payload["customers"];    
      _customerTotalPage = (payload['totalItems']/50).ceil();  
      
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  Future<List<dynamic>?> searchCustomer(String query) async{
    //LoadingControl.showLoading();
    final response = await _httpService.searchCustomerRequest(query);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
   // print(response);
   // print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){  

      var data = payload['Customer'];
      return data;
       
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
     
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  editCustomer(String fullName, String email, String address, String gender, String age) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.editCustomerRequest(
      _selectedCustomer!.sId!,
      fullName, 
      email, 
      address, 
      gender, 
      age);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 200){   

      LoadingControl.dismissLoading(); 

      Get.offAll(CustomerScreen()); 
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Customer updated successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         
      
     // notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
   else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  addCustomer(String fullName, String phoneNumber, String email, String address, String gender, String age) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.addCustomerRequest(
      fullName,
      phoneNumber,
      email, 
      address, 
      gender, 
      age
    );

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Customer added successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         

      Get.to(() => CustomerScreen());
      
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }


}
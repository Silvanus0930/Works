
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/customwidgets/datetimefields.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/auth/loginscreen.dart';
import 'package:vicpharm_app/screens/customer/customerprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class EditCustomerScreen extends StatefulWidget {
  EditCustomerScreen({Key? key}) : super(key: key);

  @override
  _EditCustomerScreenState createState() => _EditCustomerScreenState();
}

class _EditCustomerScreenState extends State<EditCustomerScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController fnameController= new TextEditingController();
  TextEditingController phoneController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();
  TextEditingController addressController = new TextEditingController();
  TextEditingController dobController = new TextEditingController();
  List<String> genders = <String>["male", "female", "unknown"];
  String? gender;

  @override
  void initState() { 
    super.initState();
    var gg = Provider.of<CustomerProvider>(context, listen: false).selectedCustomer!.personalInfo!.gender!.isEmpty ? "unknown": Provider.of<CustomerProvider>(context, listen: false).selectedCustomer!.personalInfo!.gender;
    var email = Provider.of<CustomerProvider>(context, listen: false).selectedCustomer!.personalInfo!.email!;
    fnameController.text = Provider.of<CustomerProvider>(context, listen: false).selectedCustomer!.personalInfo!.fullName!;
    phoneController.text = Provider.of<CustomerProvider>(context, listen: false).selectedCustomer!.personalInfo!.phoneNumber!;
    emailController.text = email != null ? email : "";
    addressController.text = Provider.of<CustomerProvider>(context, listen: false).selectedCustomer!.personalInfo!.address!;
    gender = gg;
    var dob = Provider.of<CustomerProvider>(context, listen: false).selectedCustomer!.personalInfo!.age!;
    dobController.text = dob != null ? dob : "";
    checkAuth();
  }

  void checkAuth() async{
    Provider.of<AuthProvider>(context, listen: false).validateJwt().then((value)
      {
        if(value == false){
          Get.offAll(LoginScreen());
        }
      }
    );
  }

   Widget genderSelect(BuildContext context){
    return Padding(
      padding: EdgeInsets.only(left: 10, top: 20.0, right: 10.0),
      child: Container(
        decoration: BoxDecoration(
            color: Color(0xffecf0f1),
            borderRadius: BorderRadius.all(Radius.circular(10))
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: DropdownButton<String>(
            hint: Text("Select Gender",
                style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)
            ),
            value: gender,
            icon: Icon(Icons.arrow_drop_down, color: mainColor,),
            elevation: 10,
            style: TextStyle(color: mainColor),
            underline: Container(
              height: 1,
              color: Colors.transparent,
            ),
            onChanged: (String? value){
              setState(() {
                print(value);
                gender =  value;
                print(gender);
              });

            },
            isExpanded: true,
            items: genders.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value , style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }


  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Edit Customer",
      style: TextStyle(fontSize: 18, color: mainColor, fontFamily: 'PoppinsSemiBold'),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      onPressed: (){
        Navigator.of(context).pop();
      },
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
    ),
    actions: [
      FlatButton(
          color: Colors.transparent,
          shape: CircleBorder(side: BorderSide(width: 2, color: Colors.transparent, style: BorderStyle.none)),
          splashColor: mainColor.withOpacity(0.3),
          onPressed: (){
            Provider.of<CustomerProvider>(context, listen: false).editCustomer(
              fnameController.text, 
              emailController.text, 
              addressController.text, 
              gender!, 
              dobController.text);
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.save_alt, color: mainColor, size: 16),
              Text('update',
                style: TextStyle(color: mainColor, fontSize: 12),
              )
            ],
          )
      )
    ],


  );

  TextFormField fnameField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: fnameController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.text,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.person, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "First Name",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  
  TextFormField phoneField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: phoneController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.number,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.phone_in_talk, color: Colors.grey, size: 16),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Phone Number",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  TextFormField emailField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: emailController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.emailAddress,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.mail, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Email Address",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  TextFormField addressField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: addressController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.text,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.location_on, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Address",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),

    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  Widget formContainer(BuildContext context) => SingleChildScrollView(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0),
          child: fnameField(context),
        ),

        
        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0),
          child: phoneField(context),
        ),

        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0),
          child: emailField(context),
        ),

        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0),
          child: addressField(context),
        ),

        Padding(
          padding: const EdgeInsets.only(left: 10.0, top: 10.0, right: 10.0),
          child: genderSelect(context),
        ),


       Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0, bottom: 20.0),
          child: Platform.isIOS ? IosDateTimeField(label: "Date of Birth",expiryDateController: dobController,) : AndroidDateTimeField(label: "Date of Birth", expiryDateController: dobController),
        ),

      ],
    ),
  );


  Widget mainLayer(BuildContext context) => Container(
    height: MediaQuery.of(context).size.height,
    width: MediaQuery.of(context).size.width,
    child: formContainer(context),
  );


  @override
  Widget build(BuildContext context) {

    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          appBar: appbar(context),
          body: mainLayer(context),

        )
    );
  }
}
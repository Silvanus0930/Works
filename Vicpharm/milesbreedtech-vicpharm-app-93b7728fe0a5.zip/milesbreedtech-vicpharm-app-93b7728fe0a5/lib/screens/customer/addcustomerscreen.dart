
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/auth/loginscreen.dart';
import 'package:vicpharm_app/screens/customer/customerprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class AddCustomerScreen extends StatefulWidget {
  AddCustomerScreen({Key? key}) : super(key: key);

  @override
  _AddCustomerScreenState createState() => _AddCustomerScreenState();
}

class _AddCustomerScreenState extends State<AddCustomerScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController fnameController= new TextEditingController();
  TextEditingController phoneController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();
  TextEditingController addressController = new TextEditingController();
  TextEditingController dobController = new TextEditingController();
  List<String> genders = <String>["male", "female"];
  String gender = "male";

  @override
  void initState() { 
    super.initState();
    checkAuth();
  }

  void checkAuth() async{
    Provider.of<AuthProvider>(context, listen: false).validateJwt().then((value)
      {
        if(value == false){
          Get.offAll(LoginScreen());
        }
      }
    );
  }

  Widget genderSelect(BuildContext context){
    return Padding(
      padding: EdgeInsets.only(left: 20, top: 18.0, right: 20.0),
      child: Container(
        decoration: BoxDecoration(
            color: Color(0xffecf0f1),
            borderRadius: BorderRadius.all(Radius.circular(10))
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: DropdownButton<String>(
            hint: Text("Select Gender",
                style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)
            ),
            value: gender,
            icon: Icon(Icons.arrow_drop_down, color: mainColor, size: 30,),
            elevation: 10,
            style: TextStyle(color: mainColor),
            underline: Container(
              height: 1,
              color: Colors.transparent,
            ),
            onChanged: (String? value){
              setState(() {
                print(value);
                gender =  value!;
                print(gender);
              });

            },
            isExpanded: true,
            items: genders.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value , style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Add Customer",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      onPressed: (){
        Navigator.of(context).pop();
      },
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 16,),
    ),
    actions: [
      FlatButton(
          color: Colors.transparent,
          shape: CircleBorder(side: BorderSide(width: 2, color: Colors.transparent, style: BorderStyle.none)),
          splashColor: mainColor.withOpacity(0.3),
          onPressed: (){
            var authProvider = Provider.of<AuthProvider>(context, listen: false);
            String phone = authProvider.checkForCountryCode(phoneController.text);
            
            if(phone.isNotEmpty && fnameController.text.isNotEmpty){
              Provider.of<CustomerProvider>(context, listen: false).addCustomer(
              fnameController.text, 
              phoneController.text,
              emailController.text, 
              addressController.text, 
              gender, 
              dobController.text);
            }
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.save_alt, color: mainColor, size: 16),
              Text('save',
                style: TextStyle(color: mainColor, fontSize: 12),
              )
            ],
          )
      )
    ],

  );

  TextFormField fnameField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: fnameController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.text,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.person, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "First Name",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  
  TextFormField phoneField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: phoneController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.phone,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.phone_in_talk, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Phone Number",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  TextFormField emailField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: emailController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.emailAddress,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.mail, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Email Address",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  TextFormField addressField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: addressController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.text,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.person, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Address",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),

    validator: (String? value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  TextFormField dobField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: dobController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.text,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.person, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Date of Birth",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),

    validator: (String? value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );



  Widget formContainer(BuildContext context) => SingleChildScrollView(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0),
          child: fnameField(context),
        ),

        
        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0),
          child: phoneField(context),
        ),

        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0),
          child: emailField(context),
        ),

        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0),
          child: addressField(context),
        ),
        
        genderSelect(context),

        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0),
          child: dobField(context),
        ),


      ],
    ),
  );

  Widget mainLayer(BuildContext context) => Container(
    height: MediaQuery.of(context).size.height,
    width: MediaQuery.of(context).size.width,
    child: formContainer(context),
  );


  @override
  Widget build(BuildContext context) {

    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          appBar: appbar(context),
          body: mainLayer(context)
        )
    );
  }


}
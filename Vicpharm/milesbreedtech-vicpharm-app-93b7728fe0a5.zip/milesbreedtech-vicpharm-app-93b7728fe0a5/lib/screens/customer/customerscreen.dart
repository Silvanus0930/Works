import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/customwidgets/AlternateContainer.dart';
import 'package:vicpharm_app/models/customer.dart';
import 'package:vicpharm_app/screens/activities/activitiesscreen.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/auth/loginscreen.dart';
import 'package:vicpharm_app/screens/customer/addcustomerscreen.dart';
import 'package:vicpharm_app/screens/customer/customerprovider.dart';
import 'package:vicpharm_app/screens/customer/editcustomerscreen.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class CustomerScreen extends StatefulWidget {
  CustomerScreen({Key? key}) : super(key: key);

  @override
  _CustomerScreenState createState() => _CustomerScreenState();
}

class _CustomerScreenState extends State<CustomerScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  ActivitiesLoadMoreStatus loadMoreStatus = ActivitiesLoadMoreStatus.STABLE;
  ScrollController controller = ScrollController();
  final RefreshController _refreshController = RefreshController();

  final _searchController = TextEditingController();  
  int currentPageNumber = 1;

  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => 
      checkAuth()
    );
    
  }

  void checkAuth() async{
    Provider.of<AuthProvider>(context, listen: false).validateJwt().then((value)
      {
        if(value == false){
          Get.offAll(LoginScreen());
          return;
        }
        Provider.of<CustomerProvider>(context, listen: false).setFutureList(Provider.of<CustomerProvider>(context, listen: false).populateCustomers(1));
      }
    );
  }

   @override
   void dispose() { 
     _searchController.dispose();
     super.dispose();
   }
   
   AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Customers",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: (){
       Get.offAll(LandingScreen());

      },
    ),

  );

  Widget searchField(BuildContext context) => TextField(
    
        
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: _searchController,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.text,
        textInputAction: TextInputAction.search,
        onChanged: (String? query) async {
          if(query != null){
            if(query.isEmpty){
              Provider.of<CustomerProvider>(context, listen: false).setFutureList(Provider.of<CustomerProvider>(context, listen: false).populateCustomers(1));
            }else{
              Provider.of<CustomerProvider>(context, listen: false).setFutureList(Provider.of<CustomerProvider>(context, listen: false).populateSearchCustomer(query));
              
            }
          }
        },
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            suffixIcon: Icon(Icons.search, color: Colors.grey, size: 16,),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Search for Staff here",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        

      );
  
  bool onNotification(ScrollNotification notification) {
  if (notification is ScrollUpdateNotification) {
    if (controller.position.maxScrollExtent > controller.offset &&
        controller.position.maxScrollExtent - controller.offset <=
            50) {
      if (loadMoreStatus != null && loadMoreStatus == ActivitiesLoadMoreStatus.STABLE) {
        loadMoreStatus = ActivitiesLoadMoreStatus.LOADING;
        if(currentPageNumber != Provider.of<CustomerProvider>(context, listen: false).customerTotalPage){
          currentPageNumber = currentPageNumber + 1;
        Provider.of<CustomerProvider>(context, listen: false).populateCustomers(currentPageNumber);
        }
        
      }
    }
  }
  return true;
}
  

  Widget mainCustomerList(BuildContext context) {
    return FutureBuilder<List<Customer>?>(
      future: Provider.of<CustomerProvider>(context, listen: true).futureCustomer,
      builder: (context, AsyncSnapshot<List<Customer>?>? snapshot){
       print(snapshot!.hasData);
        if(snapshot.hasError){
            return AlternateContainer(text: "Error occurred retrieving data...");
        }else if (snapshot.connectionState == ConnectionState.waiting){
            return AlternateContainer(text: "Loading....");
        }
        else if(snapshot.data == null){
          return AlternateContainer(text: "No Customer found.....");
        }

        else if(snapshot.connectionState == ConnectionState.done){
          return snapshot.hasData == true && snapshot.data!.length == 0 ?
          AlternateContainer(text: "No Customer found") :

          NotificationListener(
            onNotification: onNotification,
            child: SmartRefresher(
              enablePullDown: true,
                  //scrollController: controller,
                  controller: Provider.of<CustomerProvider>(context, listen: true).refreshController,
                    header: WaterDropMaterialHeader(
                      backgroundColor: mainColor,
                    ),
                    onRefresh: (){
                      Provider.of<CustomerProvider>(context, listen: false).setFutureList(Provider.of<CustomerProvider>(context, listen: false).populateCustomers(1));
                    },
              child: ListView.builder(
                    controller: controller,
                    physics: BouncingScrollPhysics(),
                    itemCount: snapshot.data!.length,
                    itemBuilder: (BuildContext context, i){
                     
                     
                      return InkWell(
                                       onTap: (){
                                          Provider.of<CustomerProvider>(context, listen: false).setSelectedCustomer(snapshot.data![i]);
                                          Get.to(() => EditCustomerScreen());
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                          child: Container(
                                            width: MediaQuery.of(context).size.width * 0.95,
                                            //color: Colors.deepPurple,
                                            decoration: BoxDecoration(
                                              color: Color(0x0d1c63ba),
                                              borderRadius: BorderRadius.all(Radius.circular(20.0),),
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 1.0),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        width: Get.width * 0.82,
                                                        child: Text("${snapshot.data![i].fullName}".capitalize!,
                                                          //snapshot.data[index].firstName + " " + snapshot.data[index].lastName,
                                                          style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14),),
                                                      ),
                                                      Text( "${snapshot.data![i].personalInfo!.email}",
                                                        //snapshot.data[index].email != null ? snapshot.data[index].email : "",
                                                        style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12), ),
                                                      Text(
                                                        "${snapshot.data![i].personalInfo!.phoneNumber}",
                                                        //snapshot.data[index].phoneNumber != null ? snapshot.data[index].phoneNumber : "",
                                                          style: TextStyle(fontFamily: 'PoppinsSemiBold', color: mainColor, fontSize: 12))
                                                    ],
                                                  ),

                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                
                    },
                  ),
            ),
          );
    
          
        }else{
          return AlternateContainer(text: "No data returned");
        }
            
      },
    
    );
     
  }

   Widget alteContainer(String text){
    return  Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.2,
            child: Image.asset("assets/images/search.png"),
          ),
          SizedBox(height: 10,),
          Text(text, maxLines: 1, style: TextStyle(fontSize: 18,color: Colors.black,),
          ),
          SizedBox(height: 10,),
        ],
      ),
    );
  }

  Widget mainLayer(BuildContext context) => Container(
    height: MediaQuery.of(context).size.height,
    width: MediaQuery.of(context).size.width,
    color: whiteBG,
    child: Column(
      children: [

        SizedBox(
            height: Get.height * 0.1,
            width: Get.width,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: searchField(context),
            )
          ),
        
        Expanded(
          child:  mainCustomerList(context),
        ),
      ],
    ),

    //child: contentStack(context),
  );

  @override
  Widget build(BuildContext context) {

    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          backgroundColor: whiteBG,
          appBar: appbar(context),
          body: mainLayer(context),
          floatingActionButton: FloatingActionButton(
            onPressed: () {              
              Get.to(() => AddCustomerScreen());
            },
            child: Icon(Icons.add,),
            backgroundColor: mainColor,
          ),
        )
    );
  }

}
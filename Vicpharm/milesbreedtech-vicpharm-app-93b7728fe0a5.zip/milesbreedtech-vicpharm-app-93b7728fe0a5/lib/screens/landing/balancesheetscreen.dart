import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:flutter_money_formatter/flutter_money_formatter.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/landing/landingprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';
import 'package:jiffy/jiffy.dart';

class BalanceSheetScreen extends StatefulWidget {
  BalanceSheetScreen({Key? key}) : super(key: key);

  @override
  _BalanceSheetScreenState createState() => _BalanceSheetScreenState();
}

class _BalanceSheetScreenState extends State<BalanceSheetScreen> {


  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  bool darkModeOn = false;
  bool isExpenses = false;
  bool isRevenue = false;
 
  String storeCurrency = "";
  TextEditingController startDateController = new TextEditingController();
  TextEditingController endDateController = new TextEditingController();
  final format = DateFormat("yyyy-MM-dd");
  var currencyFormat = new NumberFormat.currency(locale: "en_US", symbol: " \u{020A6}");

  Widget filterFieldStart(BuildContext context) {
    return DateTimeField(
      controller: startDateController,
      style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),

          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          suffixIcon: Icon(Icons.calendar_today, color: Colors.grey, size: 16,),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
          hintText: "Start Date",
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

      format: format,
      onShowPicker: (context, currentValue) async {
        final date = await showDatePicker(
          context: context,
          firstDate: DateTime(1900),
          initialDate: currentValue ?? DateTime.now(),
          lastDate: DateTime(9100),
        );
        if (date != null) {
          /**  final time = await showTimePicker(
              context: context,
              initialTime:
              TimeOfDay.fromDateTime(currentValue ?? DateTime.now()),
              ); **/
          //print("checking biggggggggg");
          return DateTimeField.combine(date, null);
        } else {
          return currentValue;
        }
      },
    );
  }

  Widget filterFieldEnd(BuildContext context) {
    return DateTimeField(
      controller: endDateController,
      style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),

          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          suffixIcon: Icon(Icons.calendar_today, color: Colors.grey, size: 16,),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
          hintText: "End Date",
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

      format: format,
      onShowPicker: (context, currentValue) async {
        final date = await showDatePicker(
          context: context,
          firstDate: DateTime(1900),
          initialDate: currentValue ?? DateTime.now(),
          lastDate: DateTime(9100),
        );
        if (date != null) {
          /**  final time = await showTimePicker(
              context: context,
              initialTime:
              TimeOfDay.fromDateTime(currentValue ?? DateTime.now()),
              ); **/
          print("checking biggggggggg");
        if(startDateController.text.isEmpty){
              //_errorDialog(context, "Please provide start date.");
        }else{
          endDateController.text = date.toString();
         
          Provider.of<LandingProvider>(context, listen: false).populateBalanceSheet(startDateController.text, endDateController.text);
        }



          return DateTimeField.combine(date, null);
        } else {
          endDateController.text = currentValue.toString();
          return currentValue;

        }


      },
    );
  }

  
  Widget filterBox(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.12,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(child: filterFieldStart(context)),
            SizedBox(width: 10,),
            Expanded(child: filterFieldEnd(context)),
          ],
        ),
      ),
    );
  }

  Widget profitContainer(BuildContext context){
    var pp = Provider.of<LandingProvider>(context, listen: false);
    var diff = pp.totalSales! - pp.totalCost!;// - pp.totalDebt!;

    
    return Padding(
      padding: const EdgeInsets.only(top: 15, left: 20, right: 20),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.1,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: Color(0x19219653),
          borderRadius: BorderRadius.all(Radius.circular(20))
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 15, right: 15),
          child: Align(
            alignment: Alignment.centerLeft,
            child: RichText(
                      text: TextSpan(
                          text: diff > 0 ? "You have made a gain of " : "You have made a loss of ",
                          style: TextStyle(color: grey),
                          children: [
                            TextSpan(
                              text: "${currencyFormat.format(diff)}",
                              style: TextStyle(color: diff > 0 ? Colors.green : mvsred, fontFamily: 'Roboto'),
                            )
                          ]
                      ),
                    )
                  
          ),
        ),
      ),
    );
  }

  Widget divider(BuildContext context){
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
      child: Divider(
        color: grey,
        thickness: 2,
      ),
    );
  }


  Widget expsRevContainer(){
    var pp = Provider.of<LandingProvider>(context, listen: false);

    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20, bottom: 20),
      child: Container(
        height: Get.height * 0.13,
        width: Get.width,

        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            InkWell(
              onTap: (){
                setState(() {
                  isExpenses = true;
                  isRevenue = false;
                });
              },
              child: Container(
                height: MediaQuery.of(context).size.height * 0.6,
                width: MediaQuery.of(context).size.width * 0.35,

                decoration: BoxDecoration(
                  color: whiteBG,
                    border: isExpenses ?  Border.all(color: Colors.transparent) : Border.all(color: grey),
                    boxShadow: isExpenses ? [
                      BoxShadow(
                        color: grey,
                        blurRadius: 50,
                        spreadRadius: 1,
                        offset: Offset(-5, 25)
                      )
                    ] : null,
                    borderRadius: BorderRadius.all(Radius.circular(10))
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text("Cost Price", style: TextStyle(fontSize: 14, color: mvsblue),),
                    SizedBox(height: 5,),
                     Text(currencyFormat.format(pp.totalCost!), overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: grey, fontFamily: 'Roboto'),)
                    //Text(currencyFormat.format(pp.totalCost! + pp.totalDebt!), overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: grey, fontFamily: 'Roboto'),)
                  ],
                ),
              ),
            ),

            SizedBox(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width * 0.1,
                child: Container(

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container( color: Colors.black, width: 2, height: 30, ),
                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Container(
                          width: 5,
                          height: 5,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.black
                          ),
                        ),
                      ),
                      Container( color: Colors.black, width: 2, height: 30, ),
                    ],
                  ),
                ),
              ),

            InkWell(
              onTap: (){
                setState(() {
                  isExpenses = false;
                  isRevenue = true;
                });
              },
              child: Container(
                height: MediaQuery.of(context).size.height * 0.6,
                width: MediaQuery.of(context).size.width * 0.35,
                decoration: BoxDecoration(
                  color: whiteBG,
                    border: isRevenue ? Border.all(color: Colors.transparent) :  Border.all(color: grey),
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: isRevenue ? [
                    BoxShadow(
                        color: grey,
                        blurRadius: 50,
                        spreadRadius: 1,
                        offset: Offset(-5, 25)
                    )
                  ] : null,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text("Selling Price", style: TextStyle(fontSize: 14, color: mvsblue),),
                    SizedBox(height: 5,),
                    Text(currencyFormat.format(pp.totalSales), overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: grey, fontFamily: 'Roboto'),)
                  ],
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }

  Widget BSRecordBox(BuildContext context){
    return Expanded(
      child: Column(
            children: List.generate(2, (index) {
             
              String date = "";
              try{
                //date = Jiffy(data.debitSales[index].expectedDate).yMd;
              }catch(e){
                date = "";
                print(e);
              }
              //data.debitSales[index].expectedDate == null || data.debitSales[index].expectedDate.isEmpty ? "" : data.debitSales[index].expectedDate;

              FlutterMoneyFormatter  fmg = FlutterMoneyFormatter(
                  amount: 0,//data.debitSales[index].remainingAmount,// data.sumTotalSales4Sale(data.sales[index].productDetails),
                  settings: MoneyFormatterSettings(
                    symbol: storeCurrency,
                    thousandSeparator: ',',
                    decimalSeparator: '.',
                    symbolAndNumberSeparator: ' ',
                    fractionDigits: 2,
                  ));
              MoneyFormatterOutput  fog = fmg.output;
              return InkWell(
                child: Padding(
                  padding: const EdgeInsets.only(top: 8, bottom: 8, left: 20, right: 20),
                  child: Container(
                    height: MediaQuery.of(context).size.height * 0.15,
                    width: MediaQuery.of(context).size.width * 0.9,
                    decoration: BoxDecoration(
                        color: Color(0x0d1c63ba),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 10.0, right: 20, left: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.5,
                                child: Text(fog.symbolOnLeft + ", ...", overflow: TextOverflow.ellipsis, style:  TextStyle(color: grey, fontSize: 12, fontFamily: 'Roboto'),),
                              ),
                              Expanded(child: Text("ED: " + date , overflow: TextOverflow.ellipsis, style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular', color: mvsblue),)),

                            ],
                          ),
                        ),

                        Padding(
                          padding: const EdgeInsets.only(top: 1.0, right: 20, left: 20),
                          child: Divider(thickness: 2, color: Color(0xb21c63ba),),
                        ),

                        Padding(
                          padding: const EdgeInsets.only(top: 1.0, right: 20, left: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              //Text("Date: " + Jiffy(data.debitSales[index].createdAt).yMMMMd, style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular')),
                              Text("Date: " + "2000/18/08", style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular')),
                            ],
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
              );
            }),
          )

    );
  }


Widget mainContainer(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Column(
            children: [
              filterBox(context),
              profitContainer(context),
              divider(context),
              expsRevContainer(),
              //BSRecordBox(context)
            ],
          ),

      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        key: _scaffoldKey,
        body: mainContainer(context),
      ),
    );
  }
}



 
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class LowStockScreen extends StatelessWidget {

  Widget lowStockData(BuildContext context){
    var dData = Provider.of<AuthProvider>(context, listen: false).lowStock;
    return Column(
        children: List.generate(dData!.length, (i) => 
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Container(
              decoration: BoxDecoration(
                color: Color(0xffe0d5e2),
                border: Border.all(color: mainColor),
                borderRadius: BorderRadius.all(Radius.circular(10))
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: 100,
                          child: Text("${dData[i]['name']}".capitalizeFirst!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: mainColor, fontSize: 12, fontFamily: 'PoppinsSemiBold'),)),
                        Container(
                          width: Get.width * 0.55,
                          decoration: BoxDecoration(
                            color: Color(0xff80005C),
                            borderRadius: BorderRadius.all(Radius.circular(5))
                          ),
                          padding: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                            Text("Quantity", style: TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
                            Text("Reorder Limit", style: TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'PoppinsSemiBold'),)
                          ],),
                        )
                      ],
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          //mainAxisAlignment: MainAxisAlignment.start,
                          children: dData[i]['quantity'].entries.map<Widget>((e)  {
                            return e.key.toString().toLowerCase().contains("updated")
                            ? Container()
                            : Padding(
                              padding: const EdgeInsets.only(right: 10),
                              child: Text("${e.key}".capitalizeFirst!, textAlign: TextAlign.center, style: TextStyle(height: 1.5, fontSize: 12, fontFamily: 'Roboto'),),
                            );
                          }).toList(),
                        ),

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: dData[i]['quantity'].entries.map<Widget>((e)  {
                            return e.key.toString().toLowerCase().contains("updated")
                            ? Container()
                            : Text("${e.value}", style: TextStyle( height: 1.5, color: mainColor, fontSize: 12, fontFamily: 'Roboto'),);
                          }).toList(),
                        ),

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: dData[i]['reOrderLimit'].entries.map<Widget>((e)  {
                            return e.key.toString().toLowerCase().contains("updated")
                            ? Container() 
                            : Padding(
                              padding: const EdgeInsets.only(right: 10),
                              child: Text("${e.value}", style: TextStyle(height: 1.5, color: mainColor, fontSize: 12, fontFamily: 'Roboto'),),
                            );
                          }).toList(),
                        ),
                      ],
                    )

                  ],
                ),
              ),
            ),
          ),
        ),
      );
    
  }
  
   AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Low Stock Products",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Get.offAll(LandingScreen()),
    ),
  
  );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: appbar(context),
        body: SingleChildScrollView(child: lowStockData(context))
      ),
    );
  }
}
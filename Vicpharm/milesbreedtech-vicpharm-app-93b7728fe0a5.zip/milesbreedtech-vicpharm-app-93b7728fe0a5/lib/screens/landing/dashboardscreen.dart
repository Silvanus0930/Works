import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_money_formatter/flutter_money_formatter.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/main.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/auth/loginscreen.dart';
import 'package:vicpharm_app/screens/landing/lowstockscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class DashBoardScreen extends StatefulWidget {
  DashBoardScreen({Key? key}) : super(key: key);

  @override
  _DashBoardScreenState createState() => _DashBoardScreenState();
}

class _DashBoardScreenState extends State<DashBoardScreen> {
   final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
   var currencyFormat = new NumberFormat.currency(locale: "en_US", symbol: "\u{020A6} ");

   @override
   void initState() { 
     super.initState();
     _requestPermissions();
    //_configureDidReceiveLocalNotificationSubject();
    _configureSelectNotificationSubject();
   }

   @override
   void dispose() { 
      didReceiveLocalNotificationSubject.close();
      selectNotificationSubject.close();
      super.dispose();
   }

    void _requestPermissions() {
      flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(
          alert: true,
          badge: true,
          sound: true,
        ); 
    }

    void _configureSelectNotificationSubject() {
      selectNotificationSubject.stream.listen((String? payload) async {
        await Get.to(LoginScreen());
      });
    }

    
    Widget noStaff(BuildContext context){
    return Container(
      width: MediaQuery.of(context).size.width * 0.8,
      height: MediaQuery.of(context).size.height * 0.1,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white),
        color: Colors.white.withAlpha(100),
        borderRadius: BorderRadius.only(topRight: Radius.circular(20), topLeft: Radius.circular(20), bottomLeft: Radius.circular(20),),
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Staff & Business Owner",
              maxLines: 1,
              style:  TextStyle(color: Colors.white, fontFamily: 'PoppinsBold', fontSize: 12),
            ),

            Text(
              "${Provider.of<AuthProvider>(context, listen: true).staff}", //data.numOfStaff.toString(),
              maxLines: 1,
              style:  TextStyle(color: Colors.white, fontFamily: 'PoppinsBold', fontSize: 14),
            )
          ],
        ),
      ),
    );
  }


   Widget noCustomers(BuildContext context){
    return Container(
      width: Get.width * 0.8,
      height: Get.height * 0.1,
      decoration: BoxDecoration(
        color: Color(0xff80005C),
        borderRadius: BorderRadius.only(topRight: Radius.circular(20), topLeft: Radius.circular(20), bottomRight: Radius.circular(20),),
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            RichText(
              text: TextSpan(
                  text: 'N',
            style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.white),
                children: [
                  TextSpan(
                    text: 'o',
                    style: TextStyle(decoration: TextDecoration.underline, fontFamily: 'PoppinsSemiBold', fontSize: 14, color: Colors.white)
                  ),

                  TextSpan(
                    text: ' of Customers',
                    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14, color: Colors.white),
                  )
                ]
              ),

              //style: TextStyle(fontSize: 14, color: whiteBG),
              //maxLines: 1,
            ),
            Text(
              "${Provider.of<AuthProvider>(context, listen: true).customer}",//data.numOfCustomers.toString(),
              maxLines: 1,
              style:  TextStyle(color: whiteBG, fontFamily: 'PoppinsBold', fontSize: 18),
            )
          ],
        ),
      ),
    );
  }


    Widget customerContainer(BuildContext context){
    return Container(
      width: Get.width,
      //height: Get.height * 0.48,
      //color: Colors.red,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          noCustomers(context),
          SizedBox(height: 10,),
          noStaff(context),
          SizedBox(height: 10,),
          lowStockBtn(),
        ],
      ),
    );
  }

   Widget itemsSockContainer(BuildContext context){
    print("inside blue container");
    return Material(
      elevation: 5,
      borderRadius: BorderRadius.only(topRight: Radius.circular(20), topLeft: Radius.circular(20), bottomRight: Radius.circular(20),),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.45,
        height: MediaQuery.of(context).size.height * 0.48,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(topRight: Radius.circular(20), topLeft: Radius.circular(20), bottomRight: Radius.circular(20),),
          color: whiteBG
        ),

        child: Padding(
          padding: const EdgeInsets.only(left: 20),
          child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  //SizedBox(height: 50,),
                  Text(
                    "Items Stocks",
                    maxLines: 1,
                    style:  TextStyle(color: Color(0xff333333), fontFamily: 'PoppinsBold', fontSize: 16),
                  ),
                  SizedBox(height: 20,),
                  Text(
                    "Total Stocks",
                    maxLines: 1,
                    style:  TextStyle(color: Color(0xff219653), fontFamily: 'PoppinsBold', fontSize: 14),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "4",//data.totalStock.toString(),
                    maxLines: 1,
                    style:  TextStyle(color: Color(0xff4f4f4f), fontFamily: 'PoppinsBold', fontSize: 18),
                  ),
                  SizedBox(height: 15,),
                  Text(
                    "Low Stocks",
                    maxLines: 1,
                    style:  TextStyle(color: Color(0xffdb1515), fontFamily: 'PoppinsBold', fontSize: 14),
                  ),
                  SizedBox(height: 5,),
                  Text(
                    "4",//data.lowStock.toString(),
                    maxLines: 1,
                    style:  TextStyle(color: Color(0xff4f4f4f), fontFamily: 'PoppinsBold', fontSize: 18),
                  ),
                ],
              )
            
        ),

      ),
    );
  }

   Widget stackContainer(BuildContext context){
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.35,
      child: Container(
        //color: Colors.red,
        child: Container(
                //height: Get.height * 0.3,
                width: Get.width,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                    color: mainColor
                ),
                child: Column(
                  children: [
                    

                      SizedBox(height: 10,),

                      customerContainer(context),
            
                  ],
                ),
              ),

            
      ),
    );
  }

  Widget TopSellingData(){
    var dData = Provider.of<AuthProvider>(context, listen: true).topSelling;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Stack(
        children: [
          
          
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Container(
              decoration: BoxDecoration(
                    border: Border.all(color: mainColor),
                    borderRadius: BorderRadius.all(Radius.circular(10))
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                
                child: Container(
                  width: Get.width,
                  
                  child: Column(
                    children: List.generate(dData!.length, (i) => 
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xffe0d5e2),
                            borderRadius: BorderRadius.all(Radius.circular(10))
                          ),
                          child: ListTile(
                            title: Text("${dData[i]['productName']}".capitalizeFirst!, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.black, fontSize: 12, fontFamily: 'PoppinsRegular'),),
                            trailing: Text("${currencyFormat.format(dData[i]['TotalSales'] != null ? dData[i]['TotalSales'].toDouble() : 0.0)}", style: TextStyle(color: mainColor, fontSize: 12, fontFamily: 'Roboto', fontWeight: FontWeight.bold),),
                            
                          ),
                        ),
                      )
                    ),
                  ),
                ),
              ),
            ),
          ),
        
          Align(
            alignment: Alignment.topCenter,            
            child: Container(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text("Top Selling Products", style: TextStyle(fontSize: 14, fontFamily: 'PoppinsSemiBold'),),
              ))

          ),
        ],
      ),
    );
  }

  Widget TotalStockData(){
    var dData = Provider.of<AuthProvider>(context, listen: true).totalStock;
    return Container(
      width: Get.width,
      
      child: Column(
        children: List.generate(dData!.length, (i) => 
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Container(
              decoration: BoxDecoration(
                color: Color(0xffe0d5e2),
                border: Border.all(color: mainColor),
                borderRadius: BorderRadius.all(Radius.circular(10))
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: 100,
                          child: Text("${dData[i]['name']}".capitalizeFirst!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: mainColor, fontSize: 12, fontFamily: 'PoppinsSemiBold'),)),
                        Container(
                          width: Get.width * 0.55,
                          decoration: BoxDecoration(
                            color: Color(0xff80005C),
                            borderRadius: BorderRadius.all(Radius.circular(5))
                          ),
                          padding: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                            Text("Quantity", style: TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
                            Text("Selling Price", style: TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'PoppinsSemiBold'),)
                          ],),
                        )
                      ],
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          //mainAxisAlignment: MainAxisAlignment.start,
                          children: dData[i]['quantity'].entries.map<Widget>((e)  {
                            return e.key.toString().toLowerCase().contains("updated")
                            ? Container()
                            : Padding(
                              padding: const EdgeInsets.only(right: 10),
                              child: Text("${e.key}".capitalizeFirst!, textAlign: TextAlign.center, style: TextStyle(height: 1.5, fontSize: 12, fontFamily: 'Roboto'),),
                            );
                          }).toList(),
                        ),

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: dData[i]['quantity'].entries.map<Widget>((e)  {
                            return e.key.toString().toLowerCase().contains("updated")
                            ? Container()
                            : Text("${e.value}", style: TextStyle( height: 1.5, color: mainColor, fontSize: 12, fontFamily: 'Roboto'),);
                          }).toList(),
                        ),

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: dData[i]['sellingPrice'].entries.map<Widget>((e)  {
                            return e.key.toString().toLowerCase().contains("updated")
                            ? Container() 
                            : Padding(
                              padding: const EdgeInsets.only(right: 10),
                              child: Text("${currencyFormat.format(e.value != null ? e.value : 0.0)}", style: TextStyle(height: 1.5, color: mainColor, fontSize: 12, fontFamily: 'Roboto'),),
                            );
                          }).toList(),
                        ),
                      ],
                    )

                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
  
  Widget lowStockBtn(){
    var ltProvider = Provider.of<AuthProvider>(context, listen: true).lowStock;

    return SizedBox(
      width: Get.width * 0.8,
      height: 40,
      child: ElevatedButton(
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all(Color(0xffe677f2)),
          shadowColor: MaterialStateProperty.all(Colors.grey),
          shape: MaterialStateProperty.all(RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10))
          ))
        ),
        onPressed: (){
          Get.to(() => LowStockScreen());
        },
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("${ltProvider!.length} Low Stock", style: TextStyle(color: Colors.white, fontFamily: 'PoppinsRegular'),),
            SizedBox(width: 5,),
            Icon(Icons.arrow_forward_ios, color: Colors.white, size: 14,)
          ],
        )
      ),
    );
  }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(

            children: [
              stackContainer(context),
              SizedBox(height: 20,),
              TopSellingData(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text("Total Stock - ${Provider.of<AuthProvider>(context, listen: true).noOfproduct} unique Stocks", style: TextStyle(fontSize: 14, fontFamily: 'PoppinsBold'),),
              ),
              TotalStockData(),
            ],
          ),
      ),
    );

  }
}
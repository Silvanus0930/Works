import 'dart:io';

import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/customwidgets/datetimefields.dart';
import 'package:vicpharm_app/models/profile.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';
import 'package:image_picker/image_picker.dart';

class ProfileScreen extends StatefulWidget {
  ProfileScreen({Key? key}) : super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {

  String name = "";
  String position = "";
  File? _image = File("");
  PickedFile? _imageFile;
  final ImagePicker _picker = ImagePicker();
  dynamic _pickImageError;

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController fnameController= new TextEditingController();
  TextEditingController lnameController = new TextEditingController();
  //TextEditingController mnameController = new TextEditingController();
  TextEditingController phoneController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();
  TextEditingController expiryDateController = new TextEditingController();
  TextEditingController addressController = new TextEditingController();
  final format = DateFormat("dd/MM/yyyy");
  List<String> genders = ["female", "male", "rather not say"];
  String gender = "rather not say";

  @override
  void initState() { 
    super.initState();
    var pp = Provider.of<AuthProvider>(context, listen: false).profile;
    print("print gender");
   // print(pp.personalInfo!.gender);
    String fname = (pp != null ? pp.personalInfo != null ? pp.personalInfo!.firstName : "" : "")!;
    String lname = (pp != null ? pp.personalInfo != null ? pp.personalInfo!.lastName : "" : "")!;
    name = fname + " " + lname;

    fnameController.text = (pp != null ? pp.personalInfo != null ? pp.personalInfo!.firstName : "" : "")!;
    lnameController.text = (pp != null ? pp.personalInfo != null ? pp.personalInfo!.lastName : "" : "")!;
    phoneController.text = (pp != null ? pp.personalInfo != null ? pp.personalInfo!.phoneNumber : "" : "")!;
    emailController.text = (pp != null ? pp.personalInfo != null ? pp.personalInfo!.email : "" : "")!;
    addressController.text = (pp != null ? pp.personalInfo != null ? pp.personalInfo!.address : "" : "")!;
   // gender = pp != null
   // ? pp.personalInfo != null
   //   ? pp.personalInfo!.gender!
   //   : ""
   // : "";
  
  }



  TextFormField fnameField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: fnameController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.text,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.person, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "First Name",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter first name';
      }
      return null;
    },
  );

 
  TextFormField lnameField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: lnameController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.text,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.person, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Last Name",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  TextFormField phoneField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: phoneController,
    enableSuggestions: true,
    autocorrect: true,
    enabled: false,
    keyboardType: TextInputType.number,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.phone_in_talk, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Phone Number",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  TextFormField emailField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: emailController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.emailAddress,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: Icon(Icons.email, color: Colors.grey, size: 16,),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Email Address",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
    ),
    validator: (String? value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  Widget genderSelect(BuildContext context){
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: Container(
        decoration: BoxDecoration(
            color: Color(0xffecf0f1),
            borderRadius: BorderRadius.all(Radius.circular(10))
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: DropdownButton<String>(
            hint: Text("Select Gender",
                style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)
            ),
            value: gender,
            icon: Icon(Icons.arrow_drop_down, color: mainColor,),
            elevation: 10,
            style: TextStyle(color: mainColor),
            underline: Container(
              height: 1,
              color: Colors.transparent,
            ),
            onChanged: (value){
              setState(() {
                gender = value!;
              });

            },
            isExpanded: true,
            items: genders.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value , style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }


  TextFormField addressField(BuildContext context) => TextFormField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: addressController,
    enableSuggestions: true,
    autocorrect: true,
    keyboardType: TextInputType.text,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(
      filled: true,
      fillColor: Color(0xffecf0f1),
      border: OutlineInputBorder(
        borderSide: BorderSide.none,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide.none,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide.none,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      suffixIcon: Icon(Icons.location_on, color: Colors.grey, size: 16,),
      floatingLabelBehavior: FloatingLabelBehavior.never,
      errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
      hintText: "Address",
      hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
  ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter some text';
      }
      return null;
    },
  );

  Widget saveBtn() => Padding(
    padding: EdgeInsets.only(right: 20.0, bottom: 20.0),
    child: SizedBox(
        height: Get.height * 0.08,
        width: Get.width * 0.4,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(50)),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                blurRadius: 15,
                spreadRadius: 3,
                offset: Offset(-1, 20),
              ),
            ],
          ),
          child: MaterialButton(
            elevation: 0.0,
            shape: StadiumBorder(),

            onPressed: (){
             PersonalInfo pi = PersonalInfo(
                firstName: fnameController.text,
                lastName: lnameController.text,
                phoneNumber: phoneController.text,
                email: emailController.text,
                age: expiryDateController.text,
                address: addressController.text,
                gender: "male"
              );

              File _file;

              if(_imageFile == null){
                Provider.of<AuthProvider>(context, listen: false).updateStaffProfile(
                Profile(personalInfo: pi), 
                _imageFile!
              );
              }else{
                Provider.of<AuthProvider>(context, listen: false).updateStaffProfile(
                Profile(personalInfo: pi), 
                _imageFile!
              );
              }

            
           
            },

            color: mainColor,
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Save",
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: whiteBG),
                  ),
                ),
                Align(alignment: Alignment.centerRight, child: Icon(Icons.arrow_forward_ios,size: 15, color: mainColor)),
              ],
            ),

          ),
        )
    ),
  );

  Widget expDateField(BuildContext context){
    return DateTimeField(
      controller: expiryDateController,
      style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      onChanged: (DateTime? value){
          //Provider.of<InventoryProvider>(context, listen: false).setExpDate(Jiffy(value).yMd);
        },
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),

          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          suffixIcon: Icon(Icons.calendar_today, color: Colors.grey, size: 16,),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
          hintText: "Date of Birth",
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

        format: format,
        onShowPicker: (context, currentValue) async {
          final date = await showDatePicker(
              context: context,
              firstDate: DateTime(1900),
              initialDate: currentValue ?? DateTime.now(),
              lastDate: DateTime(2100));
          if (date != null) {
         
            return DateTimeField.combine(date, null);
          } else {
            return currentValue;
          }
        },
      );
  }


  
  Widget formContainer(BuildContext context) => Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 25.0),
          child: fnameField(context),
        ),

        
        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
          child: lnameField(context),
        ),

        

        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
          child: phoneField(context),
        ),

        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
          child: emailField(context),
        ),

        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
          child: AndroidDateTimeField(expiryDateController: expiryDateController, label: "Date of Birth"),
        ),

        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 10.0, right: 20.0),
          child: addressField(context),
        ),

        genderSelect(context),

        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20.0, right: 20.0, bottom: 20),
          child: Align(
            alignment: Alignment.bottomRight,
              child: saveBtn(),
          ),
        ),

      ],
    );

  getImage(ImageSource source) async{
    try {
          final pickedFile = await _picker.getImage(
            source: source,
          );
          print(pickedFile!.path);
          Provider.of<AuthProvider>(context, listen: false).setTempProfilePic(pickedFile.path);
          setState(() {
            _imageFile = pickedFile;
          });

        } catch (e) {
          print(e);
          setState(() {
            _pickImageError = e;
          });
        }
  }
  
  Widget profilePicContainer(BuildContext context){
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(

          child: Stack(
            children: [
              Provider.of<AuthProvider>(context, listen: false).profile == null || Provider.of<AuthProvider>(context, listen: false).profile.personalInfo!.profileImage == null
              ? CircleAvatar(
                radius: 100,
                backgroundImage: NetworkImage("https://img2.pngio.com/united-states-avatar-organization-information-png-512x512px-user-avatar-png-820_512.jpg")
              )

              : _imageFile == null 
              ? CircleAvatar(
                radius: 100,
                backgroundImage: NetworkImage("${Provider.of<AuthProvider>(context, listen: false).profile.personalInfo!.profileImage}")
              )
              :
              CircleAvatar(
                radius: 100,
                backgroundImage: FileImage(File(_imageFile!.path))
              ),
              
              
              InkWell(
                onTap: () async{
                  print("use camera");
                    await getImage(ImageSource.gallery);
                },
                child: Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: mainColor,
                      ),
                      child: Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: Icon(Icons.image_rounded, color: Colors.white, size: 16,),
                  )),
                ),
              )
            
            ],
          ),
        ),
      
    );
  }

  Widget profileDetails(){   
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 8, left: 8, right: 8),
          child: Container(
              width: MediaQuery.of(context).size.width,
              child: Text(name, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: mvsblue, fontSize: 14, fontFamily: 'PoppinsSemiBold'),)),
          //child: Text(Utils.data2UpperCase(name) ?? "", style: TextStyle(color: mvsblue, fontSize: 18, fontFamily: 'PoppinsSemiBold'),),
        ),
        
      ],
    );
  }
  
  Widget profileContainer(BuildContext context){
    return Padding(
      padding: const EdgeInsets.only(top: 30, left: 20, right: 20),
      child: Container(
        child: Row(
          children: [
            SizedBox(
                width: Get.width * 0.3,
                height: Get.height * 0.15,
                child: profilePicContainer(context)),
                Expanded(child: profileDetails())
          ],
        ),
      ),
    );
  }
  
  
  Widget bodyContainer(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Container(
        color: whiteBG,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            profileContainer(context),
            formContainer(context)
          ],
        ),
      ),
    );
  }

  
  Widget mainLayer(BuildContext context) => Container(
    height: Get.height * 0.8,
    width: Get.size.width,
    color: whiteBG,
    child: bodyContainer(context),
  );



  @override
  Widget build(BuildContext context) {
    return SafeArea(
       child: Scaffold(
         key: _scaffoldKey,
         body: mainLayer(context),
       ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_app_badger/flutter_app_badger.dart';

import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:package_info/package_info.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/activities/activitiesscreen.dart';
import 'package:vicpharm_app/screens/assortment/categoryscreen.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/auth/loginscreen.dart';
import 'package:vicpharm_app/screens/cart/cartscreen.dart';
import 'package:vicpharm_app/screens/customer/customerscreen.dart';
import 'package:vicpharm_app/screens/debt/debtrecordscreen.dart';
import 'package:vicpharm_app/screens/expiration/expirationproductsscreen.dart';
import 'package:vicpharm_app/screens/expiration/expiryinventoryscreen.dart';
import 'package:vicpharm_app/screens/inventory/inventoryrecordscreen.dart';
import 'package:vicpharm_app/screens/landing/balancesheetscreen.dart';
import 'package:vicpharm_app/screens/landing/dashboardscreen.dart';
import 'package:vicpharm_app/screens/landing/homescreen.dart';
import 'package:vicpharm_app/screens/landing/landingprovider.dart';
import 'package:vicpharm_app/screens/landing/profilescreen.dart';
import 'package:vicpharm_app/screens/landing/settingscreen.dart';
import 'package:vicpharm_app/screens/misc/misceventscreen.dart';
import 'package:vicpharm_app/screens/online/approvedonlineorderscreen.dart';
import 'package:vicpharm_app/screens/online/cancelledonlineordersscreen.dart';
import 'package:vicpharm_app/screens/online/issuesonlineordersscreen.dart';
import 'package:vicpharm_app/screens/online/onlineordersscreen.dart';
import 'package:vicpharm_app/screens/online/packedonlineordersscreen.dart';
import 'package:vicpharm_app/screens/online/transitonlineordersscreen.dart';
import 'package:vicpharm_app/screens/return/returnproductscreen.dart';
import 'package:vicpharm_app/screens/sales/salesrecordscreen.dart';
import 'package:vicpharm_app/screens/staff/staffscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';
import 'package:badges/badges.dart';
import 'package:getwidget/getwidget.dart';

class LandingScreen extends StatefulWidget {
  LandingScreen({Key? key}) : super(key: key);

  @override
  _LandingScreenState createState() => _LandingScreenState();
}

class _LandingScreenState extends State<LandingScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  int currentPage = 0;
  String position = "";
  final format = DateFormat("yyyy-MM-dd");

  bool _showPM = false;
  bool _showSM = false;

  List<Widget> _children = [
    //HomeScreen(), //0
    DashBoardScreen(), //0
    BalanceSheetScreen(), //1
    SettingScreen(), //2
    ProfileScreen(), //3
  ];

   PackageInfo _packageInfo = PackageInfo(
    appName: 'Unknown',
    packageName: 'Unknown',
    version: 'Unknown',
    buildNumber: 'Unknown',

  );

  @override
  void initState() { 
    super.initState();
    _initPackageInfo();
    WidgetsBinding.instance!.addPostFrameCallback((_) => initData());
    
  }
  

  initData() async{
      Provider.of<AuthProvider>(context, listen: false).retrieveProfile();
      //Provider.of<LandingProvider>(context, listen: false).setFutureList(Provider.of<LandingProvider>(context, listen: false).populateProduct(1));
      Provider.of<AuthProvider>(context, listen: false).populateDashboard();
      DateTime date = DateTime.now();
      Duration dur = Duration(days: 30);
      var startDate = format.format(date.subtract(dur));
      var endDate = format.format(date);
      Provider.of<LandingProvider>(context, listen: false).populateBalanceSheet(startDate, endDate);
      Provider.of<AuthProvider>(context, listen: false).getExpiryInventories();

      await initPlatformState();
      
  }

  

  initPlatformState() async {
    String appBadgeSupported;
    try {
      bool res = await FlutterAppBadger.isAppBadgeSupported();
      print("is badge supported:::::: ${res}");
      if (res) {
        //appBadgeSupported = 'Supported';
      } else {
        //appBadgeSupported = 'Not supported';
      }
    } on PlatformException {
      //appBadgeSupported = 'Failed to get badge support.';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) return;

    //setState(() {
      //_appBadgeSupported = appBadgeSupported;
    //});
  }
  

  Future<void> _initPackageInfo() async {
    final PackageInfo info = await PackageInfo.fromPlatform();
    setState(() {
      _packageInfo = info;
    });
  }


  void onTabTapped(int index) {
    setState(() {
      currentPage = index;
    });
  }

  String mainTitle(int index){
    if(index == 0){
      return "Dashboard";
    }else if(index == 1){
      return "Balance Sheet";
    }else if(index == 2){
      return "Settings";
    }else if(index == 3){
      return "Profile";
    }else{
      return "";
    }
  }
  
  AppBar appbar(BuildContext context) => AppBar(
    elevation: 0.0,
    centerTitle: true,
    title: Text(
      mainTitle(currentPage),
      style: TextStyle(color: whiteBG, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: mainColor,
    leading: IconButton(
        onPressed: (){
          if(!_scaffoldKey.currentState!.isDrawerOpen){
            _scaffoldKey.currentState!.openDrawer();
          }
         
        },
        icon: Icon(Icons.sort, color: whiteBG, size: 24,),
      ),
    actions: [
      
      Padding(
        padding: const EdgeInsets.only(right: 10),
        child: Badge(
          toAnimate: true,
          badgeColor: Colors.red, //Colors.green : Color(0xffbfe8ff),
          position: BadgePosition.topEnd(top: 0, end: 6),
          animationDuration: Duration(milliseconds: 300),
          animationType: BadgeAnimationType.slide,
          shape: BadgeShape.circle,
          showBadge: Provider.of<AuthProvider>(context, listen: true).expiryInventories.length > 0 ? true : false,
          badgeContent:  Padding(
            padding: const EdgeInsets.all(2.0),
            child: 
              Text(
                "${Provider.of<AuthProvider>(context, listen: true).expiryInventories.length}",
                style: TextStyle(color: Colors.white, fontSize: 12,),
              )
             ,
            ),
            child: ElevatedButton.icon(
              
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(mainColor)
              ),
              label: Text(""),
              icon: Icon(
                Icons.explicit_rounded, color: whiteBG, size: 34,),
                onPressed: Provider.of<AuthProvider>(context, listen: true).expiryInventories.length > 0 ? () {
                  print("did these happen");
                  Get.to(() => ExpiryInventoryScreen());
                } : null,
              ),
          ),
      ),
        

    ],
  

  );

  FloatingActionButton fab(){
    return FloatingActionButton(
      heroTag: "btn1",
      backgroundColor: whiteBG,
      hoverColor: mvsdarkyellow,
      hoverElevation: 10.0,
      onPressed: (){
        onTabTapped(0);
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SvgPicture.asset(
            "assets/images/svgs/items.svg",
            color: mainColor,
            height: 20,
            width: 20,
            fit: BoxFit.none,
            semanticsLabel: 'add item'
          ),

          Text(
            "Sell",
            style: TextStyle(color: mainColor, fontSize: 12, fontFamily: 'PoppinsRegular'),
          )
        ],
      ),
      elevation: 5.0,
      tooltip: "All Products",
      foregroundColor: Colors.red,
    );
  }

  BottomAppBar bottomAppBar (){
    return BottomAppBar(
                  clipBehavior: Clip.hardEdge,
                  shape: CircularNotchedRectangle(),
                  color: mainColor,
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        width: Get.width * 0.45,
                        height: Get.height * 0.13,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Expanded(
                              child: FlatButton(
                                  padding: EdgeInsets.all(0),
                                  color: Colors.transparent,
                                  shape: CircleBorder(side: BorderSide(width: 2, color: Colors.transparent, style: BorderStyle.none)),
                                  splashColor: mainColor.withOpacity(0.3),
                                  onPressed: (){
                                    onTabTapped(0);
                                  },
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SvgPicture.asset(
                                          "assets/images/svgs/dashboard.svg",
                                          color: currentPage == 0 ? Color(0xffa5deff) : whiteBG,
                                          height: 30,
                                          width: 40,
                                          fit: BoxFit.none,
                                          semanticsLabel: 'add item'
                                      ),

                                      Text('Dashboard', maxLines: 1,
                                        style: TextStyle(color: whiteBG, fontSize: 11, fontFamily: 'PoppinsRegular'),
                                      )
                                    ],
                                  )
                              ),
                            ),

                            Expanded(
                              child: FlatButton(
                                  color: Colors.transparent,
                                  shape: CircleBorder(side: BorderSide(width: 2, color: Colors.transparent, style: BorderStyle.none)),
                                  splashColor: mainColor.withOpacity(0.3),
                                  onPressed: (){
                                    onTabTapped(1);
                                  },
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SvgPicture.asset(
                                          "assets/images/svgs/income.svg",
                                          color: currentPage == 1 ? Color(0xffa5deff) : whiteBG,
                                          height: 30,
                                          width: 40,
                                          fit: BoxFit.none,
                                          semanticsLabel: 'add item'
                                      ),
                                      Text('Revenue', maxLines: 1,
                                        style: TextStyle(color: whiteBG, fontSize: 11, fontFamily: 'PoppinsRegular'),
                                      )
                                    ],
                                  )
                              ),
                            ),

                          ],
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.5,
                        height: MediaQuery.of(context).size.height * 0.08,

                        child: Padding(
                          padding: const EdgeInsets.only(left: 18),
                          child: Row(
                            children: [
                              Expanded(
                                child: FlatButton(
                                    color: Colors.transparent,
                                    shape: CircleBorder(side: BorderSide(width: 2, color: Colors.transparent, style: BorderStyle.none)),
                                    splashColor: mainColor.withOpacity(0.3),
                                    onPressed: (){
                                      onTabTapped(2);
                                    },
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        SvgPicture.asset(
                                            "assets/images/svgs/settings.svg",
                                            color: currentPage == 2 ? Color(0xffa5deff) :whiteBG,
                                            height: 30,
                                            width: 40,
                                            fit: BoxFit.none,
                                            semanticsLabel: 'add item'
                                        ),
                                        Text('Settings',
                                          style: TextStyle(color: whiteBG, fontSize: 11, fontFamily: 'PoppinsRegular'),
                                        )
                                      ],
                                    )
                                ),
                              ),

                              Expanded(
                                child: FlatButton(
                                    color: Colors.transparent,
                                    shape: CircleBorder(side: BorderSide(width: 2, color: Colors.transparent, style: BorderStyle.none)),
                                    splashColor: mainColor.withOpacity(0.3),
                                    onPressed: (){
                                      onTabTapped(3);
                                    },
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        SvgPicture.asset(
                                            "assets/images/svgs/profile.svg",
                                            color: currentPage == 3 ? Color(0xffa5deff) : whiteBG,
                                            height: 30,
                                            width: 40,
                                            fit: BoxFit.none,
                                            semanticsLabel: 'add item'
                                        ),
                                        Text('Profile',
                                          style: TextStyle(color: whiteBG, fontSize: 11, fontFamily: 'PoppinsRegular'),
                                        )
                                      ],
                                    )
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                );

          
  }

  Widget smContainer(BuildContext context){
    return Material(
      child: Container(
        color: mainColor,
        child: Column(
          children: [

            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),


            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => SalesRecordScreen());

              },
              leading: SvgPicture.asset(
                  "assets/images/svgs/sales_record.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Sales Records",
                style: TextStyle(color: whiteBG),),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),


            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => DebtRecordScreen());

              },
              leading:  SvgPicture.asset(
                  "assets/images/svgs/debit.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Debt Sale Records",
                style: TextStyle(color: whiteBG),),
            ),


          ],
        ),
      ),
    );
  }
  
  Widget pmContainer(BuildContext context){
    return Material(
      child: Container(
        color: mainColor,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),

            ListTile(
              onTap: (){
               
                Get.back(closeOverlays: true);
                Get.to(() => InventoryRecordScreen());
                /* Navigator.push(
                  _scaffoldKey.currentContext,
                  BouncyPageRoute(widget: InvRecordsPage(),
                  ),
                ); */


              },
              leading: SvgPicture.asset(
                  "assets/images/svgs/inv_record.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Inventory Records",
                style: TextStyle(color: whiteBG),),
            ),



            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),

            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => ReturnProductScreen());
                /* Navigator.push(
                  _scaffoldKey.currentContext,
                  BouncyPageRoute(widget: ReturnRecordsPage(),
                  ),
                ); */

              },
              leading:  SvgPicture.asset(
                  "assets/images/svgs/return_record.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Return Records",
                style: TextStyle(color: whiteBG),),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),

            
            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => ExpirationProductsScreen());

              },
              leading:  SvgPicture.asset(
                  "assets/images/svgs/expiration_record.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Expiration Records",
                style: TextStyle(color: whiteBG),),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),

            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => MiscEventScreen());

              },
              leading:  SvgPicture.asset(
                  "assets/images/svgs/misc.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Misc. Event Records",
                style: TextStyle(color: whiteBG),),
            ),


            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),



            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),

            ListTile(
              onTap: (){
                 Get.back(closeOverlays: true);
                Get.to(() => CategoryScreen());

              },
              leading:  SvgPicture.asset(
                  "assets/images/svgs/assortment.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Product categories",
                style: TextStyle(color: whiteBG),),
            ),



          ],
        ),
      ),
    );
  }

  Widget oomContainer(BuildContext context){
    return Material(
      child: Container(
        color: mainColor,
        child: Column(
          children: [

            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),


            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => OnlineOrdersScreen());

              },
              leading: SvgPicture.asset(
                  "assets/images/svgs/sales_record.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("All Online Orders",
                style: TextStyle(color: whiteBG),),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),


            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => ApprovedOnlineOrdersScreen());

              },
              leading:  SvgPicture.asset(
                  "assets/images/svgs/debit.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Approved Online Orders",
                style: TextStyle(color: whiteBG),),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),

            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => TransitOnlineOrdersScreen());

              },
              leading:  SvgPicture.asset(
                  "assets/images/svgs/debit.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Transit Online Orders",
                style: TextStyle(color: whiteBG),),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),


            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => PackedOnlineOrdersScreen());

              },
              leading:  SvgPicture.asset(
                  "assets/images/svgs/debit.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Packed Online Orders",
                style: TextStyle(color: whiteBG),),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),

            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => IssuesOnlineOrderScreen());

              },
              leading:  SvgPicture.asset(
                  "assets/images/svgs/debit.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Online Orders with Issues",
                style: TextStyle(color: whiteBG),),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),

            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => IssuesOnlineOrderScreen());

              },
              leading:  SvgPicture.asset(
                  "assets/images/svgs/debit.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Completed Online Orders",
                style: TextStyle(color: whiteBG),),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 18, right: 18),
              child: Divider(
                color: drawerCircles,
                height: 1,
                thickness: 2,
              ),
            ),

            ListTile(
              onTap: (){
                Get.back(closeOverlays: true);
                Get.to(() => CancelledOnlineOrdersScreen());

              },
              leading:  SvgPicture.asset(
                  "assets/images/svgs/debit.svg",
                  color: whiteBG,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),
              title: Text("Cancelled Online Orders",
                style: TextStyle(color: whiteBG),),
            ),


          ],
        ),
      ),
    );
  }

  
  Widget bodyDrawerContainer(BuildContext context){
    return Container(
      color: mainColor,
      child: Column(
        children: [
        
          SizedBox(
              height: MediaQuery.of(context).size.height * 0.08,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  
                  
                  FlatButton(
                    color: Colors.transparent,
                    child: Text(
                      "Activities",
                      style: TextStyle(decoration: TextDecoration.underline, color: whiteBG),
                    ),
                    onPressed: (){
                      Get.back();
                      Get.to(() => ActivitiesScreen());

                    },
                  )
                ],
              )
          ),

          Material(
            color: mainColor,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              //shrinkWrap: true,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 18, right: 5, top: 5),
                  child: Text("Management",
                    style: TextStyle(color: whiteBG, fontSize: 18, fontFamily: 'PoppinsSemiBold'),),
                ),

                GFAccordion(
                  expandedTitleBackgroundColor: mainColor,
                  titlePadding: EdgeInsets.zero,
                  collapsedTitleBackgroundColor: mainColor,
                  contentBackgroundColor: mainColor,
                  showAccordion: false,
                  margin: EdgeInsets.zero,
                  collapsedIcon : Icon(Icons.arrow_drop_down, color: Colors.white, size: 30,),
                  expandedIcon: Icon(Icons.arrow_drop_up, color: Colors.white, size: 30,),
                  titleChild: ListTile(
                    onTap: (){

                      setState(() {
                        _showPM = true;
                      });
                      //print(data.showPMState);
                    },
                    leading: SvgPicture.asset(
                        "assets/images/svgs/assortment.svg",
                        color: whiteBG,
                        height: 20,
                        width: 20,
                        fit: BoxFit.none,
                        semanticsLabel: 'add item'
                    ),
                    title: Text("Product Management", style: TextStyle(color: whiteBG,),),
                  ),
                  contentChild: pmContainer(context),
                ),

                GFAccordion(
                  expandedTitleBackgroundColor: mainColor,
                  titlePadding: EdgeInsets.zero,
                  collapsedTitleBackgroundColor: mainColor,
                  contentBackgroundColor: mainColor,
                  showAccordion: false,
                  margin: EdgeInsets.zero,
                  collapsedIcon : Icon(Icons.arrow_drop_down, color: Colors.white, size: 30,),
                  expandedIcon: Icon(Icons.arrow_drop_up, color: Colors.white, size: 30,),
                  titleChild: ListTile(
                    onTap: (){

                    },
                    leading: SvgPicture.asset(
                        "assets/images/svgs/salesman.svg",
                        color: whiteBG,
                        height: 20,
                        width: 20,
                        fit: BoxFit.none,
                        semanticsLabel: 'add item'
                    ),
                    title: Text("Sales Management", style: TextStyle(color: whiteBG,),),
                  ),
                  contentChild: smContainer(context),
                ),

                GFAccordion(
                  expandedTitleBackgroundColor: mainColor,
                  titlePadding: EdgeInsets.zero,
                  collapsedTitleBackgroundColor: mainColor,
                  contentBackgroundColor: mainColor,
                  showAccordion: false,
                  margin: EdgeInsets.zero,
                  collapsedIcon : Icon(Icons.arrow_drop_down, color: Colors.white, size: 30,),
                  expandedIcon: Icon(Icons.arrow_drop_up, color: Colors.white, size: 30,),
                  titleChild: ListTile(
                    onTap: (){

                    },
                    leading: SvgPicture.asset(
                        "assets/images/svgs/salesman.svg",
                        color: whiteBG,
                        height: 20,
                        width: 20,
                        fit: BoxFit.none,
                        semanticsLabel: 'online items'
                    ),
                    title: Text("Online Orders", style: TextStyle(color: whiteBG,),),
                  ),
                  contentChild: oomContainer(context),
                ),

                ListTile(
                  onTap: (){

                    Navigator.of(context).pop();
                    Get.to(() => StaffScreen());

                  },
                  leading: SvgPicture.asset(
                      "assets/images/svgs/staffman.svg",
                      color: whiteBG,
                      height: 20,
                      width: 20,
                      fit: BoxFit.none,
                      semanticsLabel: 'add item'
                  ),
                  title: Text("Staff Management", style: TextStyle(color: whiteBG,),),
                ),

            

                ListTile(
                  onTap: (){

                    Get.back();
                    Get.to(() => CustomerScreen());

                  },
                  leading: SvgPicture.asset(
                      "assets/images/svgs/cusman.svg",
                      color: whiteBG,
                      height: 20,
                      width: 20,
                      fit: BoxFit.none,
                      semanticsLabel: 'add item'
                  ),
                  title: Text("Customer Management", style: TextStyle(color: whiteBG,),),
                ),

                             
              ],
            ),
          ),

        ],
      ),
    );

  }

  Widget headContainer(BuildContext context){
    var pp = Provider.of<AuthProvider>(context, listen: false).profile;
    String fname = (pp != null ? pp.personalInfo != null ? pp.personalInfo!.firstName : "" : "")!;
    String lname = (pp != null ? pp.personalInfo != null ? pp.personalInfo!.lastName : "" : "")!;
    String name = fname + " " + lname;

    return Material(
      child: Container(
        color: whiteBG,
        height: Get.height * 0.15,
        child: Stack(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: const EdgeInsets.only(right: 16, top: 10),
                child: Column(
                  children: [
                    Text(name,
                      style: TextStyle(color: mainColor, fontSize: 12, fontFamily: 'PoppinsRegular'),
                    ),
                    Text(position != null ? position : "",
                      style: TextStyle(color: mainColor, fontSize: 12, fontFamily: 'PoppinsRegular'),
                    )
                  ],
                ),
              )
            ),

            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(left: 16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset(
                      "assets/images/small_logo.png",
                      width: 80,
                    ),
                    SizedBox(width: 10,),
                    Text("version " + _packageInfo.version == null ? "" : _packageInfo.version, style: TextStyle(fontFamily: 'PoppinsSemiBold'),)
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget logoutContainer(BuildContext context){
    return Material(
      child: Container(
        height: Get.height * 0.08,
        color: Color(0xfff2faff),
        child: ListTile(
          onTap: () {
            Get.offAll(() => LoginScreen());
            //_logoutDialog(context, "You are about to exit this platform. Are you sure?");
          },
          leading: Icon(Icons.exit_to_app, color: mainColor,),
          title: Text('Logout', style: TextStyle(color: mainColor),),
        ),
      ),
    );
  }


  Widget mainContainer(BuildContext context) {
    return ListView(
      children: [
        headContainer(context,),
        bodyDrawerContainer(context),
        logoutContainer(context)
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
       child: WillPopScope(
         onWillPop: () async => false,
         child: Scaffold(
           key: _scaffoldKey,
           appBar: appbar(context),
           drawer: Drawer(
                  child: Container(
                    width: Get.width * 0.7,
                    height: Get.height,
                    color: mainColor,
                    child: mainContainer(context),
                  ),
                ),
           body: _children[currentPage],
           //floatingActionButton: fab(),
           floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
            bottomNavigationBar: bottomAppBar()  
         ),
       )
    );
  }


}
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:bottom_sheet_x/bottom_sheet_x.dart';
import 'package:flutter_money_formatter/flutter_money_formatter.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/customwidgets/datetimefields.dart';
import 'package:vicpharm_app/screens/inventory/editproductscreen.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/screens/inventory/restockscreen.dart';
import 'package:vicpharm_app/screens/landing/landingprovider.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class AddToCartModal extends StatefulWidget {
  NavBottomSheetController? nBSC;

 AddToCartModal({Key? key, this.nBSC}) : super(key: key);

  @override
  _AddToCartModalState createState() => _AddToCartModalState();
}

class _AddToCartModalState extends State<AddToCartModal> {
  TextEditingController productQtyController = new TextEditingController();
  TextEditingController cpController = new TextEditingController();
  TextEditingController qtyController = new TextEditingController();
  TextEditingController expiryDateController = new TextEditingController();
  bool displayAC = true;

  
  
  Widget meaurementSelect(BuildContext context){
    return Padding(
      padding: EdgeInsets.only(left: 15, top: 10.0, right: 15.0),
      child: Container(
        decoration: BoxDecoration(
            color: Color(0xffecf0f1),
            borderRadius: BorderRadius.all(Radius.circular(10))
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: DropdownButton<String>(
            hint: Text("Select Unit of Measurement",
                style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)
            ),
            value: Provider.of<LandingProvider>(context, listen: true).selectedMeasurement,
            icon: Icon(Icons.arrow_drop_down, color: mainColor, size: 30,),
            elevation: 10,
            style: TextStyle(color: mainColor),
            underline: Container(
              height: 1,
              color: Colors.transparent,
            ),
            onChanged: (String? value){
              setState(() {
                print(value);
                Provider.of<LandingProvider>(context, listen: false).setSelectedMeasurement(value!);
              });

            },
            isExpanded: true,
            items: Provider.of<LandingProvider>(context, listen: true).selectedproduct!.unitOfMeasurement!.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value , style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }


  Widget itemContainer(){
    double costPrice = Provider.of<LandingProvider>(context, listen: true).selectedproduct!.costPrice!.containsKey(
      Provider.of<LandingProvider>(context, listen: true).selectedMeasurement) 
      ? Provider.of<LandingProvider>(context, listen: true).selectedproduct!.costPrice![Provider.of<LandingProvider>(context, listen: true).selectedMeasurement].toDouble()
      : 0;

    double sellPrice = Provider.of<LandingProvider>(context, listen: true).selectedproduct!.sellingPrice!.containsKey(
      Provider.of<LandingProvider>(context, listen: true).selectedMeasurement) 
      ? Provider.of<LandingProvider>(context, listen: true).selectedproduct!.sellingPrice![Provider.of<LandingProvider>(context, listen: true).selectedMeasurement].toDouble()
      : 0;

    double quantity = Provider.of<LandingProvider>(context, listen: true).selectedproduct!.quantity!.containsKey(
      Provider.of<LandingProvider>(context, listen: true).selectedMeasurement) 
      ? Provider.of<LandingProvider>(context, listen: true).selectedproduct!.quantity![Provider.of<LandingProvider>(context, listen: true).selectedMeasurement].toDouble()
      : 0;

    double totalPrice = Provider.of<LandingProvider>(context, listen: true).selectedproduct!.sellingPrice!.containsKey(
      Provider.of<LandingProvider>(context, listen: true).selectedMeasurement) 
      ? Provider.of<LandingProvider>(context, listen: true).calculateMeasurementTotal(
        (productQtyController.text.isEmpty ? 0 : double.tryParse(productQtyController.text))!, 
      sellPrice,
      Provider.of<LandingProvider>(context, listen: true).selectedMeasurement!)
      : 0;  

    FlutterMoneyFormatter  fmf = FlutterMoneyFormatter(
        amount: sellPrice,
        settings: MoneyFormatterSettings(
          symbol: "NGN",
          thousandSeparator: ',',
          decimalSeparator: '.',
          symbolAndNumberSeparator: ' ',
          fractionDigits: 2,
        ));
    MoneyFormatterOutput  fo = fmf.output;

    FlutterMoneyFormatter  totalM = FlutterMoneyFormatter(
        amount: totalPrice,
        settings: MoneyFormatterSettings(
          symbol: "NGN",
          thousandSeparator: ',',
          decimalSeparator: '.',
          symbolAndNumberSeparator: ' ',
          fractionDigits: 2,
        ));
    


    return SingleChildScrollView(
      child: Material(
        elevation: 5.0,
        color: Colors.white,
          borderRadius: BorderRadius.only(topRight: Radius.circular(35), topLeft: Radius.circular(35)),
        child: Container(
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
              color: whiteBG,
              borderRadius: BorderRadius.only(topRight: Radius.circular(35), topLeft: Radius.circular(35))
          ),

          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(
                    color: mainColor,
                    borderRadius: BorderRadius.only(topRight: Radius.circular(35), topLeft: Radius.circular(35))
                ),
                height: MediaQuery.of(context).size.height * 0.1,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      FlatButton(
                          child: Text("Edit Product", style: TextStyle( fontSize: 12, decoration: TextDecoration.underline, color: whiteBG, fontFamily: 'PoppinsRegular'),),
                          onPressed: (){        
                            //Get.back(closeOverlays: true); 
                            widget.nBSC!.close();                  
                            Get.to(() => EditProductScreen());
                          },
                          color: Colors.transparent,
                      ),

                      Expanded(child: Text(
                        "${Provider.of<LandingProvider>(context, listen: false).selectedproduct!.name}",//product.name, 
                        overflow: TextOverflow.ellipsis, maxLines: 1, style: TextStyle(color: whiteBG, fontSize: 14, fontFamily: 'PoppinsRegular'),))

                    ],
                  ),
                ),
              ),

              meaurementSelect(context),

              Padding(
                padding: const EdgeInsets.only(top: 30.0, left: 15, right: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                                       
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.2,
                      child: Text(
                        "Amount",
                        style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),
                        textAlign: TextAlign.left,
                      ),
                    ),

                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.4,
                      child: Divider(
                        color: grey,
                        height: 15,
                        thickness: 3,
                      ),
                    ),

                    SizedBox(width: 10,),

                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.25,
                      child: Container(

                        child: Text(
                          fo.symbolOnLeft,
                          style: TextStyle(fontSize: 12, fontFamily: 'Roboto'),
                          textAlign: TextAlign.right,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              
              Padding(
                padding: const EdgeInsets.only(top: 30.0, left: 15, right: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.2,
                      child: Text(
                        "Total Amount",
                        style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),
                        textAlign: TextAlign.left,
                      ),
                    ),

                    SizedBox(
                      width: Get.width * 0.4,
                      child: Divider(
                        color: grey,
                        height: 15,
                        thickness: 3,
                      ),
                    ),

                    SizedBox(width: 10,),

                    SizedBox(
                      width: Get.width * 0.25,
                      child: Container(

                        child: Text(
                          "${totalM.output.symbolOnLeft}",
                          //Category.fromJson(json.decode(product.category)).name,
                          //product.category,
                          //"category",//c.name,
                          style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),
                          textAlign: TextAlign.right,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              
              Padding(
                padding: const EdgeInsets.only(top: 30.0, left: 15, right: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.2,
                      child: Text(
                        "Stock",
                        style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),
                        textAlign: TextAlign.left,
                      ),
                    ),

                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.4,
                      child: Divider(
                        color: grey,
                        height: 15,
                        thickness: 3,
                      ),
                    ),

                    SizedBox(width: 10,),

                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.25,
                      child: Container(

                        child:Text(
                          "${quantity} left",
                          //product.availableQuantity.toString() + " left",
                          style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),
                          textAlign: TextAlign.right,
                        ),
                      ),
                    )
                  ],
                ),
              ),

              quantity > 0
              ? Padding(
                padding: const EdgeInsets.only(top: 30.0, left: 15, right: 15),
                child: changeQtyBoard(quantity),
              ) : Container(),

              Padding(
                padding: const EdgeInsets.only(top: 10.0, left: 15, right: 15),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height * 0.15,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.4,
                        child: Container(
                          child: Align(
                              alignment: Alignment.centerLeft,
                              child: FlatButton(
                                        onPressed: (){
                                          Get.to(() => RestockScreen()); 
                                        },
                                        color: Colors.transparent,
                                        child: Text("Switch to restock", style: TextStyle(fontSize: 12, decoration: TextDecoration.underline, color: Colors.black, fontFamily: 'PoppinsRegular'),),
                                      
                                      ),
                          ),

                        ),
                      ),

                     Provider.of<LandingProvider>(context, listen: false).checkQty == true ? SizedBox(
                        width: MediaQuery.of(context).size.width * 0.45,
                        child: Container(

                          child: AddBtn(),
                        ),
                      ) : Container()
                    ],
                  ),
                ),
              ),
            ],
          ),

        ),
      ),
    );
  }

  Widget AddBtn() => Padding(
    padding: EdgeInsets.only(top: 1),
    child: SizedBox(
        height: Get.height * 0.08,
        width: Get.width * 0.4,
        child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
                ),
              ],
            ),
            child: ElevatedButton(
              style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(mainColor),
                  shape: MaterialStateProperty.all(StadiumBorder())
              ),
              
              onPressed: (){
                //widget.nBSC!.close(); 
                Get.back();
                Provider.of<LandingProvider>(context, listen: false).setCartProducts(
                  Provider.of<LandingProvider>(context, listen: false).selectedproduct!
                );
              },
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Add to cart",
                      style: TextStyle(fontSize: 12,
                          fontFamily: 'PoppinsSemiBold',
                          color:Colors.white),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.arrow_forward_ios, size: 12, color: whiteBG)
                  ),
                ],
              ),

            ),
          ),
       
    ),
  );
  
  Widget changeQtyBoard(double quantity){
    return SizedBox(
      width: Get.width,
      height: Get.height * 0.1,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          
          Expanded(
            child: Container(
              height: MediaQuery.of(context).size.height * 0.06,
              child: TextField(
                  controller: productQtyController,
                  style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
                  textAlign: TextAlign.left,
                  keyboardType: TextInputType.numberWithOptions(decimal: true),
                  onChanged: (value){
                    if(isNumeric(value)){
                      double qty = double.tryParse(value)!;
                      if(qty > quantity){
                        LoadingControl.showSnackBar(
                          "Ouchs!!!", 
                          "Invalid quantity entered. Correct quantity is ${quantity}", 
                          Icon(Icons.error, color: Colors.red,)
                        );
                        Provider.of<LandingProvider>(context, listen: false).setCheckQty(false);
                      }else{
                        Provider.of<LandingProvider>(context, listen: false).setCheckQty(true);
                        // set the quantity for this meausrement
                        Provider.of<LandingProvider>(context, listen: false).setSellQuantity(qty, Provider.of<LandingProvider>(context, listen: false).selectedMeasurement!);
                      }
                    }
                  },
                  decoration: InputDecoration(
                    hintText: "Enter Quantity",
                    hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey),
                    border: OutlineInputBorder(borderSide: BorderSide.none),
                    focusedBorder: InputBorder.none,
                    enabledBorder: InputBorder.none,

                    fillColor: fieldOffWhite,
                    filled: true,
                  ),
                ),
              
            ),
          ),
          
        ],
      ),
    );
  }

  bool isNumeric(String s) {
    if (s == null) {
      return false;
    }
    return double.tryParse(s) != null;
  }

  Widget mainContainer(Widget data){
    return data;
  }


  @override
  Widget build(BuildContext context) {
    return itemContainer();
  }
}
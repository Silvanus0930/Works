import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:vicpharm_app/models/category.dart';
import 'package:vicpharm_app/models/checkoutproduct.dart';
import 'package:vicpharm_app/models/product.dart';
import 'package:vicpharm_app/screens/cart/sellsuccessscreen.dart';
import 'package:vicpharm_app/screens/customer/customerscreen.dart';
import 'package:vicpharm_app/utils/httpservice.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';
import 'package:vicpharm_app/utils/sharedprefs.dart';

class LandingProvider with ChangeNotifier {
  final HttpService _httpService = new HttpService();
  List<Product>? _products = [];
  Product? _selectedProduct;
  Future<List<Product>?>? _futureProducts;
  int? _productTotalPage;
  String? _selectedMeasurement;
  bool? _checkQty = true;
  List<Product>? _cartProducts = [];
  double _cartTotalPrice = 0.0;
  double _cartLimitPrice = 0.0;
  CheckoutProduct? _checkoutProduct;
  double? _vatTotal = 0.0;
  double? _normalTotal = 0.0;
  double? _vat = 0.0;
  double? _totalSales = 0.0;
  double? _totalCost = 0.0;
  double? _totalDebt = 0.0;

  double? get totalDebt  => _totalDebt;
  double? get totalSales => _totalSales;
  double? get totalCost => _totalCost;
  double? get normalTotal => _normalTotal;
  double? get vat => _vat;
  double? get vatTotal => _vatTotal;
  CheckoutProduct? get checkoutProduct => _checkoutProduct;
  List<Product>? get cartProducts => _cartProducts;
  String? get selectedMeasurement => _selectedMeasurement;
  List<Product>? get products => _products;
  Product? get selectedproduct => _selectedProduct;
  Future<List<Product>?>? get futureProducts => _futureProducts;
  int? get productTotalPage => _productTotalPage;
  bool? get checkQty => _checkQty;
  double get cartTotalPrice => _cartTotalPrice;
  double get cartLimitPrice => _cartLimitPrice;

  setRestockCostPrice(Map<String, dynamic> cp){
    _selectedProduct!.costPrice = cp;
  }

  setRestockQty(Map<String, dynamic> cp){
    _selectedProduct!.quantity = cp;
  }


  Future<double?> retrieveVat() async{
    _vat = await SharedPrefs.instance.retrieveDouble("vat");
    return _vat;
  }

  calculateVatTotal(double systemVat){
    _vat = systemVat;
    double? xnormalTotal = 0.0;
    _checkoutProduct!.productDetails!.forEach((element) { 
      xnormalTotal = xnormalTotal! + element.totalAmount!;
    });

    _normalTotal = xnormalTotal! + ((_vat!/100) * xnormalTotal!);
    _vatTotal = ((_vat!/100) * xnormalTotal!);
    return _normalTotal;
  }

  setCheckQty(bool value){
    _checkQty = value;
    notifyListeners();
  }

  setCheckoutProduct(String customerId){
    List<ProductDetails> pds = [];
    Map<String, dynamic> newSellingPrice = Map<String, dynamic>();

    for (var i = 0; i < _cartProducts!.length; i++) {
      
      _cartProducts![i].sellingPrice!.forEach((key, value) { 
        
        
        print("----------------------- ${i}");
        print("${i}: _cartProducts![i].sellingPrice!: ${key}: ${value}");
        print(_cartProducts![i].sellQuantity!);
        if(_cartProducts![i].sellQuantity!.containsKey(key)){
          print(_cartProducts![i].discountType!);
          _cartProducts![i].discountType!.forEach((kl, vl) { 
            print(key);
            print("discount type value: ${vl}");
            if(vl == "none"){
              print("none1");
              //only populate if qunatity is greater than zero
              
              print(kl == key);
                if(key == kl){
                  newSellingPrice[key] = value;
                }
            }else if(vl == "single"){
              print("single");
              print(kl == key);
              if(key == kl){
                var disc = _cartProducts![i].discount![key];
                print("discounted amt: ${disc}");
                newSellingPrice[key] = value - ((disc/100) * value);
              }
              
            }else if(vl == "bulk"){
              print("bulk");
              
              if(_cartProducts![i].sellQuantity![key] >= _cartProducts![i].discountUnit![key]){
                print("bulk1");
                print(kl == key);
                if(key == kl){
                  var disc = _cartProducts![i].discount![key];
                  newSellingPrice[key] = value - ((disc/100) * value);
                }
                
              }else{
                print("bulk2");
                print(kl == key);
                if(key == kl){
                  newSellingPrice[key] = value;
                }
                
              }
            }else{
              print("none2");
              print(kl == key);
                if(key == kl){
                  newSellingPrice[key] = value;
                }
            }
          });

          
          
        }
      });      
      print("****************start");
      print(newSellingPrice);
      print("****************end");

      ProductDetails pd = ProductDetails(
        id: _cartProducts![i].sId,
        quantity: _cartProducts![i].sellQuantity,
        sellingPrice: newSellingPrice,
        totalAmount: _cartProducts![i].totalSellingPrice,
        name: _cartProducts![i].name
      );
      print(pd.name);
      pds.add(pd);
      newSellingPrice = Map<String, dynamic>();
    }
    

    CheckoutProduct cp = CheckoutProduct(
      CustomerId: customerId,
      productDetails: pds,

    );

    _checkoutProduct = cp;
   
  }

  setCartProducts(Product prod){
    
    bool check = false;
    print(prod.sId);
    if(prod != null){
      for(var i = 0; i < _cartProducts!.length; i++){
        if(_cartProducts![i].sId == prod.sId){
          check = true;
          break;
        }
      }

      if(check == false){
        prod.unitOfMeasurement!.forEach((unit) { 
          prod.sellQuantity!.entries.forEach((sq) { 
            if(sq.key == unit && sq.value == 0.0){
              prod.sellingPrice![unit] = 0.0;
            }
          });
        });
        _cartProducts!.add(prod);
        Fluttertoast.showToast(
          msg: "${prod.name} added to Cart",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: mainColor,
          textColor: Colors.white,
          fontSize: 16.0
    );
       /* LoadingControl.showSnackBar(
          "Success!!!", 
          "${prod.name} added to Cart", 
          Icon(Icons.check_box, color: Colors.green,)
        ); */
      }else{
        Fluttertoast.showToast(
          msg: "${prod.name} already in Cart",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: mvsred,
          textColor: Colors.white,
          fontSize: 16.0
    );
       
      }     
      
    }
    print(_cartProducts!.length);
    
    notifyListeners();
  }
 
  removeCartProduct(int i){
    _cartProducts!.removeAt(i);
    notifyListeners();
  }

  clearCartProducts(){
    _cartProducts!.clear();
    notifyListeners();
  }

  setFutureList(Future<List<Product>?>? st){
    _futureProducts = st;
    notifyListeners();
  }


  setSellQuantity(double qty, String measurement){
    print(qty);
    print(measurement);
    
    if(qty != null){
      
      if(_selectedProduct!.sellQuantity == null){
        _selectedProduct!.sellQuantity = Map<String, dynamic>();
      }
      _selectedProduct!.sellQuantity![measurement] = qty;
      print(_selectedProduct!.sellQuantity);
    }
    
  }

  Product updateCartTotalPrice(Product cartProd, String measureKey){
    // get the appriopate discount Type
    String dType = cartProd.discountType![measureKey];
    double discount = cartProd.discount![measureKey].toDouble();
    int discountUnit = cartProd.discountUnit![measureKey];
    double oldSellPrice = cartProd.sellingPrice![measureKey].toDouble();
    double oldTotalSellPrice = cartProd.totalSellingPrice!;
    double useTotalSellPrice = oldTotalSellPrice - oldSellPrice;
    print("----------------oooo------");
    print(oldSellPrice);
    print(oldTotalSellPrice);
    print(useTotalSellPrice);
    
    if(dType == "single"){
      print("single");
      print(cartProd.sellingPrice![measureKey].toString());
      double qty = cartProd.sellQuantity![measureKey];
      double sellPrice = cartProd.sellingPrice![measureKey].toDouble();
      
      double tt = (qty * sellPrice) - ((discount/100) * (qty * sellPrice));
      print("dd: ${tt}");
      cartProd.totalSellingPrice = useTotalSellPrice + tt;
      print(cartProd.totalSellingPrice);
    }else if(dType == "bulk"){
      print("bulk");
      double qty = cartProd.sellQuantity![measureKey];
      double sellPrice = cartProd.sellingPrice![measureKey].toDouble();
      if(qty > discountUnit ){
        double tt = (qty * sellPrice) - ((discount/100) * (qty * sellPrice));
        cartProd.totalSellingPrice = useTotalSellPrice + tt;
        
      }else{
        double tt = (qty * sellPrice);
        cartProd.totalSellingPrice = useTotalSellPrice + tt;
       
      }
      print(cartProd.totalSellingPrice);
    }else if(dType == "none"){
      print("none");
      double qty = cartProd.sellQuantity![measureKey];
      double sellPrice = cartProd.sellingPrice![measureKey].toDouble();
      double tt = (qty * sellPrice);
      cartProd.totalSellingPrice = useTotalSellPrice + tt;
      print(cartProd.totalSellingPrice);
    }else{
      double qty = cartProd.sellQuantity![measureKey];
      double sellPrice = cartProd.sellingPrice![measureKey].toDouble();
      double tt = (qty * sellPrice);
        cartProd.totalSellingPrice = useTotalSellPrice + tt;
    }
    return cartProd;
  }

  updateSellQuantityFromCart(int i, String measureKey, double qty){
    Product prod = _cartProducts![i];
    if(prod != null){
      if(prod.quantity![measureKey] >= qty){
        prod.sellQuantity![measureKey] = qty;
        //calculateMeasurementTotal(double qty, double sellingPrice, String key);
        Fluttertoast.showToast(
          msg: "${prod.name} sell quantity updated successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: mainColor,
          textColor: Colors.white,
          fontSize: 16.0
        );

        _cartProducts![i] = updateCartTotalPrice(_cartProducts![i], measureKey);
        notifyListeners();
      }else{
        Fluttertoast.showToast(
          msg: "Invalid quantity provided",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: mvsred,
          textColor: Colors.white,
          fontSize: 16.0
        );
      }
    }
    
  }

  setSelectedProduct(Product cust){
    if(cust != null){
      _selectedProduct = cust;
    }
  }

  setSelectedMeasurement(String measurement){
    if(measurement != null){
      _selectedMeasurement = measurement;
    }
    notifyListeners();
  }

  double calculateMeasurementTotal(double qty, double sellingPrice, String key){
    double tt = 0.0;
    String dtype = _selectedProduct!.discountType![key];
    double dunit = 0.0;
    double disc = 0.0;

    dtype = dtype != null || dtype.isNotEmpty ? dtype : "none";
    dunit = _selectedProduct!.discountUnit![key] != null ? _selectedProduct!.discountUnit![key].toDouble() : 0.0;
    disc = _selectedProduct!.discount![key] != null ? _selectedProduct!.discount![key].toDouble() : 0.0;
    print(qty);
    print(sellingPrice);
    print(dtype);
    print(dunit);
    if(dtype == "none"){
      tt = qty * sellingPrice;
      print("tt none: ${tt}");
    } else if(dtype == "single"){
      tt = (qty * sellingPrice) - ((disc/100) * (qty * sellingPrice));
      print("tt single: ${tt}");
    }else if(dtype == "bulk"){
      if(qty >= dunit){
        tt = (qty * sellingPrice) - ((disc/100) * (qty * sellingPrice));
        print("tt bulk: ${tt}");
        print(((disc/100) * (qty * sellingPrice)));
      }else{
        tt = qty * sellingPrice;
        print("tt bulk none: ${tt}");
      }
    }
    _selectedProduct!.totalSellingPrice = tt;
    //_selectedProduct.
    //notifyListeners();
    return tt;
  }

  double calculateTotalPriceInCart(){
    _cartTotalPrice = 0.0;
    print(_cartProducts!.length);
    for (var i = 0; i < _cartProducts!.length; i++) {
      print(cartProducts![i].totalSellingPrice!);
      double xx = cartProducts![i].totalSellingPrice!;
      _cartTotalPrice = _cartTotalPrice + xx;
    }
    return _cartTotalPrice;
  }

  double calculateLimitPriceInCart(){
    LoadingControl.showLoading();
    _cartLimitPrice = 0.0;
    for (var i = 0; i < _cartProducts!.length; i++) {
      double xx = cartProducts![i].totalLimitPrice!;
      _cartLimitPrice = _cartLimitPrice + xx;
    }
    LoadingControl.showLoading();
    return _cartLimitPrice;
  }

  double? cartProductTotalPrice(Product cProduct){
    return _selectedProduct!.totalSellingPrice;
  }

  Future<List<Product>?> populateSearchProductWithBarcode(String barcode) async{
    LoadingControl.showLoading();
    Product pp = Product();
    for (var i = 0; i < _products!.length; i++) {
      if(_products![i].barCode!.contains(barcode)){
        pp = _products![i];
        break;
      }
      
    }
    LoadingControl.dismissLoading();
    var data = await searchProduct(pp.name!);
    if(data == null){
      return null;
    }
    print("staff length: ${data.length}" );
    _products!.clear();
    print("staff length:2 ${_products!.length}" );
     for(var i = 0; i < data.length; i++){
      try {
        List<String> unitOfMeasurement = [];
        unitOfMeasurement = data[i]['unitOfMeasurement'].cast<String>();
        List<String> barCode = data[i]['barCode'].cast<String>();      
       
        
        // gather category array data
        var catData = data[i]['category'];
        List<Category> categories = [];
        for(var j = 0; j < catData.length; j++){
          try {
            Category cat = Category.fromJson(catData[j]);
            categories.add(cat);
          } catch (e) {
            print(e);
          }
        }
        print("steping2 ${i}");

        String sId = data[i]['_id'];
        String name = data[i]['name'];

        Map<String, dynamic> limitPrice = Map<String, dynamic>();
        limitPrice.addAll(data[i]['limitPrice']);
        

        Map<String, dynamic> sellingPrice = Map<String, dynamic>();
        sellingPrice.addAll(data[i]['sellingPrice']);

        Map<String, dynamic> costPrice = Map<String, dynamic>();
        costPrice.addAll(data[i]['costPrice']);

        Map<String, dynamic> quantity = Map<String, dynamic>();
        quantity.addAll(data[i]['quantity']);

        Map<String, dynamic> discountUnit = Map<String, dynamic>();
        discountUnit.addAll(data[i]['discountUnit']);

        Map<String, dynamic> discountType = Map<String, dynamic>();
        discountType.addAll(data[i]['discountType']);

        Map<String, dynamic> discount = Map<String, dynamic>();
        discount.addAll(data[i]['discount']);

        Map<String, dynamic> reOrderLimit = Map<String, dynamic>();
        reOrderLimit.addAll(data[i]['reOrderLimit']);

        String expiryDate = data[i]['expiryDate'];
        bool status =  data[i]['status'];
        String createdAt = data[i]['createdAt'];

        Product cust = Product(
          unitOfMeasurement: unitOfMeasurement,
          barCode: barCode,
          category: categories,
          sId: sId,
          name: name,
          status: status,
          limitPrice: limitPrice,
          sellingPrice: sellingPrice,
          costPrice: costPrice,
          quantity: quantity,
          sellQuantity: Map<String, dynamic>(),
          discountUnit: discountUnit,
          discountType: discountType,
          discount: discount,
          reOrderLimit: reOrderLimit,
          expiryDate: expiryDate,
          createdAt: createdAt,
        ); 

        print(cust);
        
        _products!.add(cust); 
        print(cust);
      } catch (e) {
        print(e);
      }
            
                
    }
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _products;
  }


  Future<List<Product>?> populateProduct(int page) async{
    print("step 1");
    var data = await getSaleProducts(page);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _products!.clear();

    for(var i = 0; i < data.length; i++){
      try {
        List<String> unitOfMeasurement = [];
        unitOfMeasurement = data[i]['unitOfMeasurement'].cast<String>();
        List<String> barCode = data[i]['barCode'].cast<String>();
        
       
        
        // gather category array data
        var catData = data[i]['category'];
        List<Category> categories = [];
        for(var j = 0; j < catData.length; j++){
          try {
            Category cat = Category.fromJson(catData[j]);
            categories.add(cat);
          } catch (e) {
            print(e);
          }
        }
        print("steping2 ${i}");

        String sId = data[i]['_id'];
        String name = data[i]['name'];

        Map<String, dynamic> limitPrice = Map<String, dynamic>();
        limitPrice.addAll(data[i]['limitPrice']);

        Map<String, dynamic> sellingPrice = Map<String, dynamic>();
        sellingPrice.addAll(data[i]['sellingPrice']);

        Map<String, dynamic> costPrice = Map<String, dynamic>();
        costPrice.addAll(data[i]['costPrice']);

        Map<String, dynamic> quantity = Map<String, dynamic>();
        quantity.addAll(data[i]['quantity']);

        Map<String, dynamic> discountUnit = Map<String, dynamic>();
        discountUnit.addAll(data[i]['discountUnit']);

        Map<String, dynamic> discountType = Map<String, dynamic>();
        discountType.addAll(data[i]['discountType']);

        Map<String, dynamic> discount = Map<String, dynamic>();
        discount.addAll(data[i]['discount']);

        Map<String, dynamic> reOrderLimit = Map<String, dynamic>();
        reOrderLimit.addAll(data[i]['reOrderLimit']);

        String expiryDate = data[i]['expiryDate'];
        bool status =  data[i]['status'];
        String createdAt = data[i]['createdAt'];

        Product cust = Product(
          unitOfMeasurement: unitOfMeasurement,
          barCode: barCode,
          category: categories,
          sId: sId,
          name: name,
          status: status,
          limitPrice: limitPrice,
          sellingPrice: sellingPrice,
          costPrice: costPrice,
          quantity: quantity,
          sellQuantity: Map<String, dynamic>(),
          discountUnit: discountUnit,
          discountType: discountType,
          discount: discount,
          reOrderLimit: reOrderLimit,
          expiryDate: expiryDate,
          createdAt: createdAt,
        ); 

        print(cust);
        
        _products!.add(cust); 
        print(cust);
      } catch (e) {
        print(e);
      }
            
                
    }
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _products;
  }

  Future<List<Product>?> populateSearchProduct(String query) async{
    var data = await searchProduct(query);
    if(data == null){
      return null;
    }
    print("staff length: ${data.length}" );
    _products!.clear();
    print("staff length:2 ${_products!.length}" );
     for(var i = 0; i < data.length; i++){
      try {
        List<String> unitOfMeasurement = [];
        unitOfMeasurement = data[i]['unitOfMeasurement'].cast<String>();
        List<String> barCode = data[i]['barCode'].cast<String>();
        
       
        
        // gather category array data
        var catData = data[i]['category'];
        List<Category> categories = [];
        for(var j = 0; j < catData.length; j++){
          try {
            Category cat = Category.fromJson(catData[j]);
            categories.add(cat);
          } catch (e) {
            print(e);
          }
        }
        print("steping2 ${i}");

        String sId = data[i]['_id'];
        String name = data[i]['name'];

        Map<String, dynamic> limitPrice = Map<String, dynamic>();
        limitPrice.addAll(data[i]['limitPrice']);

        Map<String, dynamic> sellingPrice = Map<String, dynamic>();
        sellingPrice.addAll(data[i]['sellingPrice']);

        Map<String, dynamic> costPrice = Map<String, dynamic>();
        costPrice.addAll(data[i]['costPrice']);

        Map<String, dynamic> quantity = Map<String, dynamic>();
        quantity.addAll(data[i]['quantity']);

        Map<String, dynamic> discountUnit = Map<String, dynamic>();
        discountUnit.addAll(data[i]['discountUnit']);

        Map<String, dynamic> discountType = Map<String, dynamic>();
        discountType.addAll(data[i]['discountType']);

        Map<String, dynamic> discount = Map<String, dynamic>();
        discount.addAll(data[i]['discount']);

        Map<String, dynamic> reOrderLimit = Map<String, dynamic>();
        reOrderLimit.addAll(data[i]['reOrderLimit']);

        String expiryDate = data[i]['expiryDate'];
        bool status =  data[i]['status'];
        String createdAt = data[i]['createdAt'];

        Product cust = Product(
          unitOfMeasurement: unitOfMeasurement,
          barCode: barCode,
          category: categories,
          sId: sId,
          name: name,
          status: status,
          limitPrice: limitPrice,
          sellingPrice: sellingPrice,
          costPrice: costPrice,
          quantity: quantity,
          sellQuantity: Map<String, dynamic>(),
          discountUnit: discountUnit,
          discountType: discountType,
          discount: discount,
          reOrderLimit: reOrderLimit,
          expiryDate: expiryDate,
          createdAt: createdAt,
        ); 

        print(cust);
        
        _products!.add(cust); 
        print(cust);
      } catch (e) {
        print(e);
      }
            
                
    }
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _products;
  }

  Future<List<dynamic>?> getSaleProducts(int page) async{   

    //LoadingControl.showLoading();
    final response = await _httpService.getProductsRequest();
    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){      
      var data = payload['Products'];
      print(data.runtimeType);    
      _productTotalPage = (payload['totalItems']/50).ceil();        
      return data;
      

    }else if(statusCode == 422){
      print("error of 422");
      
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    
    else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    

  }

  Future<List<dynamic>?> searchProduct(String query) async{
    //LoadingControl.showLoading();
    final response = await _httpService.searchProductRequest(query);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){  

      var data = payload['Product'];
      return data;
       
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  
  saleProduct(CheckoutProduct cpp) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.saleProductRequest(cpp);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Sale completed. Proceed to print receipt.", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         

      Get.to(() => SellSuccessScreen());
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
   else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  populateBalanceSheet(String startDate, String endDate) async{
    var data = await getBalanceSheet(startDate, endDate);
    if(data == null){
      return null;
    }



    //_totalSales = data['TotalCostPrice'].toDouble();
    _totalCost = 0.0;
    _totalSales = 0.0;
    for (var i = 0; i < data['BalanceSheetSales'].length; i++) {
      print("total cp: ${data['BalanceSheetSales'][i]['TotalCostPrice']}");
      print("total sp: ${data['BalanceSheetSales'][i]['TotalSales']}");
      var ts = data['BalanceSheetSales'][i]['TotalCostPrice'] == null ? 0.0 : data['BalanceSheetSales'][i]['TotalCostPrice'].toDouble();
      _totalCost = _totalCost! + ts;

      var tt = data['BalanceSheetSales'][i]['TotalSales'] == null ? 0.0 : data['BalanceSheetSales'][i]['TotalSales'].toDouble();
      _totalSales = _totalSales! + tt;
    }

    for (var i = 0; i < data['DebitSales'].length; i++) {
      var tt = data['DebitSales'][i]['remainingAmount'] == null ? 0.0 : data['DebitSales'][i]['remainingAmount'].toDouble();
      _totalDebt = _totalDebt! + tt;
    }
  }
  
  Future<dynamic?> getBalanceSheet(String startDate, String endDate) async{
    //LoadingControl.showLoading();
    final response = await _httpService.balanceSheetByDateRequest(startDate, endDate);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 201){  

      //var data = payload['Product'];
      return payload;
       
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
   else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

}
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:package_info/package_info.dart';
import 'package:vicpharm_app/screens/advert/advertscreen.dart';
import 'package:vicpharm_app/screens/auth/changepasswordscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class SettingScreen extends StatefulWidget {
  SettingScreen({Key? key}) : super(key: key);

  @override
  _SettingScreenState createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
   PackageInfo _packageInfo = PackageInfo(
    appName: 'Unknown',
    packageName: 'Unknown',
    version: 'Unknown',
    buildNumber: 'Unknown',
  );

  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => _initPackageInfo());
    
    
  }

  Future<void> _initPackageInfo() async {
    final PackageInfo info = await PackageInfo.fromPlatform();
    setState(() {
      _packageInfo = info;
    });
  }

  Widget dataContainerAbout(String text, String version){
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        height: MediaQuery.of(context).size.height * 0.1,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(20)),
            color: Color(0xff0c1c63ba)
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(text, style: TextStyle(color: black, fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
              Row(
                children: [
                  Text(version, style: TextStyle(color: black, fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
                  Icon(Icons.arrow_forward_ios, color: black, size: 16,)
                ],
              )
            ],
          ),
        ),
      ),
    );
  }


  Widget dataContainerRecurrent(String text, Widget checkWidget){
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        height: MediaQuery.of(context).size.height * 0.1,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(20)),
            color: Color(0xff0c1c63ba)
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(text, style: TextStyle(color: black, fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
              checkWidget
            ],
          ),
        ),
      ),
    );
  }

  Widget dataContainer(String text){
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        height: MediaQuery.of(context).size.height * 0.1,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(20)),
          color: Color(0xff0c1c63ba)
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(text, style: TextStyle(color: black, fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
              Icon(Icons.arrow_forward_ios, color: black, size: 16,)
            ],
          ),
        ),
      ),
    );
  }

  Widget mainSettingsContainer(BuildContext context){
    return Container(
      width: Get.width,
      height: Get.height,
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 20, left: 30, right: 20),
              child: Text("Store Settings", style: TextStyle(fontSize: 14, fontFamily: 'PoppinsSemiBold', color: grey),),
            ),

            InkWell(
              onTap: (){
                Get.to(() => ChangePasswordScreen());

              },
                child: dataContainer("Change Password"),
            ),

         
            InkWell(
              onTap: (){
                Get.to(() => AdvertScreen());

              },
                child: dataContainer("Print Advert"),
            ),

            Padding(
              padding: const EdgeInsets.only(top: 20, left: 30, right: 20),
              child: Text("App Settings", style: TextStyle(fontSize: 14, fontFamily: 'PoppinsSemiBold', color: grey),),
            ),

            InkWell(
                onTap: (){
                  //_appUpdateDialog(context, "A new version(1.2.0) of MVS Business is available. You are using " + _packageInfo.version + ". Do you want to upgrade?");
                },
                child: dataContainerAbout("App Version", _packageInfo.version)
            ),

            /*InkWell(
              onTap: (){
                //syncDialog();
              },
              child: dataContainer("Sync Interval"),
            ), */


          ],
        ),
      ),
    );
  }




  @override
  Widget build(BuildContext context) {

    return Scaffold(
        key: _scaffoldKey,
        body: mainSettingsContainer(context)
    );
  }
}




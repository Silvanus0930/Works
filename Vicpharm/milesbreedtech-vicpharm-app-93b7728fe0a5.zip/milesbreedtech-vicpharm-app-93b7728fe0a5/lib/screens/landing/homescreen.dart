import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/customwidgets/AlternateContainer.dart';
import 'package:vicpharm_app/models/product.dart';
import 'package:vicpharm_app/screens/activities/activitiesscreen.dart';
import 'package:vicpharm_app/screens/inventory/addinventoryscreen.dart';
import 'package:vicpharm_app/screens/landing/addtocartmodal.dart';
import 'package:vicpharm_app/screens/landing/landingprovider.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';
import 'package:flutter_qr_bar_scanner/qr_bar_scanner_camera.dart';
import 'package:bottom_sheet_x/bottom_sheet_x.dart';

class HomeScreen extends StatefulWidget {
  HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  bool _camState = false;
  String barcode = "";
  final RefreshController _refreshController = RefreshController();
  final NavBottomSheetController _navBottomSheetController = NavBottomSheetController();
  final ScrollController _scrollController = ScrollController();
  ScrollController controller = ScrollController();
  ActivitiesLoadMoreStatus loadMoreStatus = ActivitiesLoadMoreStatus.STABLE;
  int currentPageNumber = 1;


  @override
  void dispose() { 
    _navBottomSheetController.dispose();
    controller.dispose();
    super.dispose();
  }

  Widget searchFilterBox(BuildContext context){
    return SizedBox(
          height: Get.height * 0.09,
          width: Get.width,
          child: Container(
              color: mainColor,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 15.0, top: 8, bottom: 8),
                  child: SizedBox(
                    width: Get.width * 0.75,
                    child: Container(
                      height: Get.height * 0.7,
                      decoration: BoxDecoration(
                        color:  whiteBG,
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: Center(
                        child: TextField(
                          //controller: searchFieldController,
                          style: TextStyle(fontSize: 14, color: black),
                          onChanged: (String? query) async {
                           if(query != null){
                              if(query.isEmpty){
                                Provider.of<LandingProvider>(context, listen: false).setFutureList(Provider.of<LandingProvider>(context, listen: false).populateProduct(1));
                              }else{
                                Provider.of<LandingProvider>(context, listen: false).setFutureList(Provider.of<LandingProvider>(context, listen: false).populateSearchProduct(query));
                              
                              }
                            }

                          },
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            contentPadding: const EdgeInsets.only(top: 10),
                            prefixIcon: Icon(
                              Icons.search, color: black, size: 16,),

                            hintText: 'What do you want to sell?',
                            hintStyle: TextStyle(fontSize: 12, color: grey, fontFamily: 'PoppinsRegular'),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.only(right: 25.0),
                  child: SizedBox(
                    width: Get.width * 0.09,
                    child: InkWell(
                        enableFeedback: true,
                        splashColor: mvsdarkyellow,
                        onTap: (){
                          _scanCode();
                          //scan(context);
                        },
                        child: _camState ? Icon(Icons.close, color: Colors.red, size: 32,) :
                        SvgPicture.asset(
                              "assets/images/svgs/barcode.svg",
                              color: _camState ? Colors.red : whiteBG,
                              height: 80,
                              width: 80,
                              fit: BoxFit.none,
                              semanticsLabel: 'barcode scan button'
                          ),
                        
                      ),

                  ),
                ),
              ],
            ),
          ),
        );
  }

  _scanCode() {
    setState(() {

     // _camState = true;
      if(_camState){
        //showFloatingActionButton(true);
        _camState =false;
      }else{
        _camState = true;
        //showFloatingActionButton(false);
      }
    });
  }

  Widget alteContainer(String text, bool showBtn){
    return  Container(
      width: Get.width,
      height: Get.height * 0.65,
      //color: Colors.red,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: Get.height * 0.12,
            child: Image.asset("assets/images/search.png"),
          ),
          SizedBox(height: 10,),
          Text(text, maxLines: 1, style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 14, color: Color(0xff979797),),
          ),
          SizedBox(height: 10,),
         // showBtn ? nextBtn(context) : Container()
          

        ],
      ),
    );
  }

  FloatingActionButton fab(){
    return FloatingActionButton(
      heroTag: "btn2",
      onPressed: (){
        Get.to(() => AddInventoryScreen());
      },
      child: Icon(Icons.add, color: whiteBG,),
                backgroundColor: mainColor,
            );
  }
  
  _qrCallback(String code) async{
    setState(() {
      _camState = false;
      //showFloatingActionButton(true);
      barcode = code;
      
    });
    print("barcode scanned");
    print(this.barcode);

  }

  bool onNotification(ScrollNotification notification) {
  if (notification is ScrollUpdateNotification) {
    if (controller.position.maxScrollExtent > controller.offset &&
        controller.position.maxScrollExtent - controller.offset <=
            50) {
      if (loadMoreStatus != null && loadMoreStatus == ActivitiesLoadMoreStatus.STABLE) {
        loadMoreStatus = ActivitiesLoadMoreStatus.LOADING;
        if(currentPageNumber != Provider.of<LandingProvider>(context, listen: false).productTotalPage){
          currentPageNumber = currentPageNumber + 1;
        Provider.of<LandingProvider>(context, listen: false).populateProduct(currentPageNumber);
        }
        
      }
    }
  }
  return true;
}
  
  
  Widget gridData(){
    var size = MediaQuery.of(context).size;
    final double iH = Platform.isIOS ? (size.height - kToolbarHeight - 48) / 3.6 : (size.height - kToolbarHeight - 48) / 3.4;
    
    final iW = size.width / 3;


   return FutureBuilder<List<Product>?>(
     future: Provider.of<LandingProvider>(context, listen: true).futureProducts,
     builder: (context, AsyncSnapshot<List<Product>?>? snapshot){
       if(snapshot!.hasError){
          return AlternateContainer(text: "Error occurred retrieving data...");
        }else if (snapshot.connectionState == ConnectionState.waiting){
          return AlternateContainer(text: "Loading....");
        }
        else if(snapshot.data == null){
          return AlternateContainer(text: "No record found.....");
        }
        else if(snapshot.connectionState == ConnectionState.done){
          return NotificationListener(
            onNotification: onNotification,
            child: GridView.builder(
              controller: controller,
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                itemCount: snapshot.data!.length,
                gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(
                    childAspectRatio: (iW / iH),
                    crossAxisCount: 3,
                    mainAxisSpacing: 2
                ),
                itemBuilder: (BuildContext context, int index) {
                  return  Padding(
                    padding: const EdgeInsets.only(
                        top: 5, bottom: 5, left: 8, right: 8),
                    child: InkWell(
                      splashColor: mvsdarkyellow,
                      onTap: () async{
                        print(snapshot.data![index].unitOfMeasurement);
                        
                        Provider.of<LandingProvider>(context, listen: false).setSelectedProduct(snapshot.data![index]);
                        print(Provider.of<LandingProvider>(context, listen: false).selectedproduct!.unitOfMeasurement);
                        Provider.of<LandingProvider>(context, listen: false).setSelectedMeasurement(Provider.of<LandingProvider>(context, listen: false).selectedproduct!.unitOfMeasurement![0]);
                        print(Provider.of<LandingProvider>(context, listen: false).selectedMeasurement);
                         /*showNavBottomSheet(

                          context: context,
                          navBottomSheetController: _navBottomSheetController,
                          isDismissible: true,
                          backdropColor: mainColor.withOpacity(0.3),
                          bottomSheetHeight: MediaQuery.of(context).size.height * 0.7,
                          bottomSheetBodyHasScrollView: true,
                          bottomSheetBodyScrollController: _scrollController,
                          
                          //bottomSheetHeader: _bottomSheetHeader,
                          bottomSheetBody: AddToCartModal(nBSC: _navBottomSheetController,),
                        ).then((onValue) {
                          print(onValue);
                        }); */
                       Get.dialog(AddToCartModal());

                      },
                      child: Container(
                        decoration: BoxDecoration(
                            color: whiteBG,
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.1),
                                blurRadius: 15,
                                spreadRadius: 3,
                                offset: Offset(-1, 18),
                              ),
                            ],
                            borderRadius: BorderRadius.all(
                              Radius.circular(5),
                            )
                        ),
                        child: Stack(
                          //overflow: Overflow.clip,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(bottom: 2, left: 5, right: 5),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                //mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(height: 25,),
                                  Align(
                                    alignment: Alignment.topCenter,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width * 0.5,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: mainColor.withOpacity(0.3),
                                        //border: Border.all(color: Colors.red, width: 1.0)
                                      ),
                                      child: Center(
                                        child: Text(
                                          "${snapshot.data![index].name}".substring(0, 1).toUpperCase(),
                                          style: TextStyle(
                                              fontFamily: 'PoppinsBold',
                                              fontSize: 28,
                                              color: mainColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 5,),
                                  Align(
                                    alignment: Alignment.center,
                                    child: Text(
                                      "${snapshot.data![index].name}",
                                      //products[index].name.isNotEmpty || products[index].name != null ? products[index].name.substring(0, 1).toUpperCase() + products[index].name.substring(1) : "",
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 14),
                                    ),

                                  ),
                                  
                                  SizedBox(height: 5,),
                                  Align(
                                    alignment: Alignment.center,
                                    child: Column(
                                      children: List.generate(snapshot.data![index].unitOfMeasurement!.length > 2 ? 2 : snapshot.data![index].unitOfMeasurement!.length, (ix) => 
                                      Text(
                                          "${snapshot.data![index].unitOfMeasurement![ix]}",
                                          //fo.symbolOnLeft,
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 1,
                                          style: TextStyle(
                                              fontFamily: 'Roboto',
                                              fontWeight: FontWeight.bold,
                                              fontSize: 12),
                                        ),
                                      ),
                                    ),

                                  ),
                                  SizedBox(height: 5,),
                                  Flexible(
                                    child: Container(
                                      padding: EdgeInsets.only( left: 5, right: 5),
                                      width: MediaQuery.of(context).size.width * 0.5,
                                      decoration: BoxDecoration(
                                          color: mainColor,
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(5))
                                      ),

                                      child: Text(
                                        "${snapshot.data![index].category!.isNotEmpty ? snapshot.data![index].category![0].name!.capitalizeFirst : ""}",
                                        //category.name.substring(0, 1).toUpperCase() + category.name.substring(1),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontFamily: 'PoppinsRegular',
                                            color: whiteBG,
                                            fontSize: 12),
                                      ),


                                    ),
                                  )
                                ],
                              ),
                            ),
                            
                          ],
                        ),

                      ),
                    ),
                  );


                },
              ),
          );
  
        }
        else{
          return AlternateContainer(text: "Loading....");
        }
     }
    
  
   );
     
  }

  Widget mainContainer(BuildContext context){
    return Column(
      children: [
        searchFilterBox(context),
        _camState ?
        Expanded(
          child: Container(
            //color: Colors.red,
            child: QRBarScannerCamera(
              onError: (context, error) => Text(
                error.toString(),
                style: TextStyle(color: Colors.red),
              ),
              qrCodeCallback: (code) {
                _qrCallback(code);
              },
              child: Container(
                width: double.infinity,
                height: double.infinity,
                color: Colors.transparent,
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        width: double.infinity,
                        height: MediaQuery.of(context).size.height * 0.08,
                        color: mainColor,
                        child: Center(
                          child: Text(
                            'Focus camera on the barcode for efficiency',
                            style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                          ),
                        ),
                      ),
                    ),

                    Align(
                      alignment: Alignment.center,
                      child: Image.asset("assets/images/ion_scan.png")
                    ),


                    
                    
                  ],
                ),
              ),
            ),
          
          ),
        )
        //: alteContainer("No Items yet. Add new Items", true),
        : Expanded(
          child: SmartRefresher(
              controller: _refreshController,
              header: WaterDropMaterialHeader(
                backgroundColor: mainColor,
              ),
              onRefresh: (){
                Provider.of<LandingProvider>(context, listen: false).setFutureList(Provider.of<LandingProvider>(context, listen: false).populateProduct(1));
              },
              child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  child: gridData()
              )
            )
         
        ),
      ],
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        setState(() {
         // if(bsc != null){
            FocusScope.of(context).unfocus();
            _navBottomSheetController.close();
         // }
        });
        FocusScopeNode currentFocus = FocusScope.of(context);
        if(!currentFocus.hasPrimaryFocus) {
          currentFocus.unfocus();
        }
      },
      child: SafeArea(
         child: Scaffold(
           body: mainContainer(context),
           floatingActionButton: fab(),
         ),
      ),
    );
  }
}
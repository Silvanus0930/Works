import 'package:flutter/material.dart';
import 'package:get/get_connect/sockets/src/sockets_io.dart';
import 'package:intl/intl.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/customwidgets/AlternateContainer.dart';
//import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/models/activity.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';
import 'package:flutter/foundation.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class ActivitiesScreen extends StatefulWidget {
  ActivitiesScreen({Key? key}) : super(key: key);

  @override
  _ActivitiesScreenState createState() => _ActivitiesScreenState();
}

class _ActivitiesScreenState extends State<ActivitiesScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  //final RefreshController _refreshController = RefreshController();
  final ScrollController scrollController = new ScrollController();
  
 
  DateFormat dateFormat = DateFormat("yyyy-MM-dd");
  DateFormat timeFormat = DateFormat("a"); //DateFormat("HH:mm a");
  int currentPageNumber = 1;
  int _pageSize = 50;

  final PagingController<int, Activity> _pagingController =
      PagingController(firstPageKey: 1);

  @override
  void initState() { 
    _pagingController.addPageRequestListener((pageKey) {
      _fetchPage(pageKey);
    });
    super.initState();
  }

  @override
  void dispose() {
    _pagingController.dispose();
    super.dispose();
  }

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Activity",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),

    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Navigator.of(context).pop(),
    ),

  );

  Widget dataContainer(Activity activity){ //.yMMMEd()
    DateTime createdDate = DateTime.parse(activity.createdAt!);
    String createdDateF = dateFormat.format(createdDate);
    var newDt = DateFormat.yMMMEd().format(createdDate);

    DateTime createdTime = DateTime.parse(activity.createdAt!);
    String createdTimeF = timeFormat.format(createdTime);

    return Padding(
      padding: const EdgeInsets.only(top:10, left: 20, right: 20),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        height: MediaQuery.of(context).size.height * 0.1,
        decoration: BoxDecoration(
          color: Color(0x0d1c63ba),
          borderRadius: BorderRadius.all(Radius.circular(15))
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 20, right: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("${activity.staffId!.personalInfo!.firstName} ${activity.staffId!.personalInfo!.lastName} ${activity.event}", overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: black, fontFamily: 'PoppinsSemiBold'),),
              SizedBox(height: 8,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Date: " + newDt, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),),
                  Text(Jiffy(activity.createdAt!).jms , maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: mvsblue, fontFamily: 'PoppinsSemiBold'),)
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _fetchPage(int pageKey) async {
    try {
      final newItems = await Provider.of<AuthProvider>(context, listen: false).populateActivities(pageKey);
      final isLastPage = newItems!.length < _pageSize;
      if (isLastPage) {
        _pagingController.appendLastPage(newItems);
      } else if(pageKey == Provider.of<AuthProvider>(context, listen: false).activitiesTotalPage!){
        //final nextPageKey = pageKey + 1;
        //_pagingController.appendPage(newItems, nextPageKey);
      }
      else {
        final nextPageKey = pageKey + 1;
        _pagingController.appendPage(newItems, nextPageKey);
      }
    } catch (error) {
      _pagingController.error = error;
    }
    
    
  }
  
 
  
  
  Widget dataContainerList(BuildContext context){
    return RefreshIndicator(
      onRefresh: () => Future.sync(
        () => _pagingController.refresh(),
      ),
      child: PagedListView<int, Activity>(
        
          pagingController: _pagingController,
          builderDelegate: PagedChildBuilderDelegate<Activity>(
            itemBuilder: (context, item, index) => dataContainer(item),
            newPageErrorIndicatorBuilder: (context) => AlternateContainer(
              text:  _pagingController.error.toString(),
            ),
            firstPageErrorIndicatorBuilder: (context) => AlternateContainer(
              text:  _pagingController.error.toString(),
            ),
            noItemsFoundIndicatorBuilder: (context) => AlternateContainer(
              text:  "No data yet.",
            ),
          ),
          
           
        ),
    );
  }

  @override
  void didUpdateWidget(dynamic oldWidget) {
   // if (oldWidget.listPreferences != widget.listPreferences) {
      _pagingController.refresh();
   // }
    super.didUpdateWidget(oldWidget);
  }
  


  Widget mainContainer(BuildContext context){
    return Container(
      color: whiteBG,
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
        child: dataContainerList(context),

    );
  }

  @override
  Widget build(BuildContext context) {

    return SafeArea(
      child: Scaffold(
        appBar: appbar(context),
        backgroundColor: whiteBG,
        body: mainContainer(context)
      ),
    );
  }
}

enum ActivitiesLoadMoreStatus { LOADING, STABLE }
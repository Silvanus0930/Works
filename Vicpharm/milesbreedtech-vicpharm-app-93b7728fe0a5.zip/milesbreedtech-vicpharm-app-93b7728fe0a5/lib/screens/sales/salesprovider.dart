import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/models/creditsalerecord.dart';
import 'package:vicpharm_app/models/salerecord.dart';
import 'package:vicpharm_app/screens/customer/customerscreen.dart';
import 'package:vicpharm_app/utils/httpservice.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';

class SalesProvider with ChangeNotifier {
  final HttpService _httpService = new HttpService();
  List<SaleRecord>? _saleRecords = [];
  SaleRecord? _selectedSaleRecord;
  Future<List<SaleRecord>?>? _futureSaleRecord;
  int? _saleRecordTotalPage;
  RefreshController _refreshController = RefreshController();

  RefreshController get refreshController => _refreshController;

  List<SaleRecord>? get saleRecords => _saleRecords;
  SaleRecord? get selectedSaleRecord => _selectedSaleRecord;
  Future<List<SaleRecord>?>? get futureSaleRecord => _futureSaleRecord;
  int? get saleRecordTotalPage => _saleRecordTotalPage;

  // for Credit Sales
  List<CreditSalerecord>? _creditSaleRecords = [];
  CreditSalerecord? _selectedCreditSaleRecord;
  Future<List<CreditSalerecord>?>? _futureCreditSaleRecord;
  int? _creditSaleRecordTotalPage;

  List<CreditSalerecord>? get creditSaleRecords => _creditSaleRecords;
  CreditSalerecord? get selectedCreditSaleRecord => _selectedCreditSaleRecord;
  Future<List<CreditSalerecord>?>? get futureCreditSaleRecord => _futureCreditSaleRecord;
  int? get creditSaleRecordTotalPage => _creditSaleRecordTotalPage;

  clearSalesList(){
    _saleRecords!.clear();
    notifyListeners();
  }

  setFutureList(Future<List<SaleRecord>?>? st){
    _futureSaleRecord = st;
    notifyListeners();
  }

  setStaffFutureList(Future<List<SaleRecord>?>? st){
    _futureSaleRecord = st;
    notifyListeners();
  }

  setSelectedSaleRecord(SaleRecord sr){
    _selectedSaleRecord = sr;
    //notifyListeners();
  }

  Future<List<SaleRecord>?> populateSaleRecord(int page) async{
    print("step 1");
    var data = await retrieveSaleRecord(page);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _saleRecords!.clear();
    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        String receiptId = data[i]['receiptId'];
        String createdAt = data[i]['createdAt'];
        String typeOfsales = data[i]['typeOfsales'];
        var totalAmount = data[i]['totalAmount'] ?? 0.0;
        print("tm1: ${totalAmount}");

        var vat = data[i]['vat'] != null ? data[i]['vat'].toDouble() : 0.0;
        print("var: ${vat}");
        List<PaymentType> paymentTypes = [];
        for(var ik = 0; ik < data[i]['paymentType'].length; ik++){
          PaymentType pt = PaymentType.fromJson(data[i]['paymentType'][ik]);
          paymentTypes.add(pt);
        }
        StaffId staffId = StaffId.fromJson(data[i]['staffId']);
        CustomerId cusId = CustomerId.fromJson(data[i]['CustomerId']);

        var productDetailsJson = data[i]['productDetails'];
        print("len of prod details: ${productDetailsJson.runtimeType}");
        print("type ${productDetailsJson.length}");
        List<ProductDetails> productDetails = [];

        for (var j = 0; j < productDetailsJson.length; j++) {
          print("for seling price map");
          Map<String, dynamic> sellingPrice = Map<String, dynamic>();
          sellingPrice.addAll(productDetailsJson[j]['sellingPrice']);
          print("sellig price: ${sellingPrice}");

          Map<String, dynamic> quantity = Map<String, dynamic>();
          quantity.addAll(productDetailsJson[j]['quantity']);

          double tm = productDetailsJson[j]['totalAmount'].toDouble();
          print("tm3 ${tm}");
          String productName = productDetailsJson[j]['productName'];
          String id = productDetailsJson[j]['id'];

          ProductDetails pds = ProductDetails(
            sellingPrice: sellingPrice,
            quantity: quantity,
            totalAmount: tm,
            productName: productName,
            id: id
          );

          productDetails.add(pds);
        }

        SaleRecord cust = SaleRecord(
          productDetails: productDetails,
          customerId: cusId,
          paymentType: paymentTypes,
          vat: vat,
          totalAmount: totalAmount.toDouble(),
          receiptId: receiptId,
          createdAt: createdAt,
          typeOfsales: typeOfsales,
          sId: sId,
          staffId: staffId,
        ); 

        print(cust);
        
        _saleRecords!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        //throw(e);
        _refreshController.loadFailed();
      }
            
                
    }
    _refreshController.loadComplete();
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _saleRecords;
  }

  Future<List<SaleRecord>?> populateSaleRecordByDate(String startDate, String endDate, int page) async{
    print("step 1");
    var data = await retrieveSaleRecordByDate(startDate, endDate, page);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _saleRecords!.clear();
    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        String receiptId = data[i]['receiptId'];
        String createdAt = data[i]['createdAt'];
        var totalAmount = data[i]['totalAmount'] ?? 0.0;
        print("tm1: ${totalAmount}");
        var vat = data[i]['vat'] != null ? data[i]['vat'].toDouble() : 0.0;
        print("var: ${vat}");
        print(data[i]['paymentType']);
        List<PaymentType> paymentTypes = [];
        
        for(var ik = 0; ik < data[i]['paymentType'].length; ik++){
          if(data[i]['paymentType'][ik].runtimeType == String){
            //double amt = data[i]['paymentType'][ik].runtimeType == String ? double.tryParse(data[i]['paymentType'][ik]) :data[i]['paymentType'][ik].toDouble();
            PaymentType pt = PaymentType(amount: totalAmount.toDouble(), paymentType: data[i]['paymentType'][ik]);
            paymentTypes.add(pt);
          }else{
            PaymentType pt = PaymentType.fromJson(data[i]['paymentType'][ik]);
            paymentTypes.add(pt);
          }
          
        }
        StaffId staffId = StaffId.fromJson(data[i]['staffId']);
        CustomerId cusId = CustomerId.fromJson(data[i]['CustomerId']);

        var productDetailsJson = data[i]['productDetails'];
        print("len of prod details: ${productDetailsJson.runtimeType}");
        print("type ${productDetailsJson.length}");
        List<ProductDetails> productDetails = [];

        for (var j = 0; j < productDetailsJson.length; j++) {
          print("for seling price map");
          Map<String, dynamic> sellingPrice = Map<String, dynamic>();
          sellingPrice.addAll(productDetailsJson[j]['sellingPrice']);
          print("sellig price: ${sellingPrice}");

          Map<String, dynamic> quantity = Map<String, dynamic>();
          quantity.addAll(productDetailsJson[j]['quantity']);

          double tm = productDetailsJson[j]['totalAmount'].toDouble();
          print("tm3 ${tm}");
          String productName = productDetailsJson[j]['productName'];
          String id = productDetailsJson[j]['id'];

          ProductDetails pds = ProductDetails(
            sellingPrice: sellingPrice,
            quantity: quantity,
            totalAmount: tm,
            productName: productName,
            id: id
          );

          productDetails.add(pds);
        }

        SaleRecord cust = SaleRecord(
          productDetails: productDetails,
          customerId: cusId,
          paymentType: paymentTypes,
          vat: vat,
          totalAmount: totalAmount.toDouble(),
          receiptId: receiptId,
          createdAt: createdAt,
          sId: sId,
          staffId: staffId,
        ); 

        print(cust);
        
        _saleRecords!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        //throw(e);
      }
            
                
    }
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _saleRecords;
  }

  Future<List<dynamic>?> retrieveSaleRecord(int page) async{
    
    final response = await _httpService.getSaleRecordRequest(page);
    if(response == null){
      
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["sales"];    
      _saleRecordTotalPage = (payload['totalItems']/50).ceil();        
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  Future<List<dynamic>?> retrieveSaleRecordByDate(String startDate, String endDate, int page) async{
    
    final response = await _httpService.getSaleRecordByDateRequest(startDate, endDate, page);
    if(response == null){
      
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["sales"];    
      _saleRecordTotalPage = (payload['totalItems']/50).ceil();        
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  exportSalesRecord(String startDate, String endDate, String email) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.exportSalesRecordRequest(startDate, endDate, email);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Record exported successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         

      //Get.to(() => CustomerScreen());
      
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  setFutureListCredit(Future<List<CreditSalerecord>?>? st){
    _futureCreditSaleRecord = st;
    notifyListeners();
  }

  setSelectedCreditSaleRecord(CreditSalerecord sr){
    _selectedCreditSaleRecord = sr;
    //notifyListeners();
  }

  Future<List<CreditSalerecord>?> populateCreditSaleRecord(int page) async{
    print("step 1");
    var data = await retrieveCreditSaleRecord(page);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _creditSaleRecords!.clear();
    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        //String receiptId = data[i]['receiptId'];
        String createdAt = data[i]['createdAt'];
        String salesId = data[i]['salesId'];
      
        String expectedDate = data[i]['expectedDate'];
        double remainingAmount = data[i]['remainingAmount'].toDouble();
        bool active = data[i]['active'];

        var totalAmount = data[i]['totalAmount'].toDouble() ?? 0.0;
        print("tm1: ${totalAmount}");

        StaffIdC staffId = StaffIdC.fromJson(data[i]['staffId']);
        CustomerIdC cusId = CustomerIdC.fromJson(data[i]['CustomerId']);

        var productDetailsJson = data[i]['productDetails'];
        print("len of prod details: ${productDetailsJson.runtimeType}");
        print("type ${productDetailsJson.length}");
        List<ProductDetailsC> productDetails = [];

        for (var j = 0; j < productDetailsJson.length; j++) {
          print("for seling price map");
          Map<String, dynamic> sellingPrice = Map<String, dynamic>();
          sellingPrice.addAll(productDetailsJson[j]['sellingPrice']);
          print("sellig price: ${sellingPrice}");

          Map<String, dynamic> quantity = Map<String, dynamic>();
          quantity.addAll(productDetailsJson[j]['quantity']);

          double tm = productDetailsJson[j]['totalAmount'].toDouble();
          print("tm3 ${tm}");
          String productName = productDetailsJson[j]['productName'];
          String id = productDetailsJson[j]['id'];

          ProductDetailsC pds = ProductDetailsC(
            sellingPrice: sellingPrice,
            quantity: quantity,
            totalAmount: tm,
            productName: productName,
            id: id,
            
          );

          productDetails.add(pds);
        }

        var paidData = data[i]['paid'];
        List<Paid> paids = [];

        for (var k = 0; k < paidData.length; k++) {
          try{
            Paid paid = Paid.fromJson(paidData[k]);
            paids.add(paid);
          }catch(e){
            print(e);
          }
        }

        CreditSalerecord cust = CreditSalerecord (
          productDetails: productDetails,
          customerId: cusId,
          totalAmount: totalAmount.toDouble(),
          //receiptId: receiptId,
          createdAt: createdAt,
          sId: sId,
          salesId: salesId,
          staffId: staffId,
          expectedDate: expectedDate,
          remainingAmount: remainingAmount,
          paid: paids,
          active: active
        ); 

        print(cust);
        
        _creditSaleRecords!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        //throw(e);
        _refreshController.loadFailed();
      }
            
                
    }
    _refreshController.loadComplete();
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _creditSaleRecords;
  }

  
  Future<List<CreditSalerecord>?> populateCreditSaleRecordByDate(String startDate, String endDate, int page) async{
    print("step 1");
    var data = await retrieveCreditSaleRecordByDate(startDate, endDate, page);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _creditSaleRecords!.clear();
    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        //String receiptId = data[i]['receiptId'];
        String createdAt = data[i]['createdAt'];
        String salesId = data[i]['salesId'];
        String expectedDate = data[i]['expectedDate'];
        double remainingAmount = data[i]['remainingAmount'].toDouble();
        bool active = data[i]['active'];

        var totalAmount = data[i]['totalAmount'] ?? 0.0;
        print("tm1: ${totalAmount}");

        StaffIdC staffId = StaffIdC.fromJson(data[i]['staffId']);
        CustomerIdC cusId = CustomerIdC.fromJson(data[i]['CustomerId']);

        var productDetailsJson = data[i]['productDetails'];
        print("len of prod details: ${productDetailsJson.runtimeType}");
        print("type ${productDetailsJson.length}");
        List<ProductDetailsC> productDetails = [];

        for (var j = 0; j < productDetailsJson.length; j++) {
          print("for seling price map");
          Map<String, dynamic> sellingPrice = Map<String, dynamic>();
          sellingPrice.addAll(productDetailsJson[j]['sellingPrice']);
          print("sellig price: ${sellingPrice}");

          Map<String, dynamic> quantity = Map<String, dynamic>();
          quantity.addAll(productDetailsJson[j]['quantity']);

          double tm = productDetailsJson[j]['totalAmount'].toDouble();
          print("tm3 ${tm}");
          String productName = productDetailsJson[j]['productName'];
          String id = productDetailsJson[j]['id'];

          ProductDetailsC pds = ProductDetailsC(
            sellingPrice: sellingPrice,
            quantity: quantity,
            totalAmount: tm,
            productName: productName,
            id: id,
            
          );

          productDetails.add(pds);
        }

        var paidData = data[i]['paid'];
        List<Paid> paids = [];

        for (var k = 0; k < paidData.length; k++) {
          try{
            Paid paid = Paid.fromJson(paidData[k]);
            paids.add(paid);
          }catch(e){
            print(e);
          }
        }

        CreditSalerecord cust = CreditSalerecord (
          productDetails: productDetails,
          customerId: cusId,
          totalAmount: totalAmount.toDouble(),
          //receiptId: receiptId,
          createdAt: createdAt,
          sId: sId,
          salesId: salesId,
          staffId: staffId,
          expectedDate: expectedDate,
          remainingAmount: remainingAmount,
          paid: paids,
          active: active
        ); 

        print(cust);
        
        _creditSaleRecords!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        //throw(e);
      }
            
                
    }
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _creditSaleRecords;
  }

  Future<List<dynamic>?> retrieveCreditSaleRecord(int page) async{
    
    final response = await _httpService.getCreditSaleRecordRequest(page);
    if(response == null){
      
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["creditSale"];    
      _saleRecordTotalPage = (payload['totalItems']/50).ceil();        
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  Future<List<dynamic>?> retrieveCreditSaleRecordByDate(String startDate, String endDate, int page) async{
    
    final response = await _httpService.getCreditSaleRecordByDateRequest(startDate, endDate, page);
    if(response == null){
      
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["sales"];    
      _saleRecordTotalPage = (payload['totalItems']/50).ceil();        
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
    else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  payCreditSale(String debitId, double paid) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.payCreditSaleRequest(debitId, paid);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Credit Sale payment posted successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         

      //Get.to(CreditSalerecord());
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  Future<List<SaleRecord>?> populateStaffSaleRecord(int page, String staffId) async{
    print("step 1");
    var data = await retrieveStaffSaleRecord(page, staffId);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _saleRecords!.clear();
    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        String receiptId = data[i]['receiptId'];
        String createdAt = data[i]['createdAt'];
        var totalAmount = data[i]['totalAmount'] ?? 0.0;
        print("tm1: ${totalAmount}");
        var vat = data[i]['vat'] != null ? data[i]['vat'].toDouble() : 0.0;
        print("var: ${vat}");
        List<PaymentType> paymentTypes = [];
        
        for(var ik = 0; ik < data[i]['paymentType'].length; ik++){
          print("paymentType dataType");
          print(data[i]['paymentType'][ik].runtimeType);
          if(data[i]['paymentType'][ik].runtimeType == String){
            PaymentType pt  = PaymentType(amount: totalAmount.runtimeType == String ? double.tryParse(totalAmount) : totalAmount.toDouble(), paymentType: data[i]['paymentType'][ik]);
            paymentTypes.add(pt);
          }else{
            PaymentType pt = PaymentType.fromJson(data[i]['paymentType'][ik]);
            paymentTypes.add(pt);
          }
          
        }
        StaffId staffId = StaffId.fromJson(data[i]['staffId']);
        CustomerId cusId = CustomerId.fromJson(data[i]['CustomerId']);

        var productDetailsJson = data[i]['productDetails'];
        print("len of prod details: ${productDetailsJson.runtimeType}");
        print("type ${productDetailsJson.length}");
        List<ProductDetails> productDetails = [];

        for (var j = 0; j < productDetailsJson.length; j++) {
          print("for seling price map");
          Map<String, dynamic> sellingPrice = Map<String, dynamic>();
          sellingPrice.addAll(productDetailsJson[j]['sellingPrice']);
          print("sellig price: ${sellingPrice}");

          Map<String, dynamic> quantity = Map<String, dynamic>();
          quantity.addAll(productDetailsJson[j]['quantity']);

          double tm = productDetailsJson[j]['totalAmount'].toDouble();
          print("tm3 ${tm}");
          String productName = productDetailsJson[j]['productName'];
          String id = productDetailsJson[j]['id'];

          ProductDetails pds = ProductDetails(
            sellingPrice: sellingPrice,
            quantity: quantity,
            totalAmount: tm,
            productName: productName,
            id: id
          );

          productDetails.add(pds);
        }

        SaleRecord cust = SaleRecord(
          productDetails: productDetails,
          customerId: cusId,
          paymentType: paymentTypes,
          vat: vat,
          totalAmount: totalAmount.toDouble(),
          receiptId: receiptId,
          createdAt: createdAt,
          sId: sId,
          staffId: staffId,
        ); 

        print(cust);
        
        _saleRecords!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        throw(e);
      }
            
                
    }
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _saleRecords;
  }


  Future<List<dynamic>?> retrieveStaffSaleRecord(int page, String staffId) async{
    
    final response = await _httpService.getStaffSaleRecordRequest(page, staffId);
    if(response == null){
      
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["sales"];    
      _saleRecordTotalPage = (payload['totalItems']/50).ceil();        
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

}
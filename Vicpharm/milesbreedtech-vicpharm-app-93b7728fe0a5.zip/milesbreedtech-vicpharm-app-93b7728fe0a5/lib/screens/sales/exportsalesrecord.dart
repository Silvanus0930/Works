import 'dart:io';

import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/sales/salesprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class ExportSalesRecordScreen extends StatefulWidget {
  ExportSalesRecordScreen({Key? key}) : super(key: key);

  @override
  _ExportSalesRecordScreenState createState() => _ExportSalesRecordScreenState();
}

class _ExportSalesRecordScreenState extends State<ExportSalesRecordScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  bool _isLoading = false;
  TextEditingController startDateController = new TextEditingController();
  TextEditingController endDateController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();
  final format = DateFormat("yyyy-MM-dd");

  

  
  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Export Sales Record",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Navigator.of(context).pop(),
    ),


  );


  Widget filterFieldStart(BuildContext context) {
    return DateTimeField(
      controller: startDateController,
      style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),

          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          suffixIcon: Icon(Icons.calendar_today, color: Colors.grey, size: 16,),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
          hintText: "Start Date",
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

      format: format,
      onShowPicker: (context, currentValue) async {
        final date = await showDatePicker(
          context: context,
          firstDate: DateTime(1900),
          initialDate: currentValue ?? DateTime.now(),
          lastDate: DateTime(9100),
        );
        if (date != null) {
          /**  final time = await showTimePicker(
              context: context,
              initialTime:
              TimeOfDay.fromDateTime(currentValue ?? DateTime.now()),
              ); **/
          //print("checking biggggggggg");
          return DateTimeField.combine(date, null);
        } else {
          return currentValue;
        }
      },
    );
  }

  Widget filterFieldEnd(BuildContext context) {
    return DateTimeField(
      controller: endDateController,
      style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),

          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          suffixIcon: Icon(Icons.calendar_today, color: Colors.grey, size: 12,),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
          hintText: "End Date",
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

      format: format,
      onShowPicker: (context, currentValue) async {
        final date = await showDatePicker(
          context: context,
          firstDate: DateTime(1900),
          initialDate: currentValue ?? DateTime.now(),
          lastDate: DateTime(9100),
        );
        if (date != null) {
          /**  final time = await showTimePicker(
              context: context,
              initialTime:
              TimeOfDay.fromDateTime(currentValue ?? DateTime.now()),
              ); **/
          print("checking biggggggggg");

          return DateTimeField.combine(date, null);
        } else {
          return currentValue;
        }
      },
    );
  }

  Widget filterBox(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.08,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(child: filterFieldStart(context)),
            SizedBox(width: 10,),
            Expanded(child: filterFieldEnd(context)),
          ],
        ),
      ),
    );
  }

  Widget emailField(BuildContext context) => TextField(
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: emailController,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.emailAddress,
        textInputAction: TextInputAction.done,
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            suffixIcon: Icon(Icons.email_rounded, color: Colors.grey, size: 16,),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Enter Email Address",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
       

      );
  

  Widget mainLayer(BuildContext context) => Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: whiteBG,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          filterBox(context),
          Padding(
            padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
            child: emailField(context)
          ),
          SizedBox(height: 15,),
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.08,
            width: MediaQuery.of(context).size.width,
            child: Padding(
              padding: const EdgeInsets.only(left: 20, right: 20),
              child: ElevatedButton(
                onPressed: (){
                  Provider.of<SalesProvider>(context, listen: false).exportSalesRecord(startDateController.text, endDateController.text, emailController.text);
                },
                
                
                child: Text('Export Data', style: TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'PoppinsRegular'),),
              ),
            ),
          )

        ],
      )

    //child: contentStack(context),
  );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          backgroundColor: whiteBG,
          appBar: appbar(context),
          body: mainLayer(context)

        )
    );
  }
}
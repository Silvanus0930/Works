import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter_money_formatter/flutter_money_formatter.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'package:intl/intl.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:get/get.dart';
import 'package:vicpharm_app/customwidgets/AlternateContainer.dart';
import 'package:vicpharm_app/models/salerecord.dart';
import 'package:vicpharm_app/screens/activities/activitiesscreen.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/screens/sales/exportsalesrecord.dart';
import 'package:vicpharm_app/screens/sales/salesdetailsscreen.dart';
import 'package:vicpharm_app/screens/sales/salesprovider.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class SalesRecordScreen extends StatefulWidget {
  SalesRecordScreen({Key? key}) : super(key: key);

  @override
  _SalesRecordScreenState createState() => _SalesRecordScreenState();
}

class _SalesRecordScreenState extends State<SalesRecordScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  //final RefreshController _refreshController = RefreshController();
  final format = DateFormat("yyyy-MM-dd");
  TextEditingController startDateController = new TextEditingController();
  TextEditingController endDateController = new TextEditingController();
  var _controller = ScrollController();
  int currentPageNumber = 0;
  ActivitiesLoadMoreStatus loadMoreStatus = ActivitiesLoadMoreStatus.STABLE;

  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => Provider.of<SalesProvider>(context, listen: false).setFutureList(Provider.of<SalesProvider>(context, listen: false).populateSaleRecord(1)));
    
  }

   AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Sales Record",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Get.offAll(LandingScreen()),
    ),
    actions: [
      Padding(
        padding: const EdgeInsets.only(right: 20),
        child: InkWell(
          onTap: (){
            print(111111);
            Get.to(() => ExportSalesRecordScreen());
           
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.import_export_rounded),
              /*SvgPicture.asset(
                  "assets/images/svgs/export.svg",
                  color: mainColor,
                  height: 20,
                  width: 20,
                  fit: BoxFit.none,
                  semanticsLabel: 'add item'
              ),*/
            // Icon(Icons.poll, color: mainColor, size: 16),
              Text('Export', style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 12),)
            ],
          ),
        ),
      )
    ],

  );

  Widget filterFieldStart(BuildContext context) {
    return DateTimeField(
      controller: startDateController,
      style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),
          
          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          suffixIcon: Icon(Icons.calendar_today, color: Colors.grey, size: 16,),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
          hintText: "Start Date",
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

      format: format,
      onShowPicker: (context, currentValue) async {
        final date = await showDatePicker(
          context: context,
          firstDate: DateTime(1900),
          initialDate: currentValue ?? DateTime.now(),
          lastDate: DateTime(9100),
        );
        if (date != null) {
          /**  final time = await showTimePicker(
              context: context,
              initialTime:
              TimeOfDay.fromDateTime(currentValue ?? DateTime.now()),
              ); **/
          //print("checking biggggggggg");
          return DateTimeField.combine(date, null);
        } else {
          return currentValue;
        }
      },
    );
  }

  Widget filterFieldEnd(BuildContext context) {
    return DateTimeField(
      controller: endDateController,
      style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),

          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          suffixIcon: Icon(Icons.calendar_today, color: Colors.grey, size: 12,),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
          hintText: "End Date",
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

      format: format,
      onShowPicker: (context, currentValue) async {
        final date = await showDatePicker(
          context: context,
          firstDate: DateTime(1900),
          initialDate: currentValue ?? DateTime.now(),
          lastDate: DateTime(9100),
        );
        if (date != null) {
          final time = await showTimePicker(
              context: context,
              initialTime:
              TimeOfDay.fromDateTime(currentValue ?? DateTime.now()),
              );
          print("checking biggggggggg");
          if(startDateController.text.isEmpty){
            LoadingControl.showSnackBar(
              "Ouchs!!!", 
              "Please provide start date.", 
              Icon(Icons.error, color: Colors.red,)
            );
         
            //_errorDialog(context, "Please provide start date.");
          }else{
            if(startDateController.text.isEmpty){
              startDateController.text = format.format(DateTime.now());
            }
            currentPageNumber = 1;
            Provider.of<SalesProvider>(context, listen: false).setFutureList(Provider.of<SalesProvider>(context, listen: false).populateSaleRecordByDate(
              startDateController.text,
              endDateController.text,
              1));
            //futureData = retrSalesByDateRecordsFromServer();
          }
          return DateTimeField.combine(date, null);
        } else {
          return currentValue;
        }
      },
    );
  }

  Widget filterBox(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.08,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(child: filterFieldStart(context)),
            SizedBox(width: 10,),
            Expanded(child: filterFieldEnd(context)),
          ],
        ),
      ),
    );
  }

   
    bool onNotification(ScrollNotification notification) {
      if (notification is ScrollUpdateNotification) {
        if (_controller.position.maxScrollExtent > _controller.offset &&
            _controller.position.maxScrollExtent - _controller.offset <=
                50) {
          if (loadMoreStatus != null && loadMoreStatus == ActivitiesLoadMoreStatus.STABLE) {
            loadMoreStatus = ActivitiesLoadMoreStatus.LOADING;
            if(currentPageNumber != Provider.of<SalesProvider>(context, listen: false).saleRecordTotalPage){
              currentPageNumber = currentPageNumber + 1;
            Provider.of<SalesProvider>(context, listen: false).populateSaleRecord(currentPageNumber);
            }
            
          }
        }
      }
      return true;
}
  

  Widget recordBox(BuildContext context){
      return NotificationListener(
        onNotification: onNotification,
        child: FutureBuilder<List<SaleRecord>?>(
          future: Provider.of<SalesProvider>(context, listen: true).futureSaleRecord,
          builder: (context, snapshot){
            if(snapshot.hasError){
                  return AlternateContainer(text: "Error occurred retrieving data...");
              }else if (snapshot.connectionState == ConnectionState.waiting){
                  return AlternateContainer(text: "Loading....");
              }
              else if(snapshot.data == null){
                return AlternateContainer(text: "No data found.....");
              }
              else if(snapshot.connectionState == ConnectionState.done){
                
                return SmartRefresher(
                  enablePullDown: true,
                  //scrollController: controller,
                  controller: Provider.of<SalesProvider>(context, listen: true).refreshController,
                    header: WaterDropMaterialHeader(
                      backgroundColor: mainColor,
                    ),
                    onRefresh: (){
                      Provider.of<SalesProvider>(context, listen: false).setFutureList(Provider.of<SalesProvider>(context, listen: false).populateSaleRecord(1));
                    },
                  child: ListView.builder(
                            controller: _controller,
                              itemCount: snapshot.data!.length,
                              itemBuilder: (BuildContext context, index){
                                FlutterMoneyFormatter  fmf = FlutterMoneyFormatter(
                                    amount: snapshot.data![index].totalAmount,//salesrecords[index] != null ? salesrecords[index].totalAmount: 0.0,
                                    settings: MoneyFormatterSettings(
                                      symbol: "NGN",
                                      thousandSeparator: ',',
                                      decimalSeparator: '.',
                                      symbolAndNumberSeparator: ' ',
                                      fractionDigits: 2,
                                    ));
                                
                                
                                return InkWell(
                                  onTap: (){
                                    Provider.of<SalesProvider>(context, listen: false).setSelectedSaleRecord(snapshot.data![index]);
                                  Get.to(() => SalesDetailScreen());
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(top: 8, bottom: 8, left: 20, right: 20),
                                    child: Container(
                                      height: Get.height * 0.2,
                                      width: Get.width * 0.9,
                                      decoration: BoxDecoration(
                                          color: Color(0x0c662d6c),
                                          borderRadius: BorderRadius.all(Radius.circular(20))
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(top: 10.0, right: 5, left: 20),
                                            child: Container(child: Text(Jiffy(snapshot.data![index].createdAt).fromNow(), maxLines: 1, overflow: TextOverflow.ellipsis, style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold'),)),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(top: 5.0, right: 20, left: 20),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Expanded(child: Text("${snapshot.data![index].productDetails![0].productName} ".capitalize! + "...", overflow: TextOverflow.ellipsis, style:  TextStyle(fontSize: 12, color: grey),)),
                                                Expanded(child: Text(fmf.output.symbolOnLeft, textAlign: TextAlign.right, style:  TextStyle(fontSize: 12, color: mvsblue, fontFamily: 'Roboto'),))
                                              ],
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(top: 1.0, right: 20, left: 20),
                                            child: Divider(thickness: 2, color: Color(0xb3662d6c),),
                                          ),

                                          Padding(
                                            padding: const EdgeInsets.only(top: 1.0, right: 20, left: 20),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Text("${snapshot.data![index].productDetails!.length}".toString() + " items sold", style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular')),
                                                Text(Jiffy(snapshot.data![index].createdAt).yMd, style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'))
                                              ],
                                            ),
                                          ),

                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                );
        
              }
              else{
                return AlternateContainer(text: "Unknown error occurred. Please refresh");
              }
          },
          
        ),
      );

    }


  Widget salesRecordBox(BuildContext context){
    return Expanded(
      child: recordBox(context)

      );

  }
  

  Widget mainLayer(BuildContext context) => Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: whiteBG,
      child: Column(
        children: [
          filterBox(context),
          SizedBox(height: 10,),
          salesRecordBox(context),
        
        ],
      )

    //child: contentStack(context),
  );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          backgroundColor: whiteBG,
          appBar: appbar(context),
          body: mainLayer(context),

        )
    );
  }
}
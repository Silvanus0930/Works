import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:jiffy/jiffy.dart';
import 'package:vicpharm_app/models/onlineorder.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';


class OnlineOrderDetailsScreen extends StatefulWidget {
  OnlineOrder? onlineOrder;

  OnlineOrderDetailsScreen({this.onlineOrder});

  @override
  _OnlineOrderDetailsScreenState createState() => _OnlineOrderDetailsScreenState();
}

class _OnlineOrderDetailsScreenState extends State<OnlineOrderDetailsScreen> {
  var currencyFormat = new NumberFormat.currency(locale: "en_US", symbol: " \u{020A6}");


  /*Widget itemsList(BuildContext context){
    var pds = Provider.of<SalesProvider>(context, listen: false).selectedSaleRecord!.productDetails;
    return Column(
      children: List.generate(pds!.length, (i){


        return Padding(
          padding: const EdgeInsets.only(left: 10, right: 10, top: 1, bottom: 1),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.4,
                child: Text("${pds[i].productName}", overflow: TextOverflow.ellipsis, maxLines: 1, style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
              ),

              Column(
                children: pds[i].quantity!.entries.map((e) =>
                    Text("${e.key}: ${e.value}", maxLines: 1, style: TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'),),

                ).toList(),
              ),

              Text(currencyFormat.format(pds[i].totalAmount), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, fontFamily: 'Roboto'),)
            ],
          ),
        );
      }),

    );
  } */

  Widget fieldContainer(BuildContext context, String name, String field, Widget icon, String font){
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20, bottom: 10),
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 70,
        decoration: BoxDecoration(
            border: Border.all(color: grey, width: 2)
        ),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.topLeft,
                child: Text(field, style: TextStyle(color: grey, fontSize: 12, fontFamily: font),),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                  alignment: Alignment.bottomLeft,
                  child: SelectableText(
                    name,
                    style: TextStyle(fontSize: 12, fontFamily: 'Roboto'),
                    cursorColor: mvsblue,
                    showCursor: true,
                    toolbarOptions: ToolbarOptions(
                        copy: true,
                        selectAll: true,
                        cut: false,
                        paste: false
                    ),
                  ) //Text(name, style: TextStyle(fontSize: 16, fontFamily: 'Roboto'),),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.bottomRight,
                child: icon,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget fieldContainerw(BuildContext context, Widget name, String field, Widget icon, String font){
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20, bottom: 10),
      child: Container(
        width: MediaQuery.of(context).size.width,
        //height: MediaQuery.of(context).size.height * 0.08,
        decoration: BoxDecoration(
            border: Border.all(color: grey, width: 2)
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.topLeft,
                child: Text(field, style: TextStyle(color: grey, fontSize: 12, fontFamily: font),),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                  alignment: Alignment.bottomLeft,
                  child: name//Text(name, style: TextStyle(fontSize: 16, fontFamily: 'Roboto'),),
              ),
            ),


          ],
        ),
      ),
    );
  }


  Widget mainContainer(BuildContext context){
    //String customerName = "${Provider.of<SalesProvider>(context, listen: false).selectedSaleRecord!.customerId!.fullName}";

    //String staffFirstName = "${Provider.of<SalesProvider>(context, listen: false).selectedSaleRecord!.staffId!.personalInfo!.firstName}";//widget.salesRecord.staffId.personalInfo.firstName == null ? "" : widget.salesRecord.staffId.personalInfo.firstName;
    //String stafflastName = "${Provider.of<SalesProvider>(context, listen: false).selectedSaleRecord!.staffId!.personalInfo!.lastName}";//widget.salesRecord.staffId.personalInfo.lastName == null ? "" : widget.salesRecord.staffId.personalInfo.lastName;
    //String staffName = staffFirstName + " " + stafflastName;

    /*var saleTypes = Column(
        children: List.generate(Provider.of<SalesProvider>(context, listen: false).selectedSaleRecord!.paymentType!.length, (index) =>
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("${Provider.of<SalesProvider>(context, listen: false).selectedSaleRecord!.paymentType![index].paymentType}"),
                Text("${currencyFormat.format(Provider.of<SalesProvider>(context, listen: false).selectedSaleRecord!.paymentType![index].amount!).toString()}",
                  style: TextStyle(fontFamily: 'Roboto'),),
              ],
            )
        )
    ); */

    return SingleChildScrollView(

      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 10, left: 20, right: 20, bottom: 5),
            child: Container(
              width: MediaQuery.of(context).size.width,
              //height: MediaQuery.of(context).size.height * 0.3,
              decoration: BoxDecoration(
                  border: Border.all(color: grey)
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10, top: 10, bottom: 10),
                    child: Text("List of items orderd", style: TextStyle(fontSize: 14, color: grey, fontFamily: 'PoppinsSemiBold'),),
                  ),
                  //itemsList(context),
                ],
              ),
            ),
          ),
          fieldContainer(context, currencyFormat.format(widget.onlineOrder!.totalAmount), "Total Amount", Icon(Icons.monetization_on, color: grey, size: 16,), "PoppinsSemiBold"),
          fieldContainer(context,currencyFormat.format(widget.onlineOrder!.subTotalAmount), "Sub Total Amount", Icon(Icons.assessment, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.prescriptionProduct}", "Contains Prescription Product", Icon(Icons.card_travel, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.prescriptionProductApprove}", "Prescription Product Approved", Icon(Icons.assessment, color: grey, size: 16,), 'PoppinsSemiBold'),
          //fieldContainerw(context, saleTypes, "Payment Option", Icon(Icons.credit_card, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, Jiffy(widget.onlineOrder!.createdAt).yMMMdjm, "Order Date", Icon(Icons.calendar_today, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context,  "${widget.onlineOrder!.customerConfirmDelivery}", "Customer Confirmed Delivery", Icon(Icons.person, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context,  "${widget.onlineOrder!.storeApproval}", "Approved from Store", Icon(Icons.phone, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.itemPacked}", "Order Packed", Icon(Icons.person, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.dispatcherApproval}", "Approved By Dispatcher", Icon(Icons.person, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.pickup}", "Picked up by Dispatch", Icon(Icons.person, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.storePickUp}", "Customer to Pickup", Icon(Icons.person, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.deliveryCompleted}", "Delivery Completed", Icon(Icons.person, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.paymentStatus}", "Payment Status", Icon(Icons.person, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.fulfil}", "Order Fulfilled", Icon(Icons.person, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.status}", "Order Status", Icon(Icons.person, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.itemStatus}", "Order Item Status", Icon(Icons.person, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, "${widget.onlineOrder!.issues}", "Order have Issues", Icon(Icons.person, color: grey, size: 16,), 'PoppinsSemiBold'),
          fieldContainer(context, currencyFormat.format(widget.onlineOrder!.paymentOnDeliveryFee), "Total Amount", Icon(Icons.monetization_on, color: grey, size: 16,), "PoppinsSemiBold"),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar:  AppBar(
        elevation: 5.0,
        centerTitle: true,
        title: Text(
          "Online Order Detail",
          style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
        ),
        backgroundColor: whiteBG,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
          onPressed: () => Get.back()
        ),


      ),
        body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: mainContainer(context),
        ),
      ),
    );
  }
}

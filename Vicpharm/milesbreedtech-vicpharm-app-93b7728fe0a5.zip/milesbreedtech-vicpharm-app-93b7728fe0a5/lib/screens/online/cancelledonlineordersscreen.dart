import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/models/onlineorder.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

import 'onlineorderdetailsscreen.dart';
import 'onlineprovider.dart';

class CancelledOnlineOrdersScreen extends StatefulWidget {
  @override
  _CancelledOnlineOrdersScreenState createState() => _CancelledOnlineOrdersScreenState();
}

class _CancelledOnlineOrdersScreenState extends State<CancelledOnlineOrdersScreen> {
  var currencyFormat = new NumberFormat.currency(locale: "en_US", symbol: "\u{020A6} ");
  final ScrollController scrollController = ScrollController();
  StreamController<List<OnlineOrder>?> _streamController = StreamController<List<OnlineOrder>?>();
  int currentPage = 1;

  @override
  void initState() {
    super.initState();
    scrollController.addListener(() async{
      if(scrollController.position.pixels >= scrollController.position.maxScrollExtent){
        currentPage = currentPage + 1;
        print("I am at the bottom");
        print("total all products page: ${ Provider.of<OnlineProvider>(context, listen: false).orderTotalPage}");
        print("current page: ${ currentPage}");
        if(currentPage <= Provider.of<OnlineProvider>(context, listen: false).orderTotalPage!){
          final dd = await Provider.of<OnlineProvider>(context, listen: false).getAllCancelledOnlineOrders(currentPage);
          print("lengrh::::::::::::::${dd!.length}");
          _streamController.add(dd);
        }

      }
    });
    WidgetsBinding.instance!.addPostFrameCallback((_) =>
        initData()
    );

  }

  @override
  void dispose() {
    super.dispose();
    scrollController.dispose();
    _streamController.close();
  }

  initData() async {
    final dd = await Provider.of<OnlineProvider>(context, listen: false).getAllCancelledOnlineOrders(currentPage);
    _streamController.add(dd);
  }

  Widget onlineOrderContainer(OnlineOrder order){
    return InkWell(
      onTap: (){
        Provider.of<OnlineProvider>(context, listen: false).setSelectedOnlineOrder(order);
        Get.to(() => OnlineOrderDetailsScreen(onlineOrder: order));
      },
      child: Padding(
        padding: const EdgeInsets.only(top: 8, bottom: 8, left: 20, right: 20),
        child: Container(
          height: 120,
          width: Get.width,
          decoration: BoxDecoration(
              color: Color(0x0c662d6c),
              borderRadius: BorderRadius.all(Radius.circular(20))
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 10.0, right: 5, left: 20),
                child: Container(child: Text(Jiffy(order.createdAt).fromNow(), maxLines: 1, overflow: TextOverflow.ellipsis, style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold'),)),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 5.0, right: 20, left: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text("${order.productDetails![0].name} ".capitalize! + "...", overflow: TextOverflow.ellipsis, style:  TextStyle(fontSize: 12, color: grey),)),
                    Expanded(child: Text(currencyFormat.format(order.totalAmount), textAlign: TextAlign.right, style:  TextStyle(fontSize: 12, color: mvsblue, fontFamily: 'Roboto'),))
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 1.0, right: 20, left: 20),
                child: Divider(thickness: 2, color: Color(0xb3662d6c),),
              ),

              Padding(
                padding: const EdgeInsets.only(top: 1.0, right: 20, left: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("${order.productDetails!.length}".toString() + " item(s) ordered", style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular')),
                    Text(Jiffy(order.createdAt).yMd, style:  TextStyle(fontSize: 12, fontFamily: 'PoppinsRegular'))
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }

  Widget _featuredProductsWidget(){
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: StreamBuilder<List<OnlineOrder>?>(
          stream: _streamController.stream,//Provider.of<LandingProvider>(context, listen: true).futureProducts,
          builder: (context, snapshot){
            if(snapshot.hasError){
              return Center(child: Text("Error occurred retrieving data..."),);
            }else if (snapshot.connectionState == ConnectionState.waiting){
              return Center(child: Text("Loading....", style: TextStyle(color: Colors.black),),);
            }
            else if(snapshot.data == null){
              return Center(child: Text("No Order found...", style: TextStyle(color: Colors.black),),);
            }
            else if(snapshot.hasData == true){
              print("snapshot length: ${snapshot.data!.length}");
              return snapshot.data!.length == 0 ?
              Center(child: Text("online order is empty..", style: TextStyle(color: Colors.black),),)
                  : ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, i){
                    OnlineOrder _order = snapshot.data![i];
                    return onlineOrderContainer(_order);
                  }
              );
            }
            else{
              print("snapshot length: ${snapshot.data!.length}");
              return Center(child: Text("No data found...", style: TextStyle(color: Colors.black),),);
            }

          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          backgroundColor: whiteBG,
          appBar: AppBar(
            elevation: 5.0,
            centerTitle: true,
            title: Text(
              "All Cancelled Online Orders",
              style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
            ),
            backgroundColor: whiteBG,
            leading: IconButton(
              icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
              onPressed: () => Get.offAll(LandingScreen()),
            ),


          ),
          body: Container(
              width: Get.width,
              height: Get.height,
              child: _featuredProductsWidget()
          ),

        )
    );
  }
}

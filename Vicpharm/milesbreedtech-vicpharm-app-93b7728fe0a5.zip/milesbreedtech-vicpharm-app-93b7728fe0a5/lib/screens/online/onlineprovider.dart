import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vicpharm_app/models/onlineorder.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/onlinehttpservice.dart';

class OnlineProvider with ChangeNotifier {
  final OnlineHttpService _httpService = OnlineHttpService();

  List<OnlineOrder>? _onlineOrders = [];
  List<OnlineOrder>? get onlineOrders => _onlineOrders;

  List<OnlineOrder>? _approvedOnlineOrders = [];
  List<OnlineOrder>? get approvedOnlineOrders => _approvedOnlineOrders;

  List<OnlineOrder>? _transitOnlineOrders = [];
  List<OnlineOrder>? get transitOnlineOrders => _transitOnlineOrders;

  List<OnlineOrder>? _packedOnlineOrders = [];
  List<OnlineOrder>? get packedOnlineOrders => _packedOnlineOrders;

  List<OnlineOrder>? _issuesOnlineOrders = [];
  List<OnlineOrder>? get issuesOnlineOrders => _issuesOnlineOrders;

  List<OnlineOrder>? _completedOnlineOrders = [];
  List<OnlineOrder>? get completedOnlineOrders => _completedOnlineOrders;

  List<OnlineOrder>? _cancelledOnlineOrders = [];
  List<OnlineOrder>? get cancelledOnlineOrders => _cancelledOnlineOrders;

  OnlineOrder? _selectedOnlineOrder;
  OnlineOrder? get selectedOnlineOrder => _selectedOnlineOrder;

  int? _totalOrders = 0;
  int? get totalOrders => _totalOrders;

  int? _orderTotalPage = 0;
  int? get orderTotalPage => _orderTotalPage;

  setSelectedOnlineOrder(OnlineOrder oo){
    _selectedOnlineOrder = oo;
  }

  Future<List<OnlineOrder>?> getAllOnlineOrders(int page) async{
    print("ARE WE HERE");
    final response = await _httpService.allOnlineOrdersRequest(page);
    if(response == null){
      //LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
          "Ouch",
          "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){
      var data = payload['Order'];
      var listData = [];
      if(page == 1){
        _onlineOrders!.clear();
      }

      for(var i = 0; i < data.length; i++){
       try{
          OnlineOrder oo = OnlineOrder.fromJson(data[i]);
          print(oo.totalAmount);
          _onlineOrders!.add(oo);
        }catch(e){
          print(e);
        }
      }
      print(data.runtimeType);
      notifyListeners();
      _orderTotalPage = (payload['totalItems']/20).ceil();
      return _onlineOrders;
    }
    else{
      LoadingControl.showSnackBar(
          "Ouch",
          "${payload['message']}",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }


  }

  Future<List<OnlineOrder>?> getAllApprovedOnlineOrders(int page) async{
    print("ARE WE HERE");
    final response = await _httpService.allApprovedOnlineOrdersRequest(page);
    if(response == null){
      //LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
          "Ouch",
          "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){
      var data = payload['Order'];
      var listData = [];
      if(page == 1){
        _approvedOnlineOrders!.clear();
      }

      for(var i = 0; i < data.length; i++){
        try{
          OnlineOrder oo = OnlineOrder.fromJson(data[i]);
          print(oo.totalAmount);
          _approvedOnlineOrders!.add(oo);
        }catch(e){
          print(e);
        }
      }
  ;
      notifyListeners();
      _orderTotalPage = (payload['totalItems']/20).ceil();
      return _approvedOnlineOrders;
    }
    else{
      LoadingControl.showSnackBar(
          "Ouch",
          "${payload['message']}",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }


  }

  Future<List<OnlineOrder>?> getAllTransitOnlineOrders(int page) async{
    print("ARE WE HERE");
    final response = await _httpService.allTransitOnlineOrdersRequest(page);
    if(response == null){
      //LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
          "Ouch",
          "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){
      var data = payload['Order'];
      var listData = [];
      if(page == 1){
        _transitOnlineOrders!.clear();
      }

      for(var i = 0; i < data.length; i++){
        try{
          OnlineOrder oo = OnlineOrder.fromJson(data[i]);
          print(oo.totalAmount);
          _transitOnlineOrders!.add(oo);
        }catch(e){
          print(e);
        }
      }
      ;
      notifyListeners();
      _orderTotalPage = (payload['totalItems']/20).ceil();
      return _transitOnlineOrders;
    }
    else{
      LoadingControl.showSnackBar(
          "Ouch",
          "${payload['message']}",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }


  }

  Future<List<OnlineOrder>?> getAllPackedOnlineOrders(int page) async{
    print("ARE WE HERE");
    final response = await _httpService.allPackedOnlineOrdersRequest(page);
    if(response == null){
      //LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
          "Ouch",
          "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){
      var data = payload['Order'];
      var listData = [];
      if(page == 1){
        _packedOnlineOrders!.clear();
      }

      for(var i = 0; i < data.length; i++){
        try{
          OnlineOrder oo = OnlineOrder.fromJson(data[i]);
          print(oo.totalAmount);
          _packedOnlineOrders!.add(oo);
        }catch(e){
          print(e);
        }
      }
      ;
      notifyListeners();
      _orderTotalPage = (payload['totalItems']/20).ceil();
      return _packedOnlineOrders;
    }
    else{
      LoadingControl.showSnackBar(
          "Ouch",
          "${payload['message']}",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }


  }

  Future<List<OnlineOrder>?> getAllIssuesOnlineOrders(int page) async{
    print("ARE WE HERE");
    final response = await _httpService.allIssuesOnlineOrdersRequest(page);
    if(response == null){
      //LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
          "Ouch",
          "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){
      var data = payload['Order'];
      var listData = [];
      if(page == 1){
        _issuesOnlineOrders!.clear();
      }

      for(var i = 0; i < data.length; i++){
        try{
          OnlineOrder oo = OnlineOrder.fromJson(data[i]);
          print(oo.totalAmount);
          _issuesOnlineOrders!.add(oo);
        }catch(e){
          print(e);
        }
      }
      ;
      notifyListeners();
      _orderTotalPage = (payload['totalItems']/20).ceil();
      return _issuesOnlineOrders;
    }
    else{
      LoadingControl.showSnackBar(
          "Ouch",
          "${payload['message']}",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }


  }

  Future<List<OnlineOrder>?> getAllCompletedOnlineOrders(int page) async{
    print("ARE WE HERE");
    final response = await _httpService.allCompletedOnlineOrdersRequest(page);
    if(response == null){
      //LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
          "Ouch",
          "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){
      var data = payload['Order'];
      var listData = [];
      if(page == 1){
        _completedOnlineOrders!.clear();
      }

      for(var i = 0; i < data.length; i++){
        try{
          OnlineOrder oo = OnlineOrder.fromJson(data[i]);
          print(oo.totalAmount);
          _completedOnlineOrders!.add(oo);
        }catch(e){
          print(e);
        }
      }
      ;
      notifyListeners();
      _orderTotalPage = (payload['totalItems']/20).ceil();
      return _completedOnlineOrders;
    }
    else{
      LoadingControl.showSnackBar(
          "Ouch",
          "${payload['message']}",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }


  }

  Future<List<OnlineOrder>?> getAllCancelledOnlineOrders(int page) async{
    print("ARE WE HERE");
    final response = await _httpService.allCancelledOnlineOrdersRequest(page);
    if(response == null){
      //LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
          "Ouch",
          "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){
      var data = payload['Order'];
      var listData = [];
      if(page == 1){
        _cancelledOnlineOrders!.clear();
      }

      for(var i = 0; i < data.length; i++){
        try{
          OnlineOrder oo = OnlineOrder.fromJson(data[i]);
          print(oo.totalAmount);
          _cancelledOnlineOrders!.add(oo);
        }catch(e){
          print(e);
        }
      }
      ;
      notifyListeners();
      _orderTotalPage = (payload['totalItems']/20).ceil();
      return _cancelledOnlineOrders;
    }
    else{
      LoadingControl.showSnackBar(
          "Ouch",
          "${payload['message']}",
          Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }


  }

}
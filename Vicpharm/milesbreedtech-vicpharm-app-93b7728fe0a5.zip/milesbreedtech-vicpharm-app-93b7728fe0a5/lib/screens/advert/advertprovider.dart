import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:vicpharm_app/models/advert.dart';
import 'package:vicpharm_app/utils/httpservice.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';

class AdvertProvider with ChangeNotifier {
  final HttpService _httpService = new HttpService();

  List<Advert>? _adverts = [];
  
  List<Advert>? get adverts => _adverts;

  clearAdverts(){
    _adverts!.clear();
  }

  allAdverts() async{
    LoadingControl.showLoading();
    final response = await _httpService.getAllAdvertsRequest();

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){   

      var data = payload['Adverts'];
      for (var i = 0; i < data.length; i++) {
        try{
          Advert ad = Advert.fromJson(data[i]);
          _adverts!.add(ad);
        }catch(e){
          print(e);
        }
      }

      LoadingControl.dismissLoading();  
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }


  createAdvert(String advert) async{
    LoadingControl.showLoading();
    final response = await _httpService.createAdvertRequest(advert);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Advert added successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );
         
      
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
   else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  deleteAdvert(String advertId) async{
    LoadingControl.showLoading();
    final response = await _httpService.deleteAdvertRequest(advertId);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Advert deleted successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );
         
      
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

}
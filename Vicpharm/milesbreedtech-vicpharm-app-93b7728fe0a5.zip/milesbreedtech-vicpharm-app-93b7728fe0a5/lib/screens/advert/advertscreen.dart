import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/advert/advertprovider.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class AdvertScreen extends StatefulWidget {
  AdvertScreen({Key? key}) : super(key: key);

  @override
  _AdvertScreenState createState() => _AdvertScreenState();
}

class _AdvertScreenState extends State<AdvertScreen> {

  TextEditingController nameController = TextEditingController();

  @override
  void initState() { 
    super.initState();
    Provider.of<AdvertProvider>(context, listen: false).clearAdverts();
    Provider.of<AdvertProvider>(context, listen: false).allAdverts();
  }

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Store Adverts",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),

    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Navigator.of(context).pop(),
    ),

    
  );

  Widget nameField(BuildContext context) => TextField(
    
        
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: nameController,
        style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.text,
        textInputAction: TextInputAction.search,
        
        
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Enter Advert Here",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        

      );
  



  Widget mainContainer(BuildContext context){

    return Container(
      color: whiteBG,
      width: Get.width,
      height: Get.height,      
      child: SingleChildScrollView(
        
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Row(
                children: [
                  SizedBox(
                    width: Get.width * 0.75,
                    child: nameField(context),
                  ),

                  SizedBox(width: 10,),

                  SizedBox(
                    width: Get.width *0.1,
                    child: InkWell(
                      onTap: (){
                        if(nameController.text.isEmpty){
                          LoadingControl.showSnackBar(
                            "Ouchs!!!", 
                            "Advert content is required", 
                            Icon(Icons.error, color: Colors.red,)
                          );
                          return;
                        }
                        Provider.of<AdvertProvider>(context, listen: false).createAdvert(nameController.text);
                      },
                      child: Icon(Icons.send_rounded, color: mainColor,),
                    )
                  )
                ],
              ),
            ),

            Column(
              children: List.generate(Provider.of<AdvertProvider>(context, listen: true).adverts!.length, (index) => 
                ListTile(
                  leading: Text("${index + 1}", style: TextStyle(color: mainColor, fontFamily: 'PoppinsRegular', fontSize: 12), ),
                  title: Text("${Provider.of<AdvertProvider>(context, listen: true).adverts![index].advert}",
                          style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12),),
                  trailing: InkWell(
                    onTap: (){
                      Provider.of<AdvertProvider>(context, listen: false).deleteAdvert(Provider.of<AdvertProvider>(context, listen: false).adverts![index].sId!);
                    },
                    child: Icon(Icons.delete, color: Colors.red,),
                  ),
                )
              )
            )
          ],
        ),
      ),
    );
  }

  
   @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: appbar(context),
        backgroundColor: whiteBG,
        body: mainContainer(context),
      ),
    );
  }

}
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/misc/miscprovider.dart';
import 'package:vicpharm_app/screens/misc/startmiscscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class MiscSelectProductScreen extends StatefulWidget {
  @override
  _MiscSelectProductScreenState createState() => _MiscSelectProductScreenState();
}

class _MiscSelectProductScreenState extends State<MiscSelectProductScreen> {
  
  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Select Product",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 16,),
      onPressed: () => Get.back(),
    ),


  );
  
  @override
  Widget build(BuildContext context) {
    return SafeArea(
       child: Scaffold(
         appBar: appbar(context),
         body: ListView.builder(
           itemCount: Provider.of<MiscProvider>(context, listen: true).products!.length,
           itemBuilder: (BuildContext context, int index) {
             var pss = Provider.of<MiscProvider>(context, listen: true).products;
           return Padding(
             padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
             child: ListTile(
               onTap: (){
                 Provider.of<MiscProvider>(context, listen: false).setSelectedProduct(pss![index]);
                 Get.to(() => StartMiscEvent());
               },
               title: Text("${pss![index].name}", style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12),),
                trailing: Icon(Icons.arrow_forward_ios_rounded, color: mainColor,),
             ),
            );
          },
         ),
       )
    );
  }
}
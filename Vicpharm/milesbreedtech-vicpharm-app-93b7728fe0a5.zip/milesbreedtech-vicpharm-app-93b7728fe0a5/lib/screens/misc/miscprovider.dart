import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/models/category.dart';
import 'package:vicpharm_app/models/misc.dart';
import 'package:vicpharm_app/models/product.dart';
import 'package:vicpharm_app/models/salerecord.dart';
import 'package:vicpharm_app/screens/misc/misceventscreen.dart';
import 'package:vicpharm_app/screens/misc/miscselectproductscreen.dart';
import 'package:vicpharm_app/utils/httpservice.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';

class MiscProvider with ChangeNotifier {
  final HttpService _httpService = new HttpService();

  List<Misc>? _miscs = [];
  Misc? _selectedMisc;
  Future<List<Misc>?>? _futureMisc;
  int? _miscTotalPage;
  List<Product>? _products = [];
  Product? _selectedProduct;
  RefreshController _refreshController = RefreshController();

  RefreshController get refreshController => _refreshController;

  List<Product>? get products => _products;
  Product? get selectedproduct => _selectedProduct;
  List<Misc>? get miscs => _miscs;
  Misc? get selectedMisc => _selectedMisc;
  Future<List<Misc>?>? get futureMisc => _futureMisc;
  int? get miscTotalPage => _miscTotalPage;

  setSelectedMisc(Misc rp){
    _selectedMisc = rp;
  }

  setFutureList(Future<List<Misc>?>? st){
    _futureMisc = st;
    notifyListeners();
  }

  Future<List<Misc>?> populateMiscRecords(int page) async{
    print("step 1");
    var data = await getMiscEvents(page);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _miscs!.clear();

    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        String createdAt = data[i]['createdAt'];
        String comments = data[i]['comments'];
        //double totalAmount= data[i]['totalAmount'].toDouble();
        StaffId staffId = StaffId.fromJson(data[i]['staffId']);

       

        var productDetailsJson = data[i]['productDetails'];
        print("len of prod details: ${productDetailsJson.runtimeType}");
        print("type ${productDetailsJson.length}");
        List<ProductDetails> productDetails = [];

        for (var j = 0; j < productDetailsJson.length; j++) {
          print("for seling price map");
          Map<String, dynamic> sellingPrice = Map<String, dynamic>();
          sellingPrice.addAll(productDetailsJson[j]['sellingPrice']);
          print("sellig price: ${sellingPrice}");

          Map<String, dynamic> quantity = Map<String, dynamic>();
          quantity.addAll(productDetailsJson[j]['quantity']);

          //double tm = productDetailsJson[j]['totalAmount'].toDouble();
          //print("tm3 ${tm}");
          String productName = productDetailsJson[j]['productName'];
          String id = productDetailsJson[j]['id'];

          ProductDetails pds = ProductDetails(
            sellingPrice: sellingPrice,
            quantity: quantity,
            //totalAmount: tm,
            productName: productName,
            id: id
          );

          productDetails.add(pds);
        }

        Misc cust = Misc(
          productDetails: productDetails,
          createdAt: createdAt,
          sId: sId,
          comments: comments,
          staffId: staffId,
          //totalAmount: totalAmount
        ); 

        print(cust);
        
        _miscs!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        //throw(e);
        _refreshController.loadFailed();
      }
            
                
    }

    _refreshController.loadComplete();
    return _miscs;
  }
  
  setSelectedProduct(Product cust){
    if(cust != null){
      _selectedProduct = cust;
    }
  }

 
  Future<List<Product>?> populateSearchProduct(String query) async{
    var data = await searchProduct(query);
    if(data == null){
      LoadingControl.dismissLoading();
      return null;
    }
    print("staff length: ${data.length}" );
    _products!.clear();
    print("staff length:2 ${_products!.length}" );

    for(var i = 0; i < data.length; i++){
      try {
        List<String> unitOfMeasurement = [];
        unitOfMeasurement = data[i]['unitOfMeasurement'].cast<String>();
        List<String> barCode = data[i]['barCode'].cast<String>();
        
       
        
        // gather category array data
        var catData = data[i]['category'];
        List<Category> categories = [];
        for(var j = 0; j < catData.length; j++){
          try {
            Category cat = Category.fromJson(catData[j]);
            categories.add(cat);
          } catch (e) {
            print(e);
          }
        }
        print("steping2 ${i}");

        String sId = data[i]['_id'];
        String name = data[i]['name'];

        Map<String, dynamic> limitPrice = Map<String, dynamic>();
        limitPrice.addAll(data[i]['limitPrice']);

        Map<String, dynamic> sellingPrice = Map<String, dynamic>();
        sellingPrice.addAll(data[i]['sellingPrice']);

        Map<String, dynamic> costPrice = Map<String, dynamic>();
        costPrice.addAll(data[i]['costPrice']);

        Map<String, dynamic> quantity = Map<String, dynamic>();
        quantity.addAll(data[i]['quantity']);

        Map<String, dynamic> discountUnit = Map<String, dynamic>();
        discountUnit.addAll(data[i]['discountUnit']);

        Map<String, dynamic> discountType = Map<String, dynamic>();
        discountType.addAll(data[i]['discountType']);

        Map<String, dynamic> discount = Map<String, dynamic>();
        discount.addAll(data[i]['discount']);

        Map<String, dynamic> reOrderLimit = Map<String, dynamic>();
        reOrderLimit.addAll(data[i]['reOrderLimit']);

        String expiryDate = data[i]['expiryDate'];
        bool status =  data[i]['status'];
        String createdAt = data[i]['createdAt'];

        Product cust = Product(
          unitOfMeasurement: unitOfMeasurement,
          barCode: barCode,
          category: categories,
          sId: sId,
          name: name,
          status: status,
          limitPrice: limitPrice,
          sellingPrice: sellingPrice,
          costPrice: costPrice,
          quantity: quantity,
          sellQuantity: Map<String, dynamic>(),
          discountUnit: discountUnit,
          discountType: discountType,
          discount: discount,
          reOrderLimit: reOrderLimit,
          expiryDate: expiryDate,
          createdAt: createdAt,
        ); 

        print(cust);
        
        _products!.add(cust); 
        print(cust);
      } catch (e) {
        print(e);
      }           
                
    }
    print("is it here");
    LoadingControl.dismissLoading();
    if(_products!.length > 0){
      Get.to(() => MiscSelectProductScreen());
    }else{
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "No Product found....", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _products;
  }

 
  
  Future<List<dynamic>?> searchProduct(String query) async{
    LoadingControl.showLoading();
    final response = await _httpService.searchProductRequest(query);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){  

      var data = payload['Product'];
      return data;
       
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }


  Future<List<dynamic>?> getMiscEvents(int page) async{
   
    final response = await _httpService.getMiscEventsRequest(page);
    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["Miscellaneous"];    
      _miscTotalPage = (payload['totalItems']/50).ceil(); 
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  createMiscEvent(String comments, List<Map<String, dynamic>> mapQtys) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.createMiscEventRequest(comments, mapQtys);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Misc event created successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         

      Get.offAll(() => MiscEventScreen());
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  Future<List<Misc>?> populateStaffMiscRecords(int page, String staffId) async{
    print("step 1");
    var data = await getStaffMiscEvents(page, staffId);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _miscs!.clear();

    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
               
        String sId = data[i]['_id'];
        String createdAt = data[i]['createdAt'];
        String comments = data[i]['comments'];
        //double totalAmount= data[i]['totalAmount'].toDouble();
        StaffId staffId = StaffId.fromJson(data[i]['staffId']);

       

        var productDetailsJson = data[i]['productDetails'];
        print("len of prod details: ${productDetailsJson.runtimeType}");
        print("type ${productDetailsJson.length}");
        List<ProductDetails> productDetails = [];

        for (var j = 0; j < productDetailsJson.length; j++) {
          print("for seling price map");
          Map<String, dynamic> sellingPrice = Map<String, dynamic>();
          sellingPrice.addAll(productDetailsJson[j]['sellingPrice']);
          print("sellig price: ${sellingPrice}");

          Map<String, dynamic> quantity = Map<String, dynamic>();
          quantity.addAll(productDetailsJson[j]['quantity']);

          //double tm = productDetailsJson[j]['totalAmount'].toDouble();
          //print("tm3 ${tm}");
          String productName = productDetailsJson[j]['productName'];
          String id = productDetailsJson[j]['id'];

          ProductDetails pds = ProductDetails(
            sellingPrice: sellingPrice,
            quantity: quantity,
            //totalAmount: tm,
            productName: productName,
            id: id
          );

          productDetails.add(pds);
        }

        Misc cust = Misc(
          productDetails: productDetails,
          createdAt: createdAt,
          sId: sId,
          comments: comments,
          staffId: staffId,
          //totalAmount: totalAmount
        ); 

        print(cust);
        
        _miscs!.add(cust); 
        print(cust);
     } catch (e) {
        print(e);
        //throw(e);
      }
            
                
    }
    return _miscs;
  }
    
  Future<List<dynamic>?> getStaffMiscEvents(int page, String staffId) async{
   
    final response = await _httpService.getStaffMiscRecordRequest(page, staffId);
    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){         
      var data = payload["Miscellaneous"];    
      _miscTotalPage = (payload['totalItems']/50).ceil(); 
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
   else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

}
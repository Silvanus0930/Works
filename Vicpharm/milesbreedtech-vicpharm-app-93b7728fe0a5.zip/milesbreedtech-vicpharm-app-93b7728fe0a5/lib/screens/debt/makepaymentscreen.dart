import 'package:flutter/material.dart';
import 'package:flutter_money_formatter/flutter_money_formatter.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/models/creditsalerecord.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/auth/loginscreen.dart';
import 'package:vicpharm_app/screens/sales/salesprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class MakePaymentScreen extends StatefulWidget {
  final String? debtId;
  final List<Paid>? paids;
  final double? remainingAmt;
  MakePaymentScreen({Key? key, required this.debtId, required this.paids, this.remainingAmt}) : super(key: key);

  @override
  _MakePaymentScreenState createState() => _MakePaymentScreenState();
}

class _MakePaymentScreenState extends State<MakePaymentScreen> {
  TextEditingController amountController = new TextEditingController(); 


  @override
  void initState() { 
    super.initState();
    checkAuth();
  }
  
   void checkAuth() async{
    Provider.of<AuthProvider>(context, listen: false).validateJwt().then((value)
      {
        if(value == false){
          Get.offAll(LoginScreen());
        }
      }
    );
  }

  
  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Make Payment",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Navigator.of(context).pop(),
    ),


  );

  
  Widget amountField(BuildContext context) => TextField(
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: amountController,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.numberWithOptions(decimal: true),
        textInputAction: TextInputAction.done,
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Enter Amount, Unpaid Debt: NGN ${widget.remainingAmt}",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
       

      );
  

  Widget mainLayer(BuildContext context) => Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: whiteBG,
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
         
            Padding(
              padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
              child: amountField(context)
            ),
            SizedBox(height: 15,),

            Column(
              children: List.generate(widget.paids!.length, (index) {
                FlutterMoneyFormatter  fmf = FlutterMoneyFormatter(
                  amount: widget.paids![index].amount,//widget.salesRecord.productDetails[i].totalPrice != null ? widget.salesRecord.productDetails[i].totalPrice.toDouble() : 0.0,
                  settings: MoneyFormatterSettings(
                    symbol: "NGN",
                    thousandSeparator: ',',
                    decimalSeparator: '.',
                    symbolAndNumberSeparator: ' ',
                    fractionDigits: 2,
                  ));
                return ListTile(
                  title: Text('Amount: ', style: TextStyle(fontFamily: 'PoppimsSemiBold', fontSize: 12),),
                  trailing: Text('${fmf.output.symbolOnLeft}', style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12),),
                );
              }

              ),
            ),

            SizedBox(height: 15,),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.08,
              width: MediaQuery.of(context).size.width,
              child: Padding(
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: ElevatedButton(
                  onPressed: (){
                    if(amountController.text.isNotEmpty){
                       Provider.of<SalesProvider>(context, listen: false).payCreditSale(widget.debtId!, double.parse(amountController.text));
                    }
                   
                  },
                  
                  
                  child: Text('Pay', style: TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'PoppinsRegular'),),
                ),
              ),
            )

          ],
        ),
      )

    //child: contentStack(context),
  );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
       
          backgroundColor: whiteBG,
          appBar: appbar(context),
          body: mainLayer(context)

        )
    );
  }
}
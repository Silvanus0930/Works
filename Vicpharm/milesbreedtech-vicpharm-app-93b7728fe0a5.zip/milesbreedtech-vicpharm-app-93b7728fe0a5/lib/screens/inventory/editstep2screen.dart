import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/models/inventory.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/screens/landing/landingprovider.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class EditStep2Screen extends StatefulWidget {
  @override
  _EditStep2ScreenState createState() => _EditStep2ScreenState();
}

class _EditStep2ScreenState extends State<EditStep2Screen> {
  List<TextEditingController> costPriceControllers = [];
  List<TextEditingController> sellPriceControllers = [];
    List<TextEditingController> qtyControllers = [];
  List<TextEditingController> reOrderPriceControllers = [];
  List<TextEditingController> discountUnitControllers = [];
  List<TextEditingController> discountControllers = [];

  List<bool> _hideUnit = [];
  List<bool> _hideDisc = [];

  List<String> discountTypes = ["none", "single", "bulk"];
  List<String> discountType = [];

  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => initData());
    
  }

  initData() async {
    //costPriceControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController());
    sellPriceControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController());
    //qtyControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController());
    reOrderPriceControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController());
    discountUnitControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController());
    discountControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController());

    //costPriceController.text = Provider.of<InventoryProvider>(context, listen: false).mapCostPrice[]
    discountType = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => "none");
    print(discountType);
    _hideUnit = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => 
        false
      );
    _hideDisc = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => 
        false
      );
      print(_hideUnit);

      populateTextFields();
  }

  populateTextFields(){
    
    var ppv = Provider.of<InventoryProvider>(context, listen: false);
    var ppl = Provider.of<LandingProvider>(context, listen: false);
    print(ppv.mapDiscType);

    for (var i = 0; i < ppv.measurements!.length; i++) {
      
      ppv.setMapSellingPrice(
      ppv.measurements![i], 
      ppl.selectedproduct!.sellingPrice![ppv.measurements![i]]);
      sellPriceControllers[i].text = ppv.mapSellingPrice[ppv.measurements![i]].toString();

      ppv.setMapReorder(
      ppv.measurements![i], 
      ppl.selectedproduct!.reOrderLimit![ppv.measurements![i]]);
      reOrderPriceControllers[i].text = ppv.mapReorder[ppv.measurements![i]].toString();

      ppv.setMapDiscType(
      ppv.measurements![i], 
      ppl.selectedproduct!.discountType![ppv.measurements![i]]);
      setState(() {
        discountType[i] = ppv.mapDiscType[ppv.measurements![i]].toString();        
      });

      ppv.setMapDiscUnit(
      ppv.measurements![i], 
      ppl.selectedproduct!.discountUnit![ppv.measurements![i]]);
      discountUnitControllers[i].text = ppv.mapDiscUnit[ppv.measurements![i]].toString();

      ppv.setMapDisc(
      ppv.measurements![i], 
      ppl.selectedproduct!.discount![ppv.measurements![i]]);
      discountControllers[i].text = ppv.mapDisc[ppv.measurements![i]].toString();

    }
  }

  Widget saveBtn() {

    return Padding(
      padding: EdgeInsets.only(left: 20, right: 20.0, top: 20,  bottom: 20.0),
      child: SizedBox(
          height: Get.height * 0.08,
          width: Get.width * 0.4,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: () {
                if(Provider.of<InventoryProvider>(context, listen: false).selectedInventory!.name == null){
                  LoadingControl.showSnackBar(
                    "Ouchs!!!", 
                    "Product name required", 
                    Icon(Icons.error, color: Colors.red,)
                  );
                  return;
                }
                else if(Provider.of<InventoryProvider>(context, listen: false).selectedInventory!.name!.isEmpty){
                  LoadingControl.showSnackBar(
                    "Ouchs!!!", 
                    "Product name is required", 
                    Icon(Icons.error, color: Colors.red,)
                  );
                  return;
                } else if(Provider.of<InventoryProvider>(context, listen: false).measurements!.isEmpty){
                  LoadingControl.showSnackBar(
                    "Warning!!!", 
                    "You did not add a measurement unit. A default measurement unit have been added instead.", 
                    Icon(Icons.warning_amber_rounded, color: Colors.yellow,)
                  );
                  //Provider.of<InventoryProvider>(context, listen: false).addMeasurement("unit");
                  
                }
                Inventory inv = Inventory(
                  name: Provider.of<InventoryProvider>(context, listen: false).selectedInventory!.name,
                  
                  description: Provider.of<InventoryProvider>(context, listen: false).selectedInventory!.description,
                  sellingPrice: Provider.of<InventoryProvider>(context, listen: false).mapSellingPrice,
                  unitOfMeasurement: Provider.of<InventoryProvider>(context, listen: false).measurements,
                  discountUnit: Provider.of<InventoryProvider>(context, listen: false).mapDiscUnit,
                  discount: Provider.of<InventoryProvider>(context, listen: false).mapDisc,
                  discountType: Provider.of<InventoryProvider>(context, listen: false).mapDiscType,
                  reOrderLimit: Provider.of<InventoryProvider>(context, listen: false).mapReorder
                );

                Provider.of<InventoryProvider>(context, listen: false).editProduct(inv, Provider.of<LandingProvider>(context, listen: false).selectedproduct!.sId!);
              },
              color: mainColor,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Save",
                      style: TextStyle(fontSize: 14,
                      fontFamily: 'PoppinsSemiBold',
                      color: Colors.white
                    ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.save, size: 16, color: Colors.amber)
                  ),
                ],
              ),

            ),
          )
      ),
    );
  }


   
  @override
  Widget build(BuildContext context) {
    var invp = Provider.of<InventoryProvider>(context, listen: true);

    return Scaffold(
       body: SingleChildScrollView(
         child: Column(
           children: [
             Column(
               children: List.generate(invp.measurements!.length, (index) {
                 costPriceControllers[index].text = Provider.of<InventoryProvider>(context, listen: false).mapCostPrice[invp.measurements![index]].toString();
                 sellPriceControllers[index].text = Provider.of<InventoryProvider>(context, listen: false).mapSellingPrice[invp.measurements![index]].toString();
                 qtyControllers[index].text = Provider.of<InventoryProvider>(context, listen: false).mapQty[invp.measurements![index]].toString();
                 reOrderPriceControllers[index].text = Provider.of<InventoryProvider>(context, listen: false).mapReorder[invp.measurements![index]].toString();
                 discountUnitControllers[index].text = Provider.of<InventoryProvider>(context, listen: false).mapDiscUnit[invp.measurements![index]].toString();
                 discountControllers[index].text = Provider.of<InventoryProvider>(context, listen: false).mapDisc[invp.measurements![index]].toString();

                 return Container(
                  width: Get.width,
                  //color: Colors.amberAccent,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        child: Text("${invp.measurements![index]}", style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14, color: Colors.black),),
                      ),

                      
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                        child: TextField(
                          controller: sellPriceControllers[index],
                          onEditingComplete: () => FocusScope.of(context).nextFocus(),
                          style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12, color: Colors.black),
                          keyboardType: TextInputType.numberWithOptions(decimal: true),
                          decoration: InputDecoration(
                          filled: true,
                          fillColor: Color(0xffecf0f1),
                          border: OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            floatingLabelBehavior: FloatingLabelBehavior.never,
                            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                            hintText: "Selling Price",
                            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                      ),
        
                          onChanged: (String value){
                            if(value.isNotEmpty){
                              Provider.of<InventoryProvider>(context, listen: false).setMapSellingPrice(invp.measurements![index], double.parse(sellPriceControllers[index].text));
                              
                            }
                          },
                        ),
                      ),

                     
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                        child: TextField(
                          controller: reOrderPriceControllers[index],
                          onEditingComplete: () => FocusScope.of(context).nextFocus(),
                          style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12, color: Colors.black),
                          keyboardType: TextInputType.numberWithOptions(decimal: true),
                          decoration: InputDecoration(
                          filled: true,
                          fillColor: Color(0xffecf0f1),
                          border: OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            floatingLabelBehavior: FloatingLabelBehavior.never,
                            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                            hintText: "Reorder Limit",
                            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                      ),
        
                          onChanged: (String value){
                            if(value.isNotEmpty){
                              Provider.of<InventoryProvider>(context, listen: false).setMapReorder(invp.measurements![index], int.parse(reOrderPriceControllers[index].text));
                              
                            }
                          },
                        ),
                      ),

                      Padding(
                        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Container(
                          decoration: BoxDecoration(
                              color: Color(0xffecf0f1),
                              borderRadius: BorderRadius.all(Radius.circular(10))
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: DropdownButton<String>(
                              hint: Text("Select Discount Type",
                                  style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)
                              ),
                              value: discountType[index],
                              icon: Icon(Icons.arrow_drop_down, color: mainColor,),
                              elevation: 10,
                              style: TextStyle(color: mainColor),
                              underline: Container(
                                height: 1,
                                color: Colors.transparent,
                              ),
                              onChanged: (String? value){
                                setState(() {
                                  discountType[index] = value!;
                                  if(value == "none"){
                                    _hideUnit[index] = false;
                                    _hideDisc[index] = false;  
                                    Provider.of<InventoryProvider>(context, listen: false).setMapDisc(invp.measurements![index], 0.0);    
                                    Provider.of<InventoryProvider>(context, listen: false).setMapDiscUnit(invp.measurements![index], 0);                           
                                  }else if(value == "single"){
                                    _hideUnit[index] = false;
                                    _hideDisc[index] = true; 
                                  }else if(value == "bulk"){
                                    _hideUnit[index] = true;
                                    _hideDisc[index] = true;
                                  }                              
                                });
                                Provider.of<InventoryProvider>(context, listen: false).setMapDiscType(invp.measurements![index], discountType[index]);
                                
                              },
                              isExpanded: true,
                              items: discountTypes.map((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value , style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),),
                                );
                              }).toList(),
                            ),
                          ),
                        ),
                      ),
  

                      _hideUnit[index]?
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                        child: TextField(
                          controller: discountUnitControllers[index],
                          onEditingComplete: () => FocusScope.of(context).nextFocus(),
                          style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12, color: Colors.black),
                          keyboardType: TextInputType.numberWithOptions(decimal: true),
                          decoration: InputDecoration(
                          filled: true,
                          fillColor: Color(0xffecf0f1),
                          border: OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            floatingLabelBehavior: FloatingLabelBehavior.never,
                            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                            hintText: "Discount unit",
                            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                      ),
        
                          onChanged: (String value){
                            if(value.isNotEmpty){
                              Provider.of<InventoryProvider>(context, listen: false).setMapDiscUnit(invp.measurements![index], int.parse(discountUnitControllers[index].text));
                             
                            }
                          },
                        ),
                      )
                      : Container(),
                      
                      _hideUnit[index] || _hideDisc[index] ?
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                        child: TextField(
                          controller: discountControllers[index],
                          onEditingComplete: () => FocusScope.of(context).nextFocus(),
                          style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12, color: Colors.black),
                          keyboardType: TextInputType.numberWithOptions(decimal: true),
                          decoration: InputDecoration(
                          filled: true,
                          fillColor: Color(0xffecf0f1),
                          border: OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            floatingLabelBehavior: FloatingLabelBehavior.never,
                            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                            hintText: "Discount",
                            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                      ),
        
                          onChanged: (String value){
                            if(value.isNotEmpty){
                              Provider.of<InventoryProvider>(context, listen: false).setMapDisc(invp.measurements![index], double.parse(discountControllers[index].text));
                            }
                          },
                        ),
                      )
                      : Container()

                      
                    ],
                  ),
                );
               
               }
                
               ),
             ),

             saveBtn(),
           ],
         ),
       ),
    );
  }
}
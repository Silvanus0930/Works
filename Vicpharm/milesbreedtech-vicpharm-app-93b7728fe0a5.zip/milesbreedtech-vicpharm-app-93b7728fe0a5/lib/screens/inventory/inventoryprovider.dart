
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/models/category.dart';
import 'package:vicpharm_app/models/inventory.dart';
import 'package:vicpharm_app/screens/assortment/categoryscreen.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/utils/httpservice.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';

class InventoryProvider with ChangeNotifier {
  final HttpService _httpService = new HttpService();

  List<Inventory>? _inventories = [];
  Inventory? _selectedInventory;
  Future<List<Inventory>?>? _futureInventories;
  int? _inventoryTotalPage;
  List<Category>? _categories = [];
  Category? _selectedCategory;
  Future<List<Category>?>? _futureCategory;
  List<String>? _measurements = [];
  Inventory? _newInventory;
  List<String>? _barcodes = [];
  RefreshController _refreshController = RefreshController();

  RefreshController get refreshController => _refreshController;
  Future<List<Category>?>? get futureCategory => _futureCategory;
  List<String>? get barcodes => _barcodes;
  Inventory? get newInventory => _newInventory;
  List<String>? get measurements => _measurements;
  Category? get selectedCategory => _selectedCategory;
  List<Category>? get catgeories => _categories;
  List<Inventory>? get inventories => _inventories;
  Inventory? get selectedInventory => _selectedInventory;
  Future<List<Inventory>?>? get futureInventories => _futureInventories;
  int? get inventoryTotalPage => _inventoryTotalPage;

  String? _name;
  String? get name => _name;

  String? _disc;
  String? get disc => _disc;

  String? _expDate;
  String? get expDate => _expDate;

  String? _shelfNumber;
  String? get shelfNumber => _shelfNumber;

  setName(String nameP){
    _name = nameP;
  }

  setShelfNumber(String sn){
    _shelfNumber = sn;
  }

  setDisc(String nameP){
    _disc = nameP;
  }

  setExpDate(String nameP){
    _expDate = nameP;
  }

  addMeasurement(String unit){
    _measurements!.add(unit);
    notifyListeners();
  }

  removeMeasurement(String unit){
    _measurements!.remove(unit);
    notifyListeners();
  }

  clearMeasurements(){
    _measurements!.clear();
    notifyListeners();
  }

  bulkAddMeasurements(List<String> mss){
    _measurements!.clear();
    _measurements = mss;
    notifyListeners();
  }

  addBarcode(String unit){
    if(_barcodes!.contains(unit) == false){
      _barcodes!.add(unit);
      notifyListeners();
    }
  }

  removeBarcode(String unit){
    _barcodes!.remove(unit);
    notifyListeners();
  }

  clearBarcodes(){
    _barcodes!.clear();
    notifyListeners();
  }

  Map<String, dynamic> _mapCostPrice = Map<String, dynamic>();
  Map<String, dynamic> _mapSellingPrice = Map<String, dynamic>();
  Map<String, dynamic> _mapWholeSellPrice = Map<String, dynamic>();
  Map<String, dynamic> _mapQty = Map<String, dynamic>();
  Map<String, dynamic> _mapReorder = Map<String, dynamic>();
  Map<String, String> _mapDiscType = Map<String, String>();
  Map<String, dynamic> _mapDiscUnit = Map<String, dynamic>();
  Map<String, dynamic> _mapDisc = Map<String, dynamic>();

  Map<String, dynamic> get mapCostPrice => _mapCostPrice;
  Map<String, dynamic> get mapSellingPrice => _mapSellingPrice;
  Map<String, dynamic> get mapWholeSellPrice => _mapWholeSellPrice;
  Map<String, dynamic> get mapQty => _mapQty;
  Map<String, dynamic> get mapReorder => _mapReorder;
  Map<String, String> get mapDiscType => _mapDiscType;
  Map<String, dynamic> get mapDiscUnit => _mapDiscUnit;
  Map<String, dynamic> get mapDisc => _mapDisc;

  clearAllMaps(){
    _mapCostPrice.clear();
    _mapSellingPrice.clear();
    _mapWholeSellPrice.clear();
    _mapQty.clear();
    _mapReorder.clear();
    _mapDiscType.clear();
    _mapDiscUnit.clear();
    _mapDisc.clear();
  }

  
  setMapCostPrice(String key, dynamic value){
    _mapCostPrice[key] = value;
  }

  setMapSellingPrice(String key, dynamic value){
    _mapSellingPrice[key] = value;
  }

  setMapWholeSellPrice(String key, dynamic value){
    _mapWholeSellPrice[key] = value;
  }

  setMapQty(String key, dynamic value){
    _mapQty[key] = value;
  }

  setMapReorder(String key, dynamic value){
    _mapReorder[key] = value;
  }

  setMapDiscType(String key, dynamic value){
    _mapDiscType[key] = value;
  }

  setMapDiscUnit(String key, dynamic value){
    _mapDiscUnit[key] = value;
  }

  setMapDisc(String key, dynamic value){
    _mapDisc[key] = value;
  }

  setFutureList(Future<List<Inventory>?>? st){
    _futureInventories = st;
    notifyListeners();
  }

  setSelectedInventory(Inventory cust){
    if(cust != null){
      _selectedInventory = cust;
    }
  }

  setSelectedCategory(Category cat){
    _selectedCategory = cat;
    notifyListeners();
  }

  setFutureCategory(Future<List<Category>?>? st){
    _futureCategory = st;
    notifyListeners();
  }

  Future<List<Inventory>?> populateInventory(int page) async{
    print("step 1");
    var data = await retrieveInventory(page);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _inventories!.clear();
    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
        print(data[i]['unitOfMeasurement'].runtimeType);
        List<String> unitOfMeasurement = [];
        unitOfMeasurement = data[i]['unitOfMeasurement'].cast<String>();
        print(unitOfMeasurement);
        print(data[i]['barCode']);
        List<String> barCode = data[i]['barCode'].cast<String>();
        print(barCode);
        print("steping1 ${i}");
        
        // gather category array data
        var catData = data[i]['category'];
        List<Category> categories = [];
        for(var j = 0; j < catData.length; j++){
          try {
            Category cat = Category.fromJson(catData[j]);
            categories.add(cat);
          } catch (e) {
            print(e);
          }
        }
        print("steping2 ${i}");

        String sId = data[i]['_id'];
        String name = data[i]['name'];
        String description = data[i]['description'];
        bool soldOut = data[i]["soldOut"];
        String shelfNumber = data[i]["shelfNumber"];

        Map<String, dynamic> limitPrice = Map<String, dynamic>();
        limitPrice.addAll(data[i]['limitPrice']);

        Map<String, dynamic> sellingPrice = Map<String, dynamic>();
        sellingPrice.addAll(data[i]['sellingPrice']);

        Map<String, dynamic> costPrice = Map<String, dynamic>();
        costPrice.addAll(data[i]['costPrice']);

        Map<String, dynamic> quantity = Map<String, dynamic>();
        quantity.addAll(data[i]['quantity']);

        Map<String, dynamic> availableQuantity = Map<String, dynamic>();
        availableQuantity.addAll(data[i]['availableQuantity']);

        Map<String, dynamic> discountUnit = Map<String, dynamic>();
        discountUnit.addAll(data[i]['discountUnit']);

        Map<String, dynamic> discountType = Map<String, dynamic>();
        discountType.addAll(data[i]['discountType']);

        Map<String, dynamic> discount = Map<String, dynamic>();
        discount.addAll(data[i]['discount']);

        Map<String, dynamic> reOrderLimit = Map<String, dynamic>();
        reOrderLimit.addAll(data[i]['reOrderLimit']);

        String expiryDate = data[i]['expiryDate'];

        StaffId staffId = StaffId.fromJson(data[i]['staffId']);
        String inventoryTypes = data[i]['inventoryTypes'];
        String createdAt = data[i]['createdAt'];
        String updatedAt = data[i]['updatedAt'];

        Inventory cust = Inventory(
          unitOfMeasurement: unitOfMeasurement,
          barCode: barCode,
          category: categories,
          sId: sId,
          name: name,
          soldOut: soldOut,
          description: description,
          limitPrice: limitPrice,
          sellingPrice: sellingPrice,
          costPrice: costPrice,
          quantity: quantity,
          availableQuantity: availableQuantity,
          discountUnit: discountUnit,
          discountType: discountType,
          discount: discount,
          reOrderLimit: reOrderLimit,
          expiryDate: expiryDate,
          staffId: staffId,
          shelfNumber: shelfNumber,
          inventoryTypes: inventoryTypes,
          createdAt: createdAt,
          updatedAt: updatedAt
        ); 

        print(cust);
        
        _inventories!.add(cust); 
        print(cust);
      } catch (e) {
        print(e);
        _refreshController.loadFailed();
        //notifyListeners();
      }
            
                
    }
    refreshController.loadComplete();
    notifyListeners();
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _inventories;
  }


  Future<List<dynamic>?> retrieveInventory(int page) async{
    
    final response = await _httpService.getInventoryRequest(page);

    if(response == null){
      
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){     
      
      var data = payload["Inventory"];    
      _inventoryTotalPage = (payload['totalItems']/50).ceil();        
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
    else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  getAllCategories() async{
    LoadingControl.showLoading();
    
    final response = await _httpService.getAllCategoriesRequest();

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      var data = payload['Categories'];
      for (var i = 0; i < data.length; i++) {
        try{
          Category cat = Category.fromJson(data[i]);
          if(cat.subCategories!.length == 0){
            _categories!.add(cat);
          }
        }catch(e){
          print(e);
        }
      }

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Categories retrieved successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         

      
      
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  addInventory(Inventory inv) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.addInventoryRequest(inv, _selectedCategory!.sId!);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading(); 
      
       
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Product added successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );   

      Future.delayed(Duration(seconds: 2), () => Get.offAll(() => LandingScreen()));     
      
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  restockInventory(Inventory inv) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.restockInventoryRequest(inv, inv.sId!);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Product restocked successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         

      //Get.to(() => CustomerScreen());
      
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  Future<List<Category>?>? getAllCategoriesFuture() async{
    final response = await _httpService.getAllCategoriesRequest();

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      var data = payload['Categories'];
      _categories!.clear();
      for (var i = 0; i < data.length; i++) {
        try{
          Category cat = Category.fromJson(data[i]);          
          _categories!.add(cat);
        
        }catch(e){
          print(e);
        }
      }

     
      notifyListeners();
      return _categories;

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );

      return null;
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );

      return null;
     
    }
    
   else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  addCategory(String name) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.addCategoryRequest(name);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Category added successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );     

      getAllCategoriesFuture();    

      //Get.to(() => CategoryScreen());
      
     // notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  addSubCategory(String name) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.addSubCategoryRequest(name, _selectedCategory!.sId!);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Subcategory added successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );     

       

      Get.to(() => CategoryScreen());
      
     // notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
    
    else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  Future<List<Inventory>?> populateStaffInventory(int page, String staffId) async{
    print("step 1");
    var data = await retrieveStaffInventory(page, staffId);
    print("step 2");
    if(data == null){
      return null;
    }
    print("step 3");
    print("customer length: ${data.length}" );
    _inventories!.clear();
    for(var i = 0; i < data.length; i++){
      try {
        print("steping ${i}");
        print(data[i]['unitOfMeasurement'].runtimeType);
        List<String> unitOfMeasurement = [];
        unitOfMeasurement = data[i]['unitOfMeasurement'].cast<String>();
        print(unitOfMeasurement);
        print(data[i]['barCode']);
        List<String> barCode = data[i]['barCode'].cast<String>();
        print(barCode);
        print("steping1 ${i}");
        
        // gather category array data
        var catData = data[i]['category'];
        List<Category> categories = [];
        for(var j = 0; j < catData.length; j++){
          try {
            Category cat = Category.fromJson(catData[j]);
            categories.add(cat);
          } catch (e) {
            print(e);
          }
        }
        print("steping2 ${i}");

        String sId = data[i]['_id'];
        String name = data[i]['name'];
        String description = data[i]['description'];

        Map<String, dynamic> limitPrice = Map<String, dynamic>();
        limitPrice.addAll(data[i]['limitPrice']);

        Map<String, dynamic> sellingPrice = Map<String, dynamic>();
        sellingPrice.addAll(data[i]['sellingPrice']);

        Map<String, dynamic> costPrice = Map<String, dynamic>();
        costPrice.addAll(data[i]['costPrice']);

        Map<String, dynamic> quantity = Map<String, dynamic>();
        quantity.addAll(data[i]['quantity']);

        Map<String, dynamic> availableQuantity = Map<String, dynamic>();
        availableQuantity.addAll(data[i]['availableQuantity']);

        Map<String, dynamic> discountUnit = Map<String, dynamic>();
        discountUnit.addAll(data[i]['discountUnit']);

        Map<String, dynamic> discountType = Map<String, dynamic>();
        discountType.addAll(data[i]['discountType']);

        Map<String, dynamic> discount = Map<String, dynamic>();
        discount.addAll(data[i]['discount']);

        Map<String, dynamic> reOrderLimit = Map<String, dynamic>();
        reOrderLimit.addAll(data[i]['reOrderLimit']);

        String expiryDate = data[i]['expiryDate'];

        StaffId staffId = StaffId.fromJson(data[i]['staffId']);
        String inventoryTypes = data[i]['inventoryTypes'];
        String createdAt = data[i]['createdAt'];
        String updatedAt = data[i]['updatedAt'];

        Inventory cust = Inventory(
          unitOfMeasurement: unitOfMeasurement,
          barCode: barCode,
          category: categories,
          sId: sId,
          name: name,
          description: description,
          limitPrice: limitPrice,
          sellingPrice: sellingPrice,
          costPrice: costPrice,
          quantity: quantity,
          availableQuantity: availableQuantity,
          discountUnit: discountUnit,
          discountType: discountType,
          discount: discount,
          reOrderLimit: reOrderLimit,
          expiryDate: expiryDate,
          staffId: staffId,
          inventoryTypes: inventoryTypes,
          createdAt: createdAt,
          updatedAt: updatedAt
        ); 

        print(cust);
        
        _inventories!.add(cust); 
        print(cust);
      } catch (e) {
        print(e);
      }
            
                
    }
    //_futureStaff = _staffs as Future<List<Staff>?>?;
    return _inventories;
  }

  
  Future<List<dynamic>?> retrieveStaffInventory(int page, String staffId) async{
    
    final response = await _httpService.getStaffInventoryRecordRequest(page, staffId);

    if(response == null){
      
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){     
      
      var data = payload["Inventory"];    
      _inventoryTotalPage = (payload['totalItems']/50).ceil();        
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  editProduct(Inventory inv, String productId) async{
    LoadingControl.showLoading();
    
    final response = await _httpService.EditProductRequest(inv, productId);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";
    print(status);

    if (status.toLowerCase() == "ok" && statusCode == 201){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "product updated successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );         

      //Get.to(() => CustomerScreen());
      
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }

    else if(payload['status'].toLowerCase() == "fail"){
      print("error of 422");
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "${payload['message']}", 
        Icon(Icons.error, color: Colors.red,)
      );
     
    }
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

}
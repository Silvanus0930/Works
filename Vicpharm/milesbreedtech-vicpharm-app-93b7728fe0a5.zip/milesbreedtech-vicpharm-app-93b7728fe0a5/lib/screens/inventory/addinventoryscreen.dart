import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/screens/inventory/step1screem.dart';
import 'package:vicpharm_app/screens/inventory/step2screen.dart';
import 'package:vicpharm_app/screens/inventory/step3screen.dart';

class AddInventoryScreen extends StatefulWidget {
  AddInventoryScreen({Key? key}) : super(key: key);

  @override
  _AddInventoryScreenState createState() => _AddInventoryScreenState();
}

class _AddInventoryScreenState extends State<AddInventoryScreen> {
  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => initData());
  }

  initData(){
    Provider.of<InventoryProvider>(context, listen: false).getAllCategories();
    Provider.of<InventoryProvider>(context, listen: false).setName("");
    Provider.of<InventoryProvider>(context, listen: false).setDisc("");
    Provider.of<InventoryProvider>(context, listen: false).clearMeasurements();
    Provider.of<InventoryProvider>(context, listen: false).clearBarcodes();
    Provider.of<InventoryProvider>(context, listen: false).clearAllMaps();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
       child: DefaultTabController(
           length: 3,
           child: Scaffold(
             appBar: AppBar(
                bottom: TabBar(
                  tabs: [
                    Tab(text: "Basic Info"),
                    Tab(text: "Prices"),
                    Tab(text: "Barcode & Save"),
                  ],
                ),
                title: Text('Add Product'),
              ),
            body: TabBarView(
            children: [
              Step1Screen(),
              Step2Screen(),
              Step3Screen(),
            ],
          ),
           )
         )
    );
  }
}
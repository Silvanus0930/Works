import 'package:flutter/material.dart';
import 'package:flutter_qr_bar_scanner/qr_bar_scanner_camera.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/models/inventory.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class Step3Screen extends StatefulWidget {
  Step3Screen({Key? key}) : super(key: key);

  @override
  _Step3ScreenState createState() => _Step3ScreenState();
}

class _Step3ScreenState extends State<Step3Screen> {
  TextEditingController baroodeController = TextEditingController();
  String barcode = "";
  bool _camState = false;

  _scanCode() {
    setState(() {

     // _camState = true;
      if(_camState){
        //showFloatingActionButton(true);
        _camState =false;
      }else{
        _camState = true;
        //showFloatingActionButton(false);
      }
    });
  }

   _qrCallback(String code) async{
    setState(() {
      _camState = false;
      //showFloatingActionButton(true);
      barcode = code;
      baroodeController.text = barcode;
    });
    print("barcode scanned");
    print(this.barcode);

  }

  Widget panelBarcode(BuildContext context){
    return QRBarScannerCamera(
              onError: (context, error) => Text(
                error.toString(),
                style: TextStyle(color: Colors.red),
              ),
              qrCodeCallback: (code) {
                _qrCallback(code);
              },
              child: Container(
                width: double.infinity,
                height: double.infinity,
                color: Colors.transparent,
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        width: double.infinity,
                        height: MediaQuery.of(context).size.height * 0.08,
                        color: mainColor,
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Text(
                                'Focus camera on the barcode for efficiency',
                                style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                              ),

                              InkWell(
                                onTap: (){
                                  setState(() {
                                   _camState = _camState ? false : true;                                   
                                  });
                                },
                                child: Icon(Icons.close, color: Colors.red, size: 32,),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),

                    Align(
                      alignment: Alignment.center,
                      child: Image.asset("assets/images/ion_scan.png")
                    ),             
                    
                  ],
                ),
              ),
            );
          
  }
  
  Widget scanBtn() {

    return Padding(
      padding: EdgeInsets.only(left: 20, right: 20.0, top: 20,  bottom: 20.0),
      child: SizedBox(
          height: Get.height * 0.08,
          width: Get.width * 0.4,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: () {
                _scanCode();
              },

              color: mainColor,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Scan",
                      style: TextStyle(fontSize: 14,
                      fontFamily: 'PoppinsSemiBold',
                      color: Colors.white
                    ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.qr_code, size: 16, color: Colors.amber)
                  ),
                ],
              ),

            ),
          )
      ),
    );
  }

  Widget addBtn() {

    return Padding(
      padding: EdgeInsets.only(left: 20, right: 20.0, top: 20,  bottom: 20.0),
      child: SizedBox(
          height: Get.height * 0.08,
          width: Get.width * 0.4,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: () {
                if(baroodeController.text.isNotEmpty){
                  Provider.of<InventoryProvider>(context, listen: false).addBarcode(baroodeController.text);
                  baroodeController.clear();
                }
              },

              color: mainColor,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Add",
                      style: TextStyle(fontSize: 14,
                      fontFamily: 'PoppinsSemiBold',
                      color: Colors.white
                    ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.add, size: 16, color: Colors.amber)
                  ),
                ],
              ),

            ),
          )
      ),
    );
  }


  Widget saveBtn() {

    return Padding(
      padding: EdgeInsets.only(left: 20, right: 20.0, top: 20,  bottom: 20.0),
      child: SizedBox(
          height: Get.height * 0.08,
          width: Get.width * 0.4,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: () {
                if(Provider.of<InventoryProvider>(context, listen: false).name == null){
                  LoadingControl.showSnackBar(
                    "Ouchs!!!", 
                    "Product name required", 
                    Icon(Icons.error, color: Colors.red,)
                  );
                  return;
                }
                else if(Provider.of<InventoryProvider>(context, listen: false).name!.isEmpty || Provider.of<InventoryProvider>(context, listen: false).expDate!.isEmpty){
                  LoadingControl.showSnackBar(
                    "Ouchs!!!", 
                    "Product name and Expiry Date is required", 
                    Icon(Icons.error, color: Colors.red,)
                  );
                  return;
                } else if(Provider.of<InventoryProvider>(context, listen: false).selectedCategory == null){
                  LoadingControl.showSnackBar(
                    "Ouchs!!!", 
                    "Product category is required", 
                    Icon(Icons.error, color: Colors.red,)
                  );
                  return;
                }else if(Provider.of<InventoryProvider>(context, listen: false).measurements!.isEmpty){
                  LoadingControl.showSnackBar(
                    "Warning!!!", 
                    "You did not add a measurement unit.", 
                    Icon(Icons.warning_amber_rounded, color: Colors.yellow,)
                  );
                  return;
                  //Provider.of<InventoryProvider>(context, listen: false).addMeasurement("unit");
                  
                }else if(Provider.of<InventoryProvider>(context, listen: false).mapCostPrice.isEmpty){
                  LoadingControl.showSnackBar(
                    "Warning!!!", 
                    "You did not add a cost price for all measurement units.", 
                    Icon(Icons.warning_amber_rounded, color: Colors.yellow,)
                  );
                  return;
                  //Provider.of<InventoryProvider>(context, listen: false).addMeasurement("unit");
                  
                }else if(Provider.of<InventoryProvider>(context, listen: false).mapSellingPrice.isEmpty){
                  LoadingControl.showSnackBar(
                    "Warning!!!", 
                    "You did not add a selling price for all measurement units.", 
                    Icon(Icons.warning_amber_rounded, color: Colors.yellow,)
                  );
                  return;
                  //Provider.of<InventoryProvider>(context, listen: false).addMeasurement("unit");
                  
                }

                
            

                if(Provider.of<InventoryProvider>(context, listen: false).barcodes!.length == 0){
                  DateTime dd = DateTime.now();
                  String dd_s = dd.millisecondsSinceEpoch.toString();
                  String last9 = dd_s.length > 12 ? dd_s.substring(dd_s.length - 12) : dd_s;
                  Provider.of<InventoryProvider>(context, listen: false).addBarcode(last9);
                  print("generated barcode: ${last9}");
                }

                var mss = Provider.of<InventoryProvider>(context, listen: false).measurements;
                var mapCP = Provider.of<InventoryProvider>(context, listen: false).mapCostPrice;
                var mapSP = Provider.of<InventoryProvider>(context, listen: false).mapSellingPrice;
                var mapWHP = Provider.of<InventoryProvider>(context, listen: false).mapWholeSellPrice;
                var mapQty = Provider.of<InventoryProvider>(context, listen: false).mapQty;
                var mapRE = Provider.of<InventoryProvider>(context, listen: false).mapReorder;
                
                if(mapCP.keys.length != mss!.length ||
                  mapSP.keys.length != mss.length ||
                  mapWHP.keys.length != mss.length ||
                  mapQty.keys.length != mss.length ||
                  mapRE.keys.length != mss.length ){
                  LoadingControl.showSnackBar(
                    "Warning!!!", 
                    "Invalid data entry. Ensure you have provided all the required data especially the prices and discount type", 
                    Icon(Icons.warning_amber_rounded, color: Colors.yellow,)
                  );
                  return;
                }

               

                if(Provider.of<InventoryProvider>(context, listen: false).mapDiscType.entries.isEmpty){
                  // fill up discountype first if it is empty
                  // fill up discount unit. it will be empty
                  // fill up discount . it will be empty
                  var mss = Provider.of<InventoryProvider>(context, listen: false).measurements;
                  for (var i = 0; i < mss!.length; i++) {
                    print(mss[i]);
                    Provider.of<InventoryProvider>(context, listen: false).setMapDiscType("${mss[i]}", "none");
                    Provider.of<InventoryProvider>(context, listen: false).setMapDiscUnit("${mss[i]}", 0.0);
                    Provider.of<InventoryProvider>(context, listen: false).setMapDisc("${mss[i]}", 0.0);
                    Provider.of<InventoryProvider>(context, listen: false).setMapWholeSellPrice("${mss[i]}", 0.0);
                  }                
                  
                }

                // make sure all unit of measurements and prices are matching
                var mapDT = Provider.of<InventoryProvider>(context, listen: false).mapDiscType;
                

                print(mapDT.keys.length);
                print(mss.length);
                
                if(mapDT.keys.length != mss.length){
                  // since there are not even, find the missing keys and populate them
                  for (var i = 0; i < mss.length; i++) {
                    if(mapDT.containsKey(mss[i]) == false){ // this key was not found so fill it up
                      Provider.of<InventoryProvider>(context, listen: false).setMapDiscType("${mss[i]}", "none");
                      Provider.of<InventoryProvider>(context, listen: false).setMapDiscUnit("${mss[i]}", 0.0);
                      Provider.of<InventoryProvider>(context, listen: false).setMapDisc("${mss[i]}", 0.0);
                    }
                  }
                }

                

                Inventory inv = Inventory(
                  name: Provider.of<InventoryProvider>(context, listen: false).name,
                  barCode: Provider.of<InventoryProvider>(context, listen: false).barcodes,
                  description: Provider.of<InventoryProvider>(context, listen: false).disc,
                  sellingPrice: Provider.of<InventoryProvider>(context, listen: false).mapSellingPrice,
                  costPrice: Provider.of<InventoryProvider>(context, listen: false).mapCostPrice,
                  limitPrice: Provider.of<InventoryProvider>(context, listen: false).mapWholeSellPrice,
                  quantity: Provider.of<InventoryProvider>(context, listen: false).mapQty,
                  unitOfMeasurement: Provider.of<InventoryProvider>(context, listen: false).measurements,
                  discountUnit: Provider.of<InventoryProvider>(context, listen: false).mapDiscUnit,
                  discount: Provider.of<InventoryProvider>(context, listen: false).mapDisc,
                  discountType: Provider.of<InventoryProvider>(context, listen: false).mapDiscType,
                  shelfNumber: Provider.of<InventoryProvider>(context, listen: false).shelfNumber,
                  //categoryId: Provider.of<InventoryProvider>(context, listen: false).selectedCategory!.sId],
                  expiryDate: Provider.of<InventoryProvider>(context, listen: false).expDate,
                  reOrderLimit: Provider.of<InventoryProvider>(context, listen: false).mapReorder
                );

                Provider.of<InventoryProvider>(context, listen: false).addInventory(inv);
              },
              color: mainColor,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Save",
                      style: TextStyle(fontSize: 14,
                      fontFamily: 'PoppinsSemiBold',
                      color: Colors.white
                    ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.save, size: 16, color: Colors.amber)
                  ),
                ],
              ),

            ),
          )
      ),
    );
  }



  @override
  Widget build(BuildContext context) {
    var invp = Provider.of<InventoryProvider>(context, listen: true);

    return Scaffold(
       body: SingleChildScrollView(
         child: Container(
           width: Get.width,
           height: Get.height,
           child: Column(
             children: [
               _camState ?
               Expanded(child: panelBarcode(context))
               : Container(),

              _camState ?
              Container()

              : scanBtn(),

              _camState ?
              Container()

              :Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                      child: TextField(
                        controller: baroodeController,
                        onEditingComplete: () => FocusScope.of(context).nextFocus(),
                        style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 12, color: Colors.black),
                        keyboardType: TextInputType.numberWithOptions(decimal: true),
                        decoration: InputDecoration(
                        filled: true,
                        fillColor: Color(0xffecf0f1),
                        border: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                        hintText: "Product Barcode",
                        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                  ),
        
                        onChanged: (String value){
                          
                        },
                      ),
                    ),

              _camState ?
              Container()

              :addBtn(),

              _camState ?
              Container()

              :Column(
                children: List.generate(invp.barcodes!.length, (index) => 
                  ListTile(
                    title: Text(
                      "${invp.barcodes![index]}",
                      style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 14),
                    ),

                    trailing: InkWell(
                      onTap: (){
                        Provider.of<InventoryProvider>(context, listen: false).removeBarcode(invp.barcodes![index]);
                      },
                      child: Icon(Icons.delete, color: Colors.red,),
                    ),
                  )
                ),
              ),
             
              _camState ?
              Container()

              :saveBtn()
             
             ],
           ),
         ),
       ),
    );
  }
}
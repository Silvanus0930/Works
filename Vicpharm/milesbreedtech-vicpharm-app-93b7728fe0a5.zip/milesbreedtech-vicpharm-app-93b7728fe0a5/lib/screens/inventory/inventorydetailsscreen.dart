import 'package:flutter/material.dart';
import 'package:flutter_money_formatter/flutter_money_formatter.dart';
import 'package:get/get.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class InventoryDetailScreen extends StatelessWidget {
  InventoryDetailScreen({Key? key}) : super(key: key);
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "${Provider.of<InventoryProvider>(context, listen: false).selectedInventory!.name}",//widget.product.name,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 16,),
      onPressed: (){
        Navigator.of(context).pop();
      },
    ),
    actions: [

    ],

  );
  
  Widget fieldContainer(BuildContext context, Widget name, String field, Widget icon, {String font = "PoppinRegular"}){
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Container(

        width: MediaQuery.of(context).size.width,
        //height: MediaQuery.of(context).size.height * 0.08,
        decoration: BoxDecoration(
          border: Border.all(color: grey, width: 2)
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(field, style: TextStyle(color: mvsblue, fontSize: 12),),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: name
            ),

           
          ],
        ),
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    var inventory = Provider.of<InventoryProvider>(context, listen: false).selectedInventory;
    
    FlutterMoneyFormatter  fmf = FlutterMoneyFormatter(
        amount: 50.0,//widget.product.costPrice,
        settings: MoneyFormatterSettings(
          symbol: "NGN",
          thousandSeparator: ',',
          decimalSeparator: '.',
          symbolAndNumberSeparator: ' ',
          fractionDigits: 2,
        ));
    MoneyFormatterOutput  foc = fmf.output;

    FlutterMoneyFormatter  fms = FlutterMoneyFormatter(
        amount: 400,//widget.product.sellingPrice,
        settings: MoneyFormatterSettings(
          symbol: "NGN",//storeCurrency,
          thousandSeparator: ',',
          decimalSeparator: '.',
          symbolAndNumberSeparator: ' ',
          fractionDigits: 2,
        ));
    MoneyFormatterOutput  fos = fms.output;

    var nameTextWidget = Text(
                      "${inventory!.name}", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    );

    var shelfNumberTextWidget = Text(
                      "${inventory.shelfNumber == null ? "" : inventory.shelfNumber }", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    );

    var descTextWidget = Text(
                      "${inventory.description}", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    );

    var expDateTextWidget = Text(
                      "${Jiffy(inventory.expiryDate).yMEd}", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    );

    var categoryColumn = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(inventory.category!.length, (index) => Text(
                      "${inventory.category![index].name}", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    )
                    ),
    );

    
    var quantityColumn = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: inventory.quantity!.entries.map((e) => Text(
                      "${e.key}: ${e.value}", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    )).toList(),
    );

    var costPriceColumn = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: inventory.costPrice!.entries.map((e) {
        FlutterMoneyFormatter  fmsc = FlutterMoneyFormatter(
        amount: e.value.toDouble(),//widget.product.sellingPrice,
        settings: MoneyFormatterSettings(
          symbol: "NGN",//storeCurrency,
          thousandSeparator: ',',
          decimalSeparator: '.',
          symbolAndNumberSeparator: ' ',
          fractionDigits: 2,
        ));
        return Text(
                      "${e.key}: " + fmsc.output.symbolOnLeft, 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    );
      }).toList(),
    );

    var sellPriceColumn = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: inventory.sellingPrice!.entries.map((e) {
        FlutterMoneyFormatter  fmsc = FlutterMoneyFormatter(
        amount: e.value.toDouble(),//widget.product.sellingPrice,
        settings: MoneyFormatterSettings(
          symbol: "NGN",//storeCurrency,
          thousandSeparator: ',',
          decimalSeparator: '.',
          symbolAndNumberSeparator: ' ',
          fractionDigits: 2,
        ));
        return Text(
                      "${e.key}: " + fmsc.output.symbolOnLeft, 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    );
      }).toList(),
    );

    var limitPriceColumn = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: inventory.limitPrice!.entries.map((e) {
        FlutterMoneyFormatter  fmsc = FlutterMoneyFormatter(
        amount: e.value.toDouble(),//widget.product.sellingPrice,
        settings: MoneyFormatterSettings(
          symbol: "NGN",//storeCurrency,
          thousandSeparator: ',',
          decimalSeparator: '.',
          symbolAndNumberSeparator: ' ',
          fractionDigits: 2,
        ));
        return Text(
                      "${e.key}: " + fmsc.output.symbolOnLeft, 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    );
      }).toList(),
    );

    var availableQtyColumn = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: inventory.availableQuantity!.entries.map((e) {
        
        return Text(
                      "${e.key}: ${e.value}", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    );
      }).toList(),
    );

    var meausreColumn = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(inventory.unitOfMeasurement!.length, (index) => Text(
                      "${inventory.unitOfMeasurement![index]}", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    )
                    ),
    );

    var barcodesColumn = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(inventory.barCode!.length, (index) => Text(
                      "${inventory.barCode![index]}", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    )
                    ),
    );

    var discTypeColumn = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: inventory.discountType!.entries.map((e) {
        
        return Text(
                      "${e.key}: ${e.value}", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    );
      }).toList(),
    );

    var discUnitColumn = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: inventory.discountUnit!.entries.map((e) {
        
        return Text(
                      "${e.key}: ${e.value}", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    );
      }).toList(),
    );

    var discColumn = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: inventory.discount!.entries.map((e) {
        
        return Text(
                      "${e.key}: ${e.value}%", 
                      style: TextStyle(color: grey, fontSize: 12, fontFamily: "PoppinSemiBold"),
                    );
      }).toList(),
    );

    


    return SafeArea(
      child: Scaffold(
        key: _scaffoldKey,
        appBar: appbar(context),
        backgroundColor: whiteBG,
        body: Container(
            width: Get.width,
            height: Get.height,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 20,),
                  
                  fieldContainer(context, nameTextWidget, "Item name", Icon(Icons.shop, size: 16,)),

                  fieldContainer(context, shelfNumberTextWidget, "Shelf Number", Icon(Icons.shop, size: 16,)),
                  
                  fieldContainer(context, categoryColumn, "Category", Icon(Icons.folder_special, size: 16)),
                  fieldContainer(context, quantityColumn, "Quantity", Icon(Icons.assignment, size: 16)),
                  fieldContainer(context, costPriceColumn, "Cost Price", Icon(Icons.monetization_on, size: 16)),

                  fieldContainer(context, sellPriceColumn, "Selling Price", Icon(Icons.assignment, size: 16)),
                  fieldContainer(context, limitPriceColumn, "Limit Price", Icon(Icons.monetization_on, size: 16)),
                  fieldContainer(context, availableQtyColumn, "Available Quantity", Icon(Icons.assignment, size: 16)),
                  fieldContainer(context, meausreColumn, "Units of Measurement", Icon(Icons.assignment, size: 16)),

                  fieldContainer(context, barcodesColumn, "Barcodes", Icon(Icons.assignment, size: 16)),
                  fieldContainer(context, descTextWidget, "Description", Icon(Icons.assignment, size: 16)),

                  fieldContainer(context, expDateTextWidget, "Expiry Date", Icon(Icons.assignment, size: 16)),

                  fieldContainer(context, discTypeColumn, "Discount Type", Icon(Icons.assignment, size: 16)),
                  fieldContainer(context, discColumn, "Discount", Icon(Icons.assignment, size: 16)),
                  fieldContainer(context, discUnitColumn, "Discount Unit", Icon(Icons.assignment, size: 16)),
                ],
              ),
            ),
          ),
 
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/utils/currencyinputformatter.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';

class Step2Screen extends StatefulWidget {
  Step2Screen({Key? key}) : super(key: key);

  @override
  _Step2ScreenState createState() => _Step2ScreenState();
}

class _Step2ScreenState extends State<Step2Screen> {
  /*Map<String, dynamic> mapCostPrice = Map<String, dynamic>();
  Map<String, dynamic> mapSellingPrice = Map<String, dynamic>();
  Map<String, dynamic> mapQty = Map<String, dynamic>();
  Map<String, dynamic> mapReorder = Map<String, dynamic>();
  Map<String, String> mapDiscType = Map<String, String>();
  Map<String, dynamic> mapDiscUnit = Map<String, dynamic>();
  Map<String, dynamic> mapDisc = Map<String, dynamic>();*/

  List<TextEditingController> costPriceControllers = [];
  List<TextEditingController> sellPriceControllers = [];
  List<TextEditingController> wholeSellPriceControllers = [];
    List<TextEditingController> qtyControllers = [];
  List<TextEditingController> reOrderPriceControllers = [];
  List<TextEditingController> discountUnitControllers = [];
  List<TextEditingController> discountControllers = [];

  List<bool> _hideUnit = [];
  List<bool> _hideDisc = [];

  List<String> discountTypes = ["none", "single", "bulk"];
  List<String> discountType = [];

  @override
  void initState() { 
    print("do we run this");
    super.initState();
    costPriceControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController(text: ""));
    sellPriceControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController(text: ""));
    wholeSellPriceControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController(text: ""));
    qtyControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController(text: ""));
    reOrderPriceControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController(text: ""));
    discountUnitControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController(text: ""));
    discountControllers = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => TextEditingController(text: ""));

    //costPriceController.text = Provider.of<InventoryProvider>(context, listen: false).mapCostPrice[]
    discountType = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => "none");
    
   
    
    _hideUnit = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => 
        false
    );
    _hideDisc = List.generate(Provider.of<InventoryProvider>(context, listen: false).measurements!.length, (index) => 
        false
    );
      print(_hideUnit);
  }


@override
void dispose() { 
  
  super.dispose();
}


   
  @override
  Widget build(BuildContext context) {
    var invp = Provider.of<InventoryProvider>(context, listen: true);
    print("CCCCCCCCCCCC");

    return Scaffold(
       body: SingleChildScrollView(
         child: Column(
           children: List.generate(invp.measurements!.length, (index) {
             var invpd = Provider.of<InventoryProvider>(context, listen: false);
             costPriceControllers[index].text = invpd.mapCostPrice[invp.measurements![index]] == null ? "" : invpd.mapCostPrice[invp.measurements![index]].toString();

             sellPriceControllers[index].text = invpd.mapSellingPrice[invp.measurements![index]] == null ? "" : invpd.mapSellingPrice[invp.measurements![index]].toString();

             wholeSellPriceControllers[index].text = invpd.mapWholeSellPrice[invp.measurements![index]] == null ? "" : invpd.mapWholeSellPrice[invp.measurements![index]].toString();
             
             qtyControllers[index].text = invpd.mapQty[invp.measurements![index]] == null ? "" : invpd.mapQty[invp.measurements![index]].toString();
             
             reOrderPriceControllers[index].text = invpd.mapReorder[invp.measurements![index]] == null ? "" : invpd.mapReorder[invp.measurements![index]].toString();
             
             discountUnitControllers[index].text = invpd.mapDiscUnit[invp.measurements![index]] == null ? "" : invpd.mapDiscUnit[invp.measurements![index]].toString();
             
             discountControllers[index].text = invpd.mapDisc[invp.measurements![index]] == null ? "" : invpd.mapDisc[invp.measurements![index]].toString();
            
             /*var mss = Provider.of<InventoryProvider>(context, listen: false).measurements;
              print(mss!.length);
              for (var i = 0; i < mss.length; i++) {
                Provider.of<InventoryProvider>(context, listen: false).setMapDiscType("${mss[i]}", "none");
                Provider.of<InventoryProvider>(context, listen: false).setMapDiscUnit("${mss[i]}", 0.0);
                Provider.of<InventoryProvider>(context, listen: false).setMapDisc("${mss[i]}", 0.0);
              }  */
             
             return Container(
              width: Get.width,
              //color: Colors.amberAccent,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    child: Text("${invp.measurements![index]}", style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14, color: Colors.black),),
                  ),

                  SizedBox(height: 20,),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: Text("Cost Price"),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: TextField(
                      controller: costPriceControllers[index],
                      onEditingComplete: () => FocusScope.of(context).nextFocus(),
                      style: TextStyle(fontFamily: 'Roboto', fontSize: 13, color: Colors.black),
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        CurrencyTextInputFormatter(
                          //locale: 'ko',
                          decimalDigits: 2,
                          symbol: '\u{020A6}', // or to remove symbol set ''.
                        )
                      ],
                      decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0xffecf0f1),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                      floatingLabelBehavior: FloatingLabelBehavior.never,
                      errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                      hintText: "Cost Price",
                      hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                ),
        
                      onChanged: (String? value){
                        print(value);
                        if(value != null && value.isNotEmpty){
                          String _onlyDigits = value.replaceAll(RegExp('[^0-9]'), "");
                          double? _doubleValue = 0.0;
                          _doubleValue = double.tryParse(_onlyDigits);
                          if(_doubleValue != null){
                            _doubleValue = _doubleValue / 100;
                          }else{
                            costPriceControllers[index].text = "0";
                            return;
                          }
                          
                          print(_doubleValue);
                          print("textcontroller:");
                          print(costPriceControllers[index].text);
                          Provider.of<InventoryProvider>(context, listen: false).setMapCostPrice(
                            invp.measurements![index], _doubleValue
                          );
                        }
                        
                      },
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: Text("Retail Selling Price"),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: TextField(
                      controller: sellPriceControllers[index],
                      onEditingComplete: () => FocusScope.of(context).nextFocus(),
                      style: TextStyle(fontFamily: 'Roboto', fontSize: 13, color: Colors.black),
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        CurrencyTextInputFormatter(
                          //locale: 'ko',
                          decimalDigits: 2,
                          symbol: '\u{020A6}', // or to remove symbol set ''.
                        )
                      ],
                      decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0xffecf0f1),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                        hintText: "Selling Price",
                        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                  ),
        
                      onChanged: (String value){
                        print(value);
                        if(value != null && value.isNotEmpty){
                          String _onlyDigits = value.replaceAll(RegExp('[^0-9]'), "");
                          double? _doubleValue = 0.0;
                          _doubleValue = double.tryParse(_onlyDigits);
                          if(_doubleValue != null){
                            _doubleValue = _doubleValue / 100;
                          }else{
                            sellPriceControllers[index].text = "0";
                            return;
                          }
                          
                          print(_doubleValue);
                          print("textcontroller:");
                          print(sellPriceControllers[index].text);
                          Provider.of<InventoryProvider>(context, listen: false).setMapSellingPrice(
                            invp.measurements![index], _doubleValue
                          );
                        }
                       
                       //Provider.of<InventoryProvider>(context, listen: false).setMapSellingPrice(invp.measurements![index], double.parse(sellPriceControllers[index].text));
                        
                      },
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: Text("WholeSale Selling Price"),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: TextField(
                      controller: wholeSellPriceControllers[index],
                      onEditingComplete: () => FocusScope.of(context).nextFocus(),
                      style: TextStyle(fontFamily: 'Roboto', fontSize: 13, color: Colors.black),
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        CurrencyTextInputFormatter(
                          //locale: 'ko',
                          decimalDigits: 2,
                          symbol: '\u{020A6}', // or to remove symbol set ''.
                        )
                      ],
                      decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0xffecf0f1),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                        hintText: "WholeSale Selling Price",
                        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                  ),
        
                      onChanged: (String value){
                        print(value);
                        if(value != null && value.isNotEmpty){
                          String _onlyDigits = value.replaceAll(RegExp('[^0-9]'), "");
                          double? _doubleValue = 0.0;
                          _doubleValue = double.tryParse(_onlyDigits);
                          if(_doubleValue != null){
                            _doubleValue = _doubleValue / 100;
                          }else{
                            wholeSellPriceControllers[index].text = "0";
                            return;
                          }
                          
                          print(_doubleValue);
                          print("textcontroller:");
                          print(wholeSellPriceControllers[index].text);
                          Provider.of<InventoryProvider>(context, listen: false).setMapWholeSellPrice(
                            invp.measurements![index], _doubleValue
                          );
                        }
                       
                       //Provider.of<InventoryProvider>(context, listen: false).setMapSellingPrice(invp.measurements![index], double.parse(sellPriceControllers[index].text));
                        
                      },
                    ),
                  ),

                  
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: Text("Quantity"),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: TextField(
                      controller: qtyControllers[index],
                      onEditingComplete: () => FocusScope.of(context).nextFocus(),
                      style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 13, color: Colors.black),
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0xffecf0f1),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                        hintText: "Quantity",
                        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                  ),
        
                      onChanged: (String value){
                        if(value != null  &&value.isNumericOnly && value.isNotEmpty){
                          Provider.of<InventoryProvider>(context, listen: false).setMapQty(invp.measurements![index], double.parse(qtyControllers[index].text));
                        }
                      },
                    ),
                  ),
                
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: Text("ReOrder Limit"),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: TextField(
                      controller: reOrderPriceControllers[index],
                      onEditingComplete: () => FocusScope.of(context).nextFocus(),
                      style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 13, color: Colors.black),
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0xffecf0f1),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                        hintText: "Reorder Limit",
                        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                  ),
        
                      onChanged: (String value){
                        if(value != null && value.isNumericOnly && value.isNotEmpty){
                          Provider.of<InventoryProvider>(context, listen: false).setMapReorder(invp.measurements![index], int.parse(reOrderPriceControllers[index].text));
                          
                        }
                      },
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: Text("Product Discount Type"),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                    child: Container(
                      decoration: BoxDecoration(
                          color: Color(0xffecf0f1),
                          borderRadius: BorderRadius.all(Radius.circular(10))
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: DropdownButton<String>(
                          hint: Text("Select Discount Type",
                              style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 13, color: black)
                          ),
                          value: discountType[index],
                          icon: Icon(Icons.arrow_drop_down, color: mainColor,),
                          elevation: 10,
                          style: TextStyle(color: mainColor),
                          underline: Container(
                            height: 1,
                            color: Colors.transparent,
                          ),
                          onChanged: (String? value){
                            setState(() {
                              discountType[index] = value!;
                              if(value == "none"){
                                _hideUnit[index] = false;
                                _hideDisc[index] = false;  
                                Provider.of<InventoryProvider>(context, listen: false).setMapDisc(invp.measurements![index], 0.0);    
                                Provider.of<InventoryProvider>(context, listen: false).setMapDiscUnit(invp.measurements![index], 0);                           
                              }else if(value == "single"){
                                _hideUnit[index] = false;
                                _hideDisc[index] = true; 
                              }else if(value == "bulk"){
                                _hideUnit[index] = true;
                                _hideDisc[index] = true;
                              }                              
                            });
                            Provider.of<InventoryProvider>(context, listen: false).setMapDiscType(invp.measurements![index], discountType[index]);
                            
                          },
                          isExpanded: true,
                          items: discountTypes.map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value , style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 13, color: black),),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ),

                  _hideUnit[index]?
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: Text("Product Discount Unit"),
                  ) : Container(),
                  
                  _hideUnit[index]?
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: TextField(
                      controller: discountUnitControllers[index],
                      onEditingComplete: () => FocusScope.of(context).nextFocus(),
                      style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 13, color: Colors.black),
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0xffecf0f1),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                        hintText: "Discount unit",
                        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                  ),
        
                      onChanged: (String value){
                        if(value.isNotEmpty){
                          Provider.of<InventoryProvider>(context, listen: false).setMapDiscUnit(invp.measurements![index], int.parse(discountUnitControllers[index].text));
                         
                        }
                      },
                    ),
                  )
                  : Container(),
                  
                  _hideUnit[index] || _hideDisc[index] ?
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: Text("Product Discount Percent"),
                  ): Container(),

                  _hideUnit[index] || _hideDisc[index] ?
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: TextField(
                      controller: discountControllers[index],
                      onEditingComplete: () => FocusScope.of(context).nextFocus(),
                      style: TextStyle(fontFamily: 'PoppinsRegular', fontSize: 13, color: Colors.black),
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0xffecf0f1),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
                        hintText: "Discount",
                        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
                  ),
        
                      onChanged: (String value){
                        if(value.isNotEmpty){
                          Provider.of<InventoryProvider>(context, listen: false).setMapDisc(invp.measurements![index], double.parse(discountControllers[index].text));
                        }
                      },
                    ),
                  )
                  : Container(),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: Divider(
                      height: 5,
                      thickness: 5,
                      endIndent: 3,
                      indent: 2,
                      color: mainColor,
                    ),
                  )

                  
                ],
              ),
            );
           
           }
            
           ),
         ),
       ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:provider/provider.dart';
//import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/customwidgets/AlternateContainer.dart';
import 'package:vicpharm_app/models/inventory.dart';
import 'package:vicpharm_app/screens/activities/activitiesscreen.dart';
import 'package:vicpharm_app/screens/inventory/addinventoryscreen.dart';
import 'package:vicpharm_app/screens/inventory/inventorydetailsscreen.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class InventoryRecordScreen extends StatefulWidget {
  InventoryRecordScreen({Key? key}) : super(key: key);

  @override
  _InventoryRecordScreenState createState() => _InventoryRecordScreenState();
}

class _InventoryRecordScreenState extends State<InventoryRecordScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  //final RefreshController _refreshController = RefreshController();
  ScrollController controller = ScrollController();
  ActivitiesLoadMoreStatus loadMoreStatus = ActivitiesLoadMoreStatus.STABLE;
   int currentPageNumber = 1;
   int _pageSize = 50;

   final PagingController<int, Inventory> _pagingController =
      PagingController(firstPageKey: 1);


  @override
  void initState() { 
    _pagingController.addPageRequestListener((pageKey) {
      _fetchPage(pageKey);
    });
    super.initState();
    
   // WidgetsBinding.instance!.addPostFrameCallback((_) {
      
   // });
  }

  Future<void> _fetchPage(int pageKey) async {
    try {
      print("CCCCCCCCCCCCCCCCCCCC");
      final newItems = await Provider.of<InventoryProvider>(context, listen: false).populateInventory(pageKey);
      final isLastPage = newItems!.length < _pageSize;
      if (isLastPage) {
        _pagingController.appendLastPage(newItems);
      } else if(pageKey == Provider.of<InventoryProvider>(context, listen: false).inventoryTotalPage!){
        //final nextPageKey = pageKey + 1;
        //_pagingController.appendPage(newItems, nextPageKey);
      }
      else {
        final nextPageKey = pageKey + 1;
        _pagingController.appendPage(newItems, nextPageKey);
      }
    } catch (error) {
      _pagingController.error = error;
    }
    
    
  }
  
  
   AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Inventory Records",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold',fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () => Get.offAll(() => LandingScreen()),
    ),


  );

  Widget mainCustomerList(BuildContext context){
    return RefreshIndicator(
      onRefresh: () => Future.sync(
        () => _pagingController.refresh(),
      ),
      child: PagedListView<int, Inventory>(
        
          pagingController: _pagingController,
          builderDelegate: PagedChildBuilderDelegate<Inventory>(
            itemBuilder: (context, item, index) => Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                        child: InkWell(
                            onTap: (){
                              Provider.of<InventoryProvider>(context, listen: false).setSelectedInventory(item);
                              Get.to(() => InventoryDetailScreen());   
                            },
                            child: Container(
                              width: Get.width * 0.95,
                              //color: Colors.deepPurple,
                              decoration: BoxDecoration(
                                color: Color(0x0d1c63ba),
                                borderRadius: BorderRadius.all(Radius.circular(20.0),),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.only(left: 20.0, right: 10.0, top: 5.0, bottom: 5),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                      Padding(
                                        padding: EdgeInsets.only(top: 5, right: 20, bottom: 15),
                                        child: Container(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Text(
                                                "${item.name!.length > 25 ? item.name!.substring(0, 25) + "..." : item.name}",//invProducts[index] == null ? "" : invProducts[index].name ,
                                                 overflow: TextOverflow.ellipsis,style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12),),
                                              Text(
                                                "${item.category!.length > 0 ? item.category![0].name : ""}",//invProducts[index].category.isEmpty ? "" : invProducts[index].category[0].name,
                                                style: TextStyle(fontFamily: 'PoppinsSemiBold', color: grey, fontSize: 12)),

                                              item.soldOut == true ?
                                              Text(
                                                "Not Available",//invProducts[index].category.isEmpty ? "" : invProducts[index].category[0].name,
                                                style: TextStyle(fontFamily: 'PoppinsSemiBold', color: mvsred, fontSize: 12))
                                              : Container()
                                            ],
                                          ),
                                        ),
                                      ),

                                      Padding(
                                        padding: EdgeInsets.only(top: 5, right: 20, bottom: 15),
                                        child: Container(

                                          child: Align(
                                              alignment: Alignment.center,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    "Quantity",//invProducts[index].quantity.toString(),
                                                    style: TextStyle(fontFamily: 'PoppinsSemiBold', color: mvsblue, fontSize: 12,),
                                                  ),
                                                     
                                                  Column(
                                                    children: item.quantity!.entries.map((e) => 
                                                      Text(
                                                        "${e.key}: " + "${e.value}",//invProducts[index].quantity.toString(),
                                                        style: TextStyle(fontFamily: 'PoppinsRegular', color: mvsblue, fontSize: 12,),
                                                      )
                                                    ).toList()
                                                    
                                                  ),
                                                ],
                                              ),

                                          ),
                                        ),

                                      )
                                  ]
                                )
                              
                              )
                            )
                        ),
                      ),
                        
            newPageErrorIndicatorBuilder: (context) => AlternateContainer(
              text:  _pagingController.error.toString(),
            ),
            firstPageErrorIndicatorBuilder: (context) => AlternateContainer(
              text:  _pagingController.error.toString(),
            ),
            noItemsFoundIndicatorBuilder: (context) => AlternateContainer(
              text:  "No data yet.",
            ),
          ),
          
           
        ),
    );
  }

  
  
  Widget mainLayer(BuildContext context) => SizedBox(
            height: Get.height ,
            width: Get.width,
            child: mainCustomerList(context));
 

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          backgroundColor: whiteBG,
          appBar: appbar(context),
          body: mainLayer(context),
          floatingActionButton: FloatingActionButton(
            onPressed: () {
              Get.to(() => AddInventoryScreen());


            },
            child: Icon(Icons.add,),
            backgroundColor: mainColor,
          ), 
        )
    );
  }
}

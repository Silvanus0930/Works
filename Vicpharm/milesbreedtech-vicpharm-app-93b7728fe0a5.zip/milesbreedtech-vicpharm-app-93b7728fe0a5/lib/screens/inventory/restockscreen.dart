import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/customwidgets/datetimefields.dart';
import 'package:vicpharm_app/models/inventory.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/screens/landing/landingprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class RestockScreen extends StatefulWidget {
  RestockScreen({Key? key}) : super(key: key);

  @override
  _RestockScreenState createState() => _RestockScreenState();
}

class _RestockScreenState extends State<RestockScreen> {
  TextEditingController expiryDateController = new TextEditingController();
  List<TextEditingController> qtyControllers = [];
  List<TextEditingController> costPriceControllers = [];

  Map<String, double> cp = Map<String, double>();
  Map<String, double> qty = Map<String, double>();


  @override
  void initState() { 
    super.initState();
    qtyControllers = List.generate(Provider.of<LandingProvider>(context, listen: false).selectedproduct!.unitOfMeasurement!.length, (index) => TextEditingController());
    costPriceControllers = List.generate(Provider.of<LandingProvider>(context, listen: false).selectedproduct!.unitOfMeasurement!.length, (index) => TextEditingController());

    for (var i = 0; i < Provider.of<LandingProvider>(context, listen: false).selectedproduct!.unitOfMeasurement!.length; i++) {
      cp[Provider.of<LandingProvider>(context, listen: false).selectedproduct!.unitOfMeasurement![i]] = 0.0;
      qty[Provider.of<LandingProvider>(context, listen: false).selectedproduct!.unitOfMeasurement![i]] = 0.0;
    }
    //Provider.of<InventoryProvider>(context, listen: false).setMapCostPrice(Map<String, dynamic>());
  }

  AppBar _appBar(BuildContext context){
    print(Provider.of<LandingProvider>(context, listen: false).selectedproduct!.name);
    return AppBar(
      title: Text(
      "${Provider.of<LandingProvider>(context, listen: false).selectedproduct!.name}",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold',fontSize: 18),
    ),
      actions: [
        FlatButton(
          color: Colors.transparent,
          shape: CircleBorder(side: BorderSide(width: 2, color: Colors.transparent, style: BorderStyle.none)),
          splashColor: mainColor.withOpacity(0.3),
          onPressed: (){

            if(expiryDateController.text.isNotEmpty){
              Inventory inv = Inventory(
                sId: Provider.of<LandingProvider>(context, listen: false).selectedproduct!.sId,
                costPrice: cp,
                quantity: qty,
                expiryDate: expiryDateController.text
              );
              Provider.of<InventoryProvider>(context, listen: false).restockInventory(inv);
            }
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.save_alt, color: whiteBG, size: 16),
              Text('Restock',
                style: TextStyle(color: whiteBG, fontSize: 12, fontFamily: 'PoppinsRegular'),
              )
          ],
        )
      ),
                        
      ],
    );
  }

  TextFormField cpField(BuildContext context, TextEditingController controller, String key) {
    //cpController.text = widget.product.costPrice.toString();

    return TextFormField(

      style: TextStyle(
          fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      controller: controller,
      enableSuggestions: true,
      autocorrect: true,
      keyboardType: TextInputType.numberWithOptions(decimal: true),
      onChanged: (String? data){
        if(data!.isNotEmpty){
          cp[key] = double.tryParse(data)!;
          Provider.of<LandingProvider>(context, listen: false).setRestockCostPrice(cp);
        }
        //cpController.selection=TextSelection.collapsed(offset:cpController.text.length);
      },
      textInputAction: Platform.isIOS
          ? TextInputAction.continueAction
          : TextInputAction.next,
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),
          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),

          suffixIcon: Icon(Icons.monetization_on, color: Colors.grey, size: 12,),
          prefix: Text("NGN" + " "),
          prefixStyle: TextStyle(
              fontFamily: 'Roboto', fontSize: 12, color: black),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),

          hintText: "Cost Price",
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

    );
  }

  TextFormField qtyField(BuildContext context, TextEditingController controller, String key) {

    return TextFormField(

      style: TextStyle(
          fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      controller: controller,
      enableSuggestions: true,
      autocorrect: true,
      keyboardType: TextInputType.numberWithOptions(decimal: true),
      textInputAction: Platform.isIOS
          ? TextInputAction.continueAction
          : TextInputAction.next,
      onChanged: (String? data){
        if(data!.isNotEmpty){
          qty[key] = double.tryParse(data)!;
          Provider.of<LandingProvider>(context, listen: false).setRestockCostPrice(qty);
        }
      },
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),
          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          suffixIcon: Icon(Icons.shop, color: Colors.grey, size: 16,),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
          hintText: "Quantity",
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

      validator: (value) {
        if (value!.isEmpty) {
          return 'Please enter some text';
        }
        return null;
      },
    );
  }

  Widget restockContainer(context) {

    var invp = Provider.of<LandingProvider>(context, listen: true);
    
   
    return SingleChildScrollView(
        child: Column(
              children: [
                meaurementRestockSelect(context),

                Column(
                  children: List.generate(invp.selectedproduct!.unitOfMeasurement!.length, (index){
                    //var qty = invp.selectedproduct!.quantity![invp.selectedproduct!.unitOfMeasurement![index]] ?? 0.0;
                    //qtyControllers[index].text = qty.toString();

                    //var cst = invp.selectedproduct!.costPrice![invp.selectedproduct!.unitOfMeasurement![index]] ?? 0.0;
                    //costPriceControllers[index].text = cst.toString();
                    
                    return Form(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                              child: Text("${invp.selectedproduct!.unitOfMeasurement![index]}", style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 14, color: Colors.black),),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                              child: qtyField(context, qtyControllers[index], invp.selectedproduct!.unitOfMeasurement![index]),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                              child: cpField(context, costPriceControllers[index], invp.selectedproduct!.unitOfMeasurement![index]),
                            ),

                            
                           
                          ],

                          
                        ),
                      
                    );
                  }
                    
              
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: AndroidDateTimeField(label: "Expiry Date", expiryDateController: expiryDateController),
                ),
                     
              ],
            ),
          
        
      );
  

  }

  Widget meaurementRestockSelect(BuildContext context){
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Container(
        decoration: BoxDecoration(
            color: Color(0xffecf0f1),
            borderRadius: BorderRadius.all(Radius.circular(10))
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: DropdownButton<String>(
            hint: Text("Select Unit of Measurement",
                style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)
            ),
            value: Provider.of<LandingProvider>(context, listen: true).selectedMeasurement,
            icon: Icon(Icons.arrow_drop_down, color: mainColor, size: 30,),
            elevation: 10,
            style: TextStyle(color: mainColor),
            underline: Container(
              height: 1,
              color: Colors.transparent,
            ),
            onChanged: (String? value){
              setState(() {
                print(value);
                Provider.of<LandingProvider>(context, listen: false).setSelectedMeasurement(value!);
              });

            },
            isExpanded: true,
            items: Provider.of<LandingProvider>(context, listen: true).selectedproduct!.unitOfMeasurement!.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value , style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
       child: Scaffold(
         appBar: _appBar(context),
         body: restockContainer(context),
       )
    );
  }
}
import 'dart:io';

import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/customwidgets/datetimefields.dart';
import 'package:vicpharm_app/models/category.dart';
import 'package:vicpharm_app/models/inventory.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class Step1Screen extends StatefulWidget {
  bool? isNew = false;
  Step1Screen({Key? key, this.isNew}) : super(key: key);

  @override
  _Step1ScreenState createState() => _Step1ScreenState();
}

class _Step1ScreenState extends State<Step1Screen> {

  final _formKey = GlobalKey<FormState>();
  TextEditingController nameController = TextEditingController();
  TextEditingController descController = TextEditingController();
  TextEditingController expDateController = TextEditingController();
  TextEditingController measurementController = TextEditingController();
  final format = DateFormat("dd/MM/yyyy");

  @override
  void initState() { 
    super.initState();
    nameController.text = Provider.of<InventoryProvider>(context, listen: false).name ?? "";
    descController.text = Provider.of<InventoryProvider>(context, listen: false).disc ?? "";
    expDateController.text = Provider.of<InventoryProvider>(context, listen: false).expDate ?? "";
  }

  Widget nameField(BuildContext context) => TextFormField(
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: nameController,
        textCapitalization: TextCapitalization.words,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.text,
        textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
        onChanged: (String value){
          Provider.of<InventoryProvider>(context, listen: false).setName(value);
        },
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Product Name",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        
        validator: (String? value) {
          if (value!.isEmpty) {
            return 'Please enter phone number';
          }
          return null;
        },

      );
  
  Widget shelfNumberField(BuildContext context) => TextFormField(
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: nameController,
        textCapitalization: TextCapitalization.words,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.text,
        textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
        onChanged: (String value){
          Provider.of<InventoryProvider>(context, listen: false).setShelfNumber(value);
        },
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Product Name",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        
        validator: (String? value) {
          if (value!.isEmpty) {
            return 'Please enter shelf number';
          }
          return null;
        },

      );
  
  Widget descField(BuildContext context) => TextFormField(
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: descController,
        textCapitalization: TextCapitalization.sentences,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        minLines: 5,
        maxLines: 8,
        keyboardType: TextInputType.text,
        textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
        onChanged: (String value){
          Provider.of<InventoryProvider>(context, listen: false).setDisc(value);
        },
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Product Description",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        validator: (String? value) {
          if (value!.isEmpty) {
            return 'Please enter phone number';
          }
          return null;
        },

      );
  
  Widget categroySelect(BuildContext context){
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: Container(
        decoration: BoxDecoration(
            color: Color(0xffecf0f1),
            borderRadius: BorderRadius.all(Radius.circular(10))
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: DropdownButton<Category>(
            hint: Text("Select Category",
                style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black)
            ),
            value: Provider.of<InventoryProvider>(context, listen: true).selectedCategory,
            icon: Icon(Icons.arrow_drop_down, color: mainColor,),
            elevation: 10,
            style: TextStyle(color: mainColor),
            underline: Container(
              height: 1,
              color: Colors.transparent,
            ),
            onChanged: (Category? value){
              Provider.of<InventoryProvider>(context, listen: false).setSelectedCategory(value!);

            },
            isExpanded: true,
            items: Provider.of<InventoryProvider>(context, listen: true).catgeories!.map((Category value) {
              return DropdownMenuItem<Category>(
                value: value,
                child: Text(value.name! , style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  Widget measurementField(BuildContext context) => TextField(
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: measurementController,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.text,
        textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Measurement Units",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        

      );
  
  Widget measureSection(BuildContext context){
    return Container(
      width: Get.width,
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: Get.width * 0.7,
                child: measurementField(context)
              ),
              InkWell(
                onTap: (){
                  if(measurementController.text.isNotEmpty){
                    Provider.of<InventoryProvider>(context, listen: false).addMeasurement(measurementController.text);
                  }
                  
                },
                child: Icon(Icons.add, color: mainColor,),
              )
            ],
          ),
        
          Column(
            children: List.generate(Provider.of<InventoryProvider>(context, listen: true).measurements!.length, (index) => 
              ListTile(
                title: Text("${Provider.of<InventoryProvider>(context, listen: true).measurements![index]}",
                  style: TextStyle(color: mainColor, fontSize: 12, fontFamily: 'PoppinsRegular'),
                  ),

                  trailing: InkWell(
                    onTap: (){
                      Provider.of<InventoryProvider>(context, listen: false).removeMeasurement(Provider.of<InventoryProvider>(context, listen: false).measurements![index]);
                    },
                    child: Icon(Icons.delete, color: Colors.red,),
                  ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget expDateField(BuildContext context){
    return DateTimeField(
      controller: expDateController,
      style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
      onChanged: (DateTime? value){
          Provider.of<InventoryProvider>(context, listen: false).setExpDate(Jiffy(value).yMd);
        },
      decoration: InputDecoration(
          filled: true,
          fillColor: Color(0xffecf0f1),

          border: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide.none,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          suffixIcon: Icon(Icons.calendar_today, color: Colors.grey, size: 16,),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
          hintText: "Expiry Date",
          hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
      ),

        format: format,
        onShowPicker: (context, currentValue) async {
          final date = await showDatePicker(
              context: context,
              firstDate: DateTime(1900),
              initialDate: currentValue ?? DateTime.now(),
              lastDate: DateTime(2100));
          if (date != null) {
         
            return DateTimeField.combine(date, null);
          } else {
            return currentValue;
          }
        },
      );
  }

  Widget continueBtn() {

    return Padding(
      padding: EdgeInsets.only(right: 20.0, bottom: 20.0),
      child: SizedBox(
          height: Get.height * 0.08,
          width: Get.width * 0.4,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: () {
                

                // populate the available fields
                var invp = Provider.of<InventoryProvider>(context, listen: false);
                invp.newInventory!.name = nameController.text;
                invp.newInventory!.description = descController.text;
                invp.newInventory!.expiryDate = expDateController.text;
                invp.newInventory!.unitOfMeasurement = invp.measurements;


              },

              color: mainColor,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Continue",
                      style: TextStyle(fontSize: 14,
                      fontFamily: 'PoppinsSemiBold',
                      color: Colors.white
                    ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.arrow_forward_ios, size: 16, color: mainColor)
                  ),
                ],
              ),

            ),
          )
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       body: SingleChildScrollView(
         child: Form(
           child: Column(
             children: [
               Padding(
                 padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                 child: nameField(context),
                ),

                Padding(
                 padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                 child: descField(context),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: expDateField(context),
                ),

                categroySelect(context),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: measureSection(context),
                ),

               
             ],
           ),
         ),
       ),
    );
  }
}
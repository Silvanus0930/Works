import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vicpharm_app/screens/inventory/editstep1screen.dart';
import 'package:vicpharm_app/screens/inventory/editstep2screen.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class EditProductScreen extends StatefulWidget {
  @override
  _EditProductScreenState createState() => _EditProductScreenState();
}

class _EditProductScreenState extends State<EditProductScreen> {
  @override
  void initState() { 
    super.initState();
    //Provider.of<InventoryProvider>(context, listen: false).getAllCategories();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
       child: DefaultTabController(
           length: 2,
           child: Scaffold(
             appBar: AppBar(
               leading: IconButton(
                  icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
                  onPressed: () => Get.offAll(LandingScreen())
                ),
                bottom: TabBar(
                  tabs: [
                    Tab(text: "Basic Info"),
                    Tab(text: "Prices"),
                    //Tab(text: "Barcode & Save"),
                  ],
                ),
                title: Text('Edit Product'),

              ),
            body: TabBarView(
            children: [
              EditStep1Screen(),
              EditStep2Screen(),
              //Step3Screen(),
            ],
          ),
           )
         )
    );
  }
}
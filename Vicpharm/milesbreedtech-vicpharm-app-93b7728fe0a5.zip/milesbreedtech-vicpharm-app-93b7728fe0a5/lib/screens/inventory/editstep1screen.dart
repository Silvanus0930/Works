import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/models/inventory.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/screens/landing/landingprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class EditStep1Screen extends StatefulWidget {
  @override
  _EditStep1ScreenState createState() => _EditStep1ScreenState();
}

class _EditStep1ScreenState extends State<EditStep1Screen> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController nameController = TextEditingController();
  TextEditingController descController = TextEditingController();
  TextEditingController expDateController = TextEditingController();
  TextEditingController measurementController = TextEditingController();
  final format = DateFormat("dd/MM/yyyy");

  @override
  void initState() { 
    super.initState();
     WidgetsBinding.instance!.addPostFrameCallback((_) => initData());
  }

  initData() async{
    nameController.text = Provider.of<LandingProvider>(context, listen: false).selectedproduct!.name ?? "";
    descController.text = Provider.of<LandingProvider>(context, listen: false).selectedproduct!.description ?? "";
    Provider.of<InventoryProvider>(context, listen: false).bulkAddMeasurements(Provider.of<LandingProvider>(context, listen: false).selectedproduct!.unitOfMeasurement!);
    //expDateController.text = Provider.of<InventoryProvider>(context, listen: false).expDate ?? "";
    Provider.of<InventoryProvider>(context, listen: false).setSelectedInventory(Inventory());
    Inventory inv = Inventory(
      name: nameController.text,
      description: descController.text,
      unitOfMeasurement: Provider.of<InventoryProvider>(context, listen: false).measurements,
      discountType: Provider.of<LandingProvider>(context, listen: false).selectedproduct!.discountType,
      discountUnit: Provider.of<LandingProvider>(context, listen: false).selectedproduct!.discountUnit,
      discount: Provider.of<LandingProvider>(context, listen: false).selectedproduct!.discount
    );
    Provider.of<InventoryProvider>(context, listen: false).setSelectedInventory(inv);
  
  }

  Widget nameField(BuildContext context) => TextFormField(
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: nameController,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.text,
        textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
        onChanged: (String value){
          Provider.of<InventoryProvider>(context, listen: false).setName(value);
        },
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Product Name",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        
        validator: (String? value) {
          if (value!.isEmpty) {
            return 'Please enter phone number';
          }
          return null;
        },

      );
  
  Widget descField(BuildContext context) => TextFormField(
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: descController,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        minLines: 5,
        maxLines: 8,
        keyboardType: TextInputType.text,
        textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
        onChanged: (String value){
          Provider.of<InventoryProvider>(context, listen: false).setDisc(value);
        },
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Product Description",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        validator: (String? value) {
          if (value!.isEmpty) {
            return 'Please enter phone number';
          }
          return null;
        },

      );
  
  
  Widget measurementField(BuildContext context) => TextField(
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: measurementController,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.text,
        textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Measurement Units",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        

      );
  
  Widget measureSection(BuildContext context){
    return Container(
      width: Get.width,
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: Get.width * 0.7,
                child: measurementField(context)
              ),
              InkWell(
                onTap: (){
                  if(measurementController.text.isNotEmpty){
                    Provider.of<InventoryProvider>(context, listen: false).addMeasurement(measurementController.text);
                  }
                  
                },
                child: Icon(Icons.add, color: mainColor,),
              )
            ],
          ),
        
          Column(
            children: List.generate(Provider.of<InventoryProvider>(context, listen: true).measurements!.length, (index) => 
              ListTile(
                title: Text("${Provider.of<InventoryProvider>(context, listen: true).measurements![index]}",
                  style: TextStyle(color: mainColor, fontSize: 12, fontFamily: 'PoppinsRegular'),
                  ),

                  trailing: InkWell(
                    onTap: (){
                      Provider.of<InventoryProvider>(context, listen: false).removeMeasurement(Provider.of<InventoryProvider>(context, listen: false).measurements![index]);
                    },
                    child: Icon(Icons.delete, color: Colors.red,),
                  ),
              ),
            ),
          )
        ],
      ),
    );
  }

  
  Widget continueBtn() {

    return Padding(
      padding: EdgeInsets.only(right: 20.0, bottom: 20.0),
      child: SizedBox(
          height: Get.height * 0.08,
          width: Get.width * 0.4,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: () {
                

                // populate the available fields
                var invp = Provider.of<InventoryProvider>(context, listen: false);
                invp.newInventory!.name = nameController.text;
                invp.newInventory!.description = descController.text;
                invp.newInventory!.expiryDate = expDateController.text;
                invp.newInventory!.unitOfMeasurement = invp.measurements;


              },

              color: mainColor,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Continue",
                      style: TextStyle(fontSize: 14,
                      fontFamily: 'PoppinsSemiBold',
                      color: Colors.white
                    ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.arrow_forward_ios, size: 16, color: mainColor)
                  ),
                ],
              ),

            ),
          )
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       body: SingleChildScrollView(
         child: Form(
           child: Column(
             children: [
               Padding(
                 padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                 child: nameField(context),
                ),

                Padding(
                 padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                 child: descField(context),
                ),

                
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: measureSection(context),
                ),

               
             ],
           ),
         ),
       ),
    );
  }
}
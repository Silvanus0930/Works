import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/customwidgets/AlternateContainer.dart';
import 'package:vicpharm_app/customwidgets/addcategorymodel.dart';
import 'package:vicpharm_app/models/category.dart';
import 'package:vicpharm_app/screens/assortment/categorydetailsscreen.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';
import 'package:get/get.dart';

class CategoryScreen extends StatefulWidget {
  @override
  _CategoryScreenState createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
   final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  TextEditingController categoryController = new TextEditingController();
  final RefreshController _refreshController = RefreshController();
  String categorySub = "";
  

  @override
  initState(){
   
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => 
    Provider.of<InventoryProvider>(context, listen: false).setFutureCategory(Provider.of<InventoryProvider>(context, listen: false).getAllCategoriesFuture())
  );
  }


  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Product Categories",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () {
        Get.offAll(() => LandingScreen());  
      
      },
    ),


  );

  Widget assortmentRecordBox(BuildContext context){
    return FutureBuilder<List<Category>?>(
      future: Provider.of<InventoryProvider>(context, listen: true).futureCategory,
      builder: (context, snapshot){
        if(snapshot.hasError){
          return AlternateContainer(text: "Error occurred retrieving data...");
        }else if (snapshot.connectionState == ConnectionState.waiting){
          return AlternateContainer(text: "Loading....");
        }
        else if(snapshot.data == null){
          return AlternateContainer(text: "No Customer found.....");
        }
        else if(snapshot.connectionState == ConnectionState.done){
          return SizedBox(
            height: Get.height,
            width: Get.width,
            child: ListView.builder(
                shrinkWrap: true,
                itemCount: snapshot.data!.length,
                itemBuilder: (BuildContext context, index){
                  return InkWell(
                    onTap: (){
                     Provider.of<InventoryProvider>(context, listen: false).setSelectedCategory(snapshot.data![index]);
                    Get.to(() => CategoryDetailScreen());
                    
                    // Navigator.push(
                    //     _scaffoldKey.currentContext,
                    //     BouncyPageRoute(widget: CategoryDetailsPage(category: categories[index]))
                    // );

                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 20),
                      child: Container(
                            height: MediaQuery.of(context).size.height * 0.12,
                            width: MediaQuery.of(context).size.width * 0.9,
                            decoration: BoxDecoration(
                                color: Color(0x0d1c63ba),
                                borderRadius: BorderRadius.all(Radius.circular(20))
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 8, bottom: 8, left: 10),
                                  child: Container(
                                    width: MediaQuery.of(context).size.width * 0.15,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: mainColor.withOpacity(0.3),
                                      //border: Border.all(color: Colors.red, width: 1.0)
                                    ),
                                    child: Center(
                                      child: Text(
                                        snapshot.data![index].name == null ? "" : snapshot.data![index].name![0].toUpperCase(),
                                        //Product.allProducts[index].category.substring(0, 1).toUpperCase(),
                                        style: TextStyle(
                                            fontFamily: 'PoppinsBold',
                                            fontSize: 28,
                                            color: snapshot.data![index].subCategories!.length > 0 ? Colors.white : mainColor),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(

                                  width: MediaQuery.of(context).size.width * 0.65,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(right: 5, left: 10),
                                        child: Text(snapshot.data![index].name == null ? "" : snapshot.data![index].name!.toUpperCase(), style:  TextStyle(fontSize: 14, fontFamily: 'PoppinsSemiBold'),),
                                      ),

                                      Padding(
                                        padding: const EdgeInsets.only(top: 1.0, right: 20, left: 10),
                                        child: Divider(thickness: 1, color: Color(0xb21c63ba),),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(top: 1.0, right: 20, left: 10),
                                        child: Text(snapshot.data![index].subCategories!.length.toString()  + " Subs | ${snapshot.data![index].product  != null ? snapshot.data![index].product!.length : 0} product(s)" , overflow: TextOverflow.ellipsis, style:  TextStyle(fontSize: 12, color: mvsblue)),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                    ),
                      
                    );
                  
                },
      ),
            
          );
        }

        else{
          return AlternateContainer(text: "Loading....");
        }
      },

    );
  }

  
  Widget mainLayer(BuildContext context) => Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: whiteBG,

      child: SmartRefresher(
                controller: _refreshController,
                header: WaterDropMaterialHeader(
                  backgroundColor: mainColor,
                ),
                onRefresh: (){
                  
                },
                child: assortmentRecordBox(context)
              ),
      
          

    //child: contentStack(context),
  );

 
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          backgroundColor: whiteBG,
          appBar: appbar(context),
          body: mainLayer(context),
         floatingActionButton: FloatingActionButton(
            onPressed: (){
              Get.dialog(AddCategoryModal());
            },
            child: Icon(Icons.add, color: Colors.white,),
         ),

        )
    );
  }
}
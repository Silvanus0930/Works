import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/customwidgets/addsubcategorymodal.dart';
import 'package:vicpharm_app/models/category.dart';
import 'package:vicpharm_app/screens/inventory/inventoryprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class CategoryDetailScreen extends StatefulWidget {
  @override
  _CategoryDetailScreenState createState() => _CategoryDetailScreenState();
}

class _CategoryDetailScreenState extends State<CategoryDetailScreen> {

  AppBar appbar(BuildContext context) => AppBar(
    elevation: 5.0,
    centerTitle: true,
    title: Text(
      "Details",
      style: TextStyle(color: mainColor, fontFamily: 'PoppinsSemiBold', fontSize: 18),
    ),
    backgroundColor: whiteBG,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios, color: mainColor, size: 15,),
      onPressed: () {
        Get.back(); 
      
      },
    ),


  );


 
  Widget fieldContainer(BuildContext context, String name, String field, Widget icon){
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20, bottom: 10),
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height * 0.08,
        decoration: BoxDecoration(
            border: Border.all(color: grey, width: 2)
        ),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.topLeft,
                child: Text(field, style: TextStyle(color: mvsblue, fontSize: 12),),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.bottomLeft,
                child: Text(name, style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.bottomRight,
                child: icon,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget subCatContainer(BuildContext context, Widget name, String field){
    return Padding(
      padding: const EdgeInsets.only(top: 10, left: 20, right: 20, bottom: 10),
      child: Container(
        width: MediaQuery.of(context).size.width,
        //height: MediaQuery.of(context).size.height * 0.08,
        decoration: BoxDecoration(
            border: Border.all(color: grey, width: 2)
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.topLeft,
                child: Text(field, style: TextStyle(color: mvsblue, fontSize: 12),),
              ),
            ),

            SizedBox(height: 10,),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Align(
                alignment: Alignment.bottomLeft,
                child: name
              ),
            ),

           
          ],
        ),
      ),
    );
  }


  Widget mainContainer(BuildContext context){
    var category = Provider.of<InventoryProvider>(context, listen: false).selectedCategory;
  
    var columnName = Column(
      children: List.generate(category!.subCategories!.length, (index) => 
        Text(category.subCategories![index].name!, style: TextStyle(fontSize: 12, fontFamily: 'PoppinsSemiBold'),),
      ),
    );

    return SingleChildScrollView(
      child: Column(
        children: [
          
          fieldContainer(context, category.name![0].toUpperCase() + category.name!.substring(1), "Category Name", Icon(Icons.calendar_today, color: grey, size: 16,)),
          //subCatContainer(context, Jiffy(category!.createdAt).yMd , "Sub Categories"),
          subCatContainer(context, columnName , "Sub Categories"),
          

        ],
      ),
    );
  }

 
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: appbar(context),
        body: mainContainer(context),
        floatingActionButton: Provider.of<InventoryProvider>(context, listen: false).selectedCategory!.product!.length == 0 
        ? FloatingActionButton.extended(
          label: Text(
            "Add Subcategory",
            maxLines: 1,
            style: TextStyle(color: whiteBG, fontSize: 12, fontFamily: 'PoppinsRegular'),
          ),
          onPressed: (){
            Get.dialog(AddSubCategoryModal());
          },
          elevation: 5,
          backgroundColor: mainColor,

        ) : null,
      ),
    );
  }
}
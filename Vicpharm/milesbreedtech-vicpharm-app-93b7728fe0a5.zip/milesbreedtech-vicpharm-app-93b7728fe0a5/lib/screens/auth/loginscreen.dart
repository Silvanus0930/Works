import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/auth/forgotpasswordscreen.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';
import 'package:vicpharm_app/utils/sharedprefs.dart';

class LoginScreen extends StatefulWidget {
  LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _passwObscure = true;
  final _formKey = GlobalKey<FormState>();
  TextEditingController phoneController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) => initData());
    
  }

  initData() async{
    String phone = (await Provider.of<AuthProvider>(context, listen: false).retrievePhone())!;
    print("phone is::: ${phone}");
    phoneController.text = phone != null ? phone : "";
  }

  Widget phoneField(BuildContext context) => TextFormField(
        onEditingComplete: () => FocusScope.of(context).nextFocus(),
        controller: phoneController,
        style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
        enableSuggestions: true,
        autocorrect: true,
        keyboardType: TextInputType.phone,
        textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
        decoration: InputDecoration(
            filled: true,
            fillColor: Color(0xffecf0f1),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            suffixIcon: Icon(Icons.phone_in_talk, color: Colors.grey, size: 16,),
            floatingLabelBehavior: FloatingLabelBehavior.never,
            errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
            hintText: "Phone Number",
            hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)
        ),
        validator: (String? value) {
          if (value!.isEmpty) {
            return 'Please enter phone number';
          }
          return null;
        },

      );
  
  TextFormField passwordField(BuildContext context) => TextFormField(
    onEditingComplete: () => FocusScope.of(context).unfocus(),
    controller: passwordController,
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
    enableSuggestions: true,

    keyboardType: TextInputType.text,
    obscureText: _passwObscure,
    textInputAction: TextInputAction.done,
    decoration: InputDecoration(

        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: IconButton(
          icon: Icon(_passwObscure ? Icons.visibility_off : Icons.visibility, color: Colors.grey, size: 16,),
          onPressed: (){
            print(_passwObscure);
            if(_passwObscure){
              setState(() {
                _passwObscure = false;
              });
            }else{
              setState(() {
                _passwObscure = true;
              });
            }
          },
        ),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Password",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)


    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter password';
      }
      return null;
    },

  );

  Widget forgotPWDBtn() => Padding(
    padding: EdgeInsets.only(left: 20.0, bottom: 20.0),
    child: SizedBox(
        height: Get.height * 0.08,
        width: Get.width * 0.4,
        child: InkWell(
          onTap:(){    
            Get.to(() => ForgotPasswordScreen());        
          },
          child:Center(
            child: Text(
              "Forgot password",
              maxLines: 1,
              style: TextStyle(fontFamily: 'PoppinsBold', decoration: TextDecoration.underline, fontSize: 14, color: black),
            ),
          ),
        ),


        ),
    );
  
  Widget loginBtn() {

    return Padding(
      padding: EdgeInsets.only(right: 20.0, bottom: 20.0),
      child: SizedBox(
          height: Get.height * 0.08,
          width: Get.width * 0.4,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: () {
                var authProvider = Provider.of<AuthProvider>(context, listen: false);
                

                print(phoneController.text.isEmpty);
                

                if(phoneController.text.isEmpty || passwordController.text.isEmpty){
                  LoadingControl.showSnackBar("Ouchs!!!", "Phone number and Password is required", Icon(Icons.error, color: Colors.white,));
                  return;
                }//else if(phoneController.text.contains("+") == false){
                 // LoadingControl.showSnackBar("Ouchs!!!", "Phone number may not be valid. Please add country code as prefix next time", Icon(Icons.error, color: Colors.white,));
                  //return;
                //}
                
                String phone = authProvider.checkForCountryCode(phoneController.text);
                authProvider.setLoginPhone(phone);
                authProvider.setLoginPassword(passwordController.text);
                authProvider.staffLogin();
                //Get.to(() => LandingScreen());
                //authProvider.setLastPhoneNumber(phoneController.text);
                /* if (_formKey.currentState.validate()) {
                  userNumber = _addCountryCodeSuffixToNumber(selectedCountryCode, phoneController.text );
                  //phoneController.text = _addCountryCodeSuffixToNumber(selectedCountryCode, phoneController.text );
                  print(phoneController.text);
                  loginUser(context);
                 
                } */
              },

              color: whiteBG,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Sign In",
                      style: TextStyle(fontSize: 14,
                      fontFamily: 'PoppinsSemiBold',
                      color: mainColor
                    ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.arrow_forward_ios, size: 16, color: mainColor)
                  ),
                ],
              ),

            ),
          )
      ),
    );
  }

  Widget btnRow(){
    return SizedBox(
      height: Get.height * 0.12,
      width: Get.width,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          forgotPWDBtn(),
          //SizedBox(width: 10,),
          loginBtn()
        ],
      ),
    );
  }

  Widget mainContainer(BuildContext context){
    return Container(
      width: Get.width,
      height: Get.height,
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: Get.height * 0.1,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Image.asset("assets/images/small_logo.png", width: Get.width * 0.35, height: Get.height * 0.07,),
                  )
                ],
              )
            ),

            SizedBox(
              height: Get.height * 0.35,
              width: Get.width *0.8,
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("assets/images/loginlogo.png"),
                    fit: BoxFit.fill
                  )
                ),
              ),
            ),

            SizedBox(
              height: Get.height * 0.5,
              child: Column(
                children: [
                  SizedBox(height: 20,),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
                    child: Row(
                      children: [
                        Text("Enter Phone Number", style: TextStyle(color: Color(0xff979797), fontSize: 14, fontFamily: 'PoppinsSemiBold'),),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    child: phoneField(context),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
                    child: Row(
                      children: [
                        Text("Enter Password", style: TextStyle(color: Color(0xff979797), fontSize: 14, fontFamily: 'PoppinsSemiBold'),),
                      ],
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    child: passwordField(context),
                  ),

                  SizedBox(height: 5,),
                  btnRow()
                ],
              ),
            ),
          ],  
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: mainContainer(context),
      ),
    );
  }
}
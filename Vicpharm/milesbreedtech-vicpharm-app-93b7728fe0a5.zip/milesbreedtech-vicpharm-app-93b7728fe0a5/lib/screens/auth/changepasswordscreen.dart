import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/screens/auth/loginscreen.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class ChangePasswordScreen extends StatefulWidget {
  ChangePasswordScreen({Key? key}) : super(key: key);

  @override
  _ChangePasswordScreenState createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {

  TextEditingController currentPasswordController = TextEditingController();
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController verifyPasswordController = TextEditingController();

  bool _cObscure = true;
  bool _nObscure = true;
  bool _vObscure = true;

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() { 
    super.initState();
    checkAuth();
  }

  void checkAuth() async{
    Provider.of<AuthProvider>(context, listen: false).validateJwt().then((value)
      {
        print(value);
        if(value == false){
          Get.offAll(LoginScreen());
        }
      }
    );
  }
  

  TextFormField currentPasswordField(BuildContext context) => TextFormField(
    onEditingComplete: () => FocusScope.of(context).unfocus(),
    controller: currentPasswordController,
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
    enableSuggestions: true,

    keyboardType: TextInputType.text,
    obscureText: _cObscure,
    textInputAction: TextInputAction.done,
    decoration: InputDecoration(

        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: IconButton(
          icon: Icon(_cObscure ? Icons.visibility_off : Icons.visibility, color: Colors.grey, size: 16,),
          onPressed: (){
            print(_cObscure);
            if(_cObscure){
              setState(() {
                _cObscure = false;
              });
            }else{
              setState(() {
                _cObscure = true;
              });
            }
          },
        ),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Current Password",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)


    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter current password';
      }
      return null;
    },

  );

  TextFormField newPasswordField(BuildContext context) => TextFormField(
    onEditingComplete: () => FocusScope.of(context).unfocus(),
    controller: newPasswordController,
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
    enableSuggestions: true,

    keyboardType: TextInputType.text,
    obscureText: _nObscure,
    textInputAction: TextInputAction.done,
    decoration: InputDecoration(

        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: IconButton(
          icon: Icon(_nObscure ? Icons.visibility_off : Icons.visibility, color: Colors.grey, size: 16,),
          onPressed: (){
            print(_nObscure);
            if(_nObscure){
              setState(() {
                _nObscure = false;
              });
            }else{
              setState(() {
                _nObscure = true;
              });
            }
          },
        ),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "New Password",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)


    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter new password';
      }else if(value.length <= 5 ){
        return 'Password length is too short. Minimum of five (5) characters.';
      }
      return null;
    },

  );

  TextFormField verifyPasswordField(BuildContext context) => TextFormField(
    onEditingComplete: () => FocusScope.of(context).unfocus(),
    controller: verifyPasswordController,
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
    enableSuggestions: true,

    keyboardType: TextInputType.text,
    obscureText: _vObscure,
    textInputAction: TextInputAction.done,
    decoration: InputDecoration(

        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: IconButton(
          icon: Icon(_vObscure ? Icons.visibility_off : Icons.visibility, color: Colors.grey, size: 16,),
          onPressed: (){
            print(_vObscure);
            if(_vObscure){
              setState(() {
                _vObscure = false;
              });
            }else{
              setState(() {
                _vObscure = true;
              });
            }
          },
        ),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "New Password",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)


    ),
    validator: (value) {
      if (value!.isEmpty) {
        return 'Please enter new password';
      }else if(value != newPasswordController.text){
        return 'Password mismatch. Check your entries';
      }
      return null;
    },

  );

  Widget saveBtn() {

    return Padding(
      padding: EdgeInsets.only(right: 20.0, bottom: 20.0),
      child: SizedBox(
          height: Get.height * 0.08,
          width: Get.width * 0.4,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: () {
                if (_formKey.currentState!.validate()){
                  Provider.of<AuthProvider>(context, listen: false).changePassword(newPasswordController.text, currentPasswordController.text);
                }
              },

              color: whiteBG,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Save",
                      style: TextStyle(fontSize: 14,
                      fontFamily: 'PoppinsSemiBold',
                      color: mainColor
                    ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.save_rounded, size: 16, color: mainColor)
                  ),
                ],
              ),

            ),
          )
      ),
    );
  }

  AppBar _appBar(){
    return AppBar(
      backgroundColor: mainColor,
      centerTitle: true,
      title: Text(
        "Change Password",
        style: TextStyle(color: whiteBG, fontFamily: 'PoppinsSemiBold', fontSize: 18)
      ),
    );
  }

  Widget mainContainer(){
    return Container(
      width: Get.width,
      height: Get.height,
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: currentPasswordField(context),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: newPasswordField(context),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: verifyPasswordField(context),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: saveBtn(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
       child: Scaffold(
         appBar: _appBar(),
         body: mainContainer(),
       )
    );
  }
}
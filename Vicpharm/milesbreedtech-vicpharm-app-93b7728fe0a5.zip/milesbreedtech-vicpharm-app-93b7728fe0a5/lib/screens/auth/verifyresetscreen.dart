import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_countdown_timer/flutter_countdown_timer.dart';
import 'package:provider/provider.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class VerifyResetScreen extends StatefulWidget {
  final String? phoneNumber;

  const VerifyResetScreen({Key? key, this.phoneNumber}) : super(key: key);

  @override
  _VerifyResetScreenState createState() => _VerifyResetScreenState();
}

class _VerifyResetScreenState extends State<VerifyResetScreen> {
 bool _activateBtn = false;
  TextEditingController passwordController = new TextEditingController();
  TextEditingController vPasswordController  = new TextEditingController();
  //var brightness = SchedulerBinding.instance.window.platformBrightness;
  //bool darkModeOn = false;
  String? _code;
  bool _passwObscure = true;
  bool _passwObscureV = true;


  @override
  void initState() {
    
    waitForOTP();
    super.initState();
  }

  @override
  void dispose() {
    SmsAutoFill().unregisterListener();
    //FocusScope.of(context).dispose();
    super.dispose();
  }

  TextField passwordField(BuildContext context) => TextField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: passwordController,
    onEditingComplete: () => FocusScope.of(context).nextFocus(),
    enableSuggestions: true,
    keyboardType: TextInputType.text,
    obscureText: _passwObscure,
    textInputAction: Platform.isIOS ? TextInputAction.continueAction : TextInputAction.next,
    decoration: InputDecoration(

        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: IconButton(
          icon: Icon(_passwObscure ? Icons.visibility_off : Icons.visibility, color: Colors.grey, size: 16),
          onPressed: (){
            print(_passwObscure);
            if(_passwObscure){
              setState(() {
                _passwObscure = false;
              });
            }else{
              setState(() {
                _passwObscure = true;
              });
            }
          },
        ),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Password",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)


    ),

  );

  TextField vPasswordField(BuildContext context) => TextField(
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: black),
    controller: vPasswordController,
    onEditingComplete: () => FocusScope.of(context).unfocus(),
    enableSuggestions: true,
    keyboardType: TextInputType.text,
    obscureText: _passwObscureV,
    textInputAction: Platform.isIOS ? TextInputAction.done : TextInputAction.done,
    decoration: InputDecoration(

        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        suffixIcon: IconButton(
          icon: Icon(_passwObscureV ? Icons.visibility_off : Icons.visibility, color: Colors.grey, size: 16),
          onPressed: (){
            print(_passwObscureV);
            if(_passwObscureV){
              setState(() {
                _passwObscureV = false;
              });
            }else{
              setState(() {
                _passwObscureV = true;
              });
            }
          },
        ),

        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Confirm Password",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)

    ),

  );

  
  waitForOTP() async {
    await SmsAutoFill().listenForCode;
  }




  Text verifyText1() => Text(
    "Confirm your number",
    style: TextStyle(color: mainColor, fontSize: 14, fontFamily: 'PoppinsBold'),
  );

  Widget verifyText2() => Padding(
    padding: EdgeInsets.only(left: 22, right: 22),
    child: Text(
      "Please enter the 6 digits code sent to your number ${widget.phoneNumber}",
      style: TextStyle(fontFamily: 'PoppinsRegular', color: grey, fontSize: 12, letterSpacing: .5, ),
      textAlign: TextAlign.center,
    ),
  );

  Widget countDowntext() {

    int endt = (DateTime.now().add(Duration(minutes: 5)).millisecondsSinceEpoch).toInt();
    print(endt);
    return Padding(
      padding: EdgeInsets.only(right: 10, left: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: _activateBtn ? (){
              print(33333);
              Provider.of<AuthProvider>(context, listen: false).startResetPassword(widget.phoneNumber!);
             
            }: null,
            child: Text("Resend code: ",
              style: TextStyle(fontFamily: 'PoppinsBold', color: mvsdarkyellow, fontSize: 12, letterSpacing: .5),
            ),
          ),
          CountdownTimer(
            onEnd: (){
              print(_code);
               _code = "";
              if(mounted){
                setState(() {
                _activateBtn =  true;
              });
              }
            },
            endTime: endt,
            //textStyle: TextStyle(fontSize: 30, color: Colors.orange),
            //defaultSec: "++",
            //secSymbol: "s",
            //hoursSymbolTextStyle:  TextStyle(fontFamily: 'PoppinsRegular', color:  grey, fontSize: 12, letterSpacing: .5),
            //hoursTextStyle: TextStyle(fontFamily: 'PoppinsRegular',color:  grey, fontSize: 12, letterSpacing: .5),
            //minSymbolTextStyle: TextStyle(fontFamily: 'PoppinsRegular',color:  grey, fontSize: 12, letterSpacing: .5),
            //minTextStyle: TextStyle(fontFamily: 'PoppinsRegular',color:  grey, fontSize: 12, letterSpacing: .5),
            //secSymbolTextStyle: TextStyle(fontFamily: 'PoppinsRegular',color:  grey, fontSize: 12, letterSpacing: .5),
            //secTextStyle: TextStyle(fontFamily: 'PoppinsRegular',color:  grey, fontSize: 12, letterSpacing: .5),
          )
        ],
      ),
    );
  }

  Widget imageContainer() => Container(

    height: MediaQuery.of(context).size.height * 0.25,
    width: MediaQuery.of(context).size.width * 0.5,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: whiteBG,
      image: DecorationImage(
        image: AssetImage(
            "assets/images/verify.gif"),
        fit: BoxFit.contain,
      ),

    ),
  );

  Widget mainLayer(BuildContext context) => Container(
    height: MediaQuery.of(context).size.height,
    width: MediaQuery.of(context).size.width,
    color: whiteBG,
    child: SingleChildScrollView(

      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          SizedBox(height: MediaQuery.of(context).size.height * 0.02,),
          imageContainer(),
          SizedBox(height: MediaQuery.of(context).size.height * 0.02,),
          verifyText1(),
          SizedBox(height: MediaQuery.of(context).size.height * 0.02,),
          verifyText2(),
          SizedBox(height: MediaQuery.of(context).size.height * 0.02,),
          //pinRow(context),
          SizedBox(
            width:  MediaQuery.of(context).size.width * 0.75,
            child: PinFieldAutoFill(
              onCodeChanged: (String? code){
                print(code);
                _code = code;
              
              },
              onCodeSubmitted: (String code){
                print("submitted");
              },
              codeLength: 6,
              decoration: BoxLooseDecoration(
                strokeColorBuilder: FixedColorBuilder(Colors.grey)
              ),
              currentCode: _code,
            ),
          ),
          SizedBox(height: MediaQuery.of(context).size.height * 0.02,),
          Padding(
            padding: EdgeInsets.only(top: 10, bottom: 10, right: 40, left: 40),
            child: passwordField(context),
          ),

          Padding(
            padding: EdgeInsets.only(top: 10, bottom: 20, right: 40, left: 40),
            child: vPasswordField(context),
          ),
        
          countDowntext(),
          SizedBox(height: MediaQuery.of(context).size.height * 0.04,),
          Align(
            alignment: Alignment.bottomCenter,
            child: verifyBtn(context),
          )
        ],
      ),

    ),
  );

  Widget verifyBtn(BuildContext context) => Padding(
    padding: EdgeInsets.only(bottom: 20.0),
    child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.08,
        width: MediaQuery.of(context).size.width * 0.6,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(50)),
            boxShadow: <BoxShadow>[
              BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
              ),
            ],
          ),
          child: MaterialButton(
            elevation: 0.0,
            shape: StadiumBorder(),
            onPressed: (){
              print(_code);
              if(_code != null && _code!.isNotEmpty && _code!.length == 6){
                if(passwordController.text == vPasswordController.text){
                  Provider.of<AuthProvider>(context, listen: false).resetPassword(widget.phoneNumber!, passwordController.text, _code!);
                }else{
                   LoadingControl.showSnackBar(
                      "Ouchs!!!", 
                      "Password mismatch. Check your inputs and try again.", 
                      Icon(Icons.error, color: Colors.red,)
                    );
                }
              }else{
                 LoadingControl.showSnackBar(
                  "Ouchs!!!", 
                  "Invalid code. Please use a valid code.", 
                  Icon(Icons.error, color: Colors.red,)
                );
              
              }
              _code = "";
            },
            color: whiteBG,
            child: Stack(
              //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Verify & Reset account",
                    style: TextStyle(fontSize: 12,
                        fontFamily: 'PoppinsSemiBold',

                        color: mainColor),
                  ),
                ),
                Align(
                    alignment: Alignment.centerRight,
                    child: Icon(Icons.arrow_forward_ios, size: 12, color: mainColor)
                ),
              ],
            ),

          ),
        )
    ),
  );

  @override
  Widget build(BuildContext context) {

    //darkModeOn = brightness == Brightness.dark;
    //setState(() {

    //print(darkModeOn);

    return SafeArea(
        child: WillPopScope(
            onWillPop: () async => true,
            child: Scaffold(
                body: mainLayer(context)
            )
        )
    );

  }
}
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:vicpharm_app/screens/auth/authprovider.dart';
import 'package:vicpharm_app/utils/projectcolors.dart';

class ForgotPasswordScreen extends StatefulWidget {
  @override
  _ForgotPasswordScreenState createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  TextEditingController phoneController = TextEditingController();

  TextFormField phoneField(BuildContext context) => TextFormField(
    onEditingComplete: () => FocusScope.of(context).unfocus(),
    controller: phoneController,
    style: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: Colors.black),
    enableSuggestions: true,

    keyboardType: TextInputType.phone,
    textInputAction: TextInputAction.done,
    decoration: InputDecoration(

        filled: true,
        fillColor: Color(0xffecf0f1),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        
        floatingLabelBehavior: FloatingLabelBehavior.never,
        errorStyle: TextStyle(fontSize: 12, color: errorTextColor),
        hintText: "Enter your Phone number",
        hintStyle: TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: 12, color: grey)


    ),
    

  );

  Widget saveBtn() {

    return Padding(
      padding: EdgeInsets.only(right: 20.0, bottom: 20.0),
      child: SizedBox(
          height: Get.height * 0.08,
          width: Get.width * 0.4,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(50)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 15,
                  spreadRadius: 3,
                  offset: Offset(-1, 18),
                ),
              ],
            ),
            child: MaterialButton(
              elevation: 0.0,
              shape: StadiumBorder(),
              onPressed: () {
                if(phoneController.text.isNotEmpty){
                  String phone = Provider.of<AuthProvider>(context, listen: false).checkForCountryCode(phoneController.text);
                  if(phone != null && phone.isNotEmpty){
                    Provider.of<AuthProvider>(context, listen: false).startResetPassword(phoneController.text);
                  }                
                }
              },

              color: whiteBG,
              child: Stack(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Continue",
                      style: TextStyle(fontSize: 14,
                      fontFamily: 'PoppinsSemiBold',
                      color: mainColor
                    ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Icon(Icons.arrow_forward_ios, size: 16, color: mainColor)
                  ),
                ],
              ),

            ),
          )
      ),
    );
  }

  AppBar _appBar(){
    return AppBar(
      backgroundColor: mainColor,
      centerTitle: true,
      title: Text(
        "Reset Password",
        style: TextStyle(color: whiteBG, fontFamily: 'PoppinsSemiBold', fontSize: 18)
      ),
    );
  }

  Widget mainContainer(){
    return Container(
      width: Get.width,
      height: Get.height,
      child: SingleChildScrollView(
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: Get.height * 0.2,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: phoneField(context),
              ),

             
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: saveBtn(),
              ),
            ],
          ),
        
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
       child: Scaffold(
         appBar: _appBar(),
         body: mainContainer(),
       )
    );
  }
}
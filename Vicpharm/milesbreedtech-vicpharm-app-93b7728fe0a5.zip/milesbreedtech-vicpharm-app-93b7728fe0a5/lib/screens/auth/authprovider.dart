import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_app_badger/flutter_app_badger.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:jwt_decode/jwt_decode.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vicpharm_app/models/activity.dart';
import 'package:vicpharm_app/models/expiryinventory.dart';
import 'package:vicpharm_app/models/profile.dart';
import 'package:vicpharm_app/screens/auth/loginscreen.dart';
import 'package:vicpharm_app/screens/auth/verifyresetscreen.dart';
import 'package:vicpharm_app/screens/landing/landingscreen.dart';
import 'package:vicpharm_app/utils/httpservice.dart';
import 'package:vicpharm_app/utils/loadingcontrol.dart';
import 'package:vicpharm_app/utils/sharedprefs.dart';

import '../../main.dart';

class AuthProvider with ChangeNotifier {
  final HttpService _httpService = new HttpService();
  late String _loginPhoneNumber;
  late String _loginPassword;
  late String? _token;
  late int? _activitesTotalPage;
  late Profile _profile;
  int? _staff = 0;
  int? _noOfproduct = 0;
  int? _customer = 0;
  List<Map<String, dynamic>>? _topSelling = [];
  List<Map<String, dynamic>>? _totalStock = [];
  List<Map<String, dynamic>>? _lowStock = [];
  NotificationAppLaunchDetails? _notificationAppLaunchDetails;
  List<ExpiryInventory> _expiryInventories = [];
   RefreshController _refreshController = RefreshController();

  RefreshController get refreshController => _refreshController;
  List<ExpiryInventory> get expiryInventories => _expiryInventories;
  NotificationAppLaunchDetails? get notificationAppLaunchDetails => _notificationAppLaunchDetails;
  List<Map<String, dynamic>>? get topSelling => _topSelling;
  List<Map<String, dynamic>>? get totalStock => _totalStock;
  List<Map<String, dynamic>>? get lowStock => _lowStock;
  late List<Activity> _activities = [];
  int? get noOfproduct => _noOfproduct;
  int? get customer => _customer;
  int? get staff => _staff;
  String get loginPassword => _loginPassword;
  String get loginPhoneNumber => _loginPhoneNumber;
  String? get token => _token;
  List<Activity> get activities => _activities;
  int? get activitiesTotalPage => _activitesTotalPage;
  Profile get profile => _profile;

  setNotificaton(NotificationAppLaunchDetails napd){
    _notificationAppLaunchDetails = napd;
  }

  Future<void> _showNotification() async {
      

      const AndroidNotificationDetails androidPlatformChannelSpecifics = AndroidNotificationDetails(
              '0', 
              'count_expiry_inventory', 
              'Notification to show number of upcoming products expiration',
              importance: Importance.max,
              priority: Priority.high,
              ticker: 'ticker',
        icon: "ic_stat_name"
      );

      const NotificationDetails platformChannelSpecifics = NotificationDetails(android: androidPlatformChannelSpecifics);

      await flutterLocalNotificationsPlugin.show(
          0, 
          'This number of products are about to expiry', 
          '${_expiryInventories.length}', 
          platformChannelSpecifics
      );
    }
    
  setTempProfilePic(String path){
    _profile.personalInfo!.profileImage = path;
    //rnotifyListeners();
  }
  storeLoginPhone(String phone){
    SharedPrefs.instance.saveString("phone", phone);
  }

  Future<String?> retrievePhone() async{
    String? ph = await SharedPrefs.instance.retrieveString("phone");
    return ph;
  }

  String checkForCountryCode(String phone){
    
      if(phone.contains("+234")){
        return phone;
      }else if(phone.startsWith("0")){
        phone = "+234" + phone.substring(1);
        return phone;
      }else{
        return "";
      }
    
  }
  
  setLoginPhone(String data){
    if(data == null || data.isEmpty){
      LoadingControl.showSnackBar("Ouchs!!!", "Phone Number is required", Icon(Icons.error, color: Colors.white,));
      return;
    }
    _loginPhoneNumber = data;
    
  }

  setLoginPassword(String data){
    if(data == null || data.isEmpty){
      LoadingControl.showSnackBar("Ouchs!!!", "Password is required", Icon(Icons.error, color: Colors.white,));
      return;
    }
    _loginPassword = data;
  }

  saveToken(String token){
    if(token != null && token.isNotEmpty){
      SharedPrefs.instance..saveString("token", token);
    }
  }

  saveVat(double vat){

      SharedPrefs.instance.saveDouble("vat", vat);
    
  }

  retrieveProfile() async{
    String userJson = await SharedPrefs.instance.retrieveUserData();
    
    Profile pp = Profile.fromJson(json.decode(userJson));
   // if(pp != null){
      _profile = pp;
   // }
  }

  Future<String?> retrieveToken() async{
    _token = await SharedPrefs.instance.retrieveString("token");
    return _token;
  }

    
  saveUser(Profile userObject){

    if(userObject != null){
      print(userObject);
      SharedPrefs.instance.setUserData(userObject);

    }
  }
  
  
  void staffLogin() async{    

    LoadingControl.showLoading();
    final response = await _httpService.staffLoginRequest(_loginPhoneNumber, _loginPassword);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "It seems you are having network issues. Please check the internet conncetivity and try again.", 
        Icon(Icons.warning_rounded, color: Colors.orange,)
      );
      return;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    if(statusCode == 403){
      LoadingControl.showSnackBar(
          "Ouchs!!!",
          "You are not allowed to perform this action.",
          Icon(Icons.error, color: Colors.red,)
      );
      return;
    }

    String status = payload['status'] ?? "";



    if (status.toLowerCase() == "ok" && statusCode == 201){     
      
      var data = payload['profile'];

      try{
        Profile prof = Profile.fromJson(data);
        saveUser(prof);
        SharedPrefs.instance.saveToken("token", payload['token'])
        .then((value) {
          SharedPrefs.instance.saveString("phone", _loginPhoneNumber);
          saveToken(payload['token']);
          saveVat(payload['vat']['vat'].toDouble());
          LoadingControl.dismissLoading();
          print("here");
          getExpiryInventories(onlyOnce: true);
          Get.offAll(() => LandingScreen());
        });
        
      }catch(e){
        print(e);
      }
      
      LoadingControl.dismissLoading();
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    
    else if(statusCode == 401){
      print("error of 422");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    else if(statusCode == 404){
      print("error of 422");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. This user does not exist.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    

  }

  void changePassword(String newPassword, String oldPassword) async{    

    LoadingControl.showLoading();
    final response = await _httpService.changePasswordRequest(oldPassword, newPassword);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){     
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Your password have been changed successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );
      
      Get.offAll(LoginScreen());

    }else if(statusCode == 422){
      print("error of 422");
      
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    
    else if(statusCode == 401){
      print("error of 422");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    

  }

  Future<List<Activity>?> populateActivities(int page) async{
    var data = await retrieveActivities(page);
    if(data == null){
      return null;
    }
    for(var i = 0; i < data.length; i++){
        final Activity acti = Activity.fromJson(data[i]); 
        _activities.add(acti);
    }
    return _activities;
  }

  Future<List<dynamic>?> retrieveActivities(int page) async{
    //LoadingControl.showLoading();
    final response = await _httpService.getActivitiesRequest(page);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){     
      
      var data = payload["Activities"];    
      _activitesTotalPage = (payload['totalItems']/50).ceil();  
      LoadingControl.dismissLoading();
      return data;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  void populateDashboard()async{
    var data = await getDashboardData();

    if(data == null){
      return;
    }
     _topSelling!.clear();
    _totalStock!.clear();
    _lowStock!.clear();
    
    var topSelling = data['TopSelling'];
    var topStock = data['totalStock'];
    var lowStock = data['lowStock'];
    print("SEEEEEEEEEEEEEEEEEEEE");
   // print(topSelling);

    for(var i = 0; i < topSelling.length; i++){
      Map<String, dynamic> quantity = topSelling[i];
      _topSelling!.add(quantity);
    }

    for(var i = 0; i < topStock.length; i++){
      Map<String, dynamic> quantity = topStock[i];
      _totalStock!.add(quantity);
    }

    for(var i = 0; i < lowStock.length; i++){
      Map<String, dynamic> quantity = lowStock[i];
      _lowStock!.add(quantity);
    }


    //print(_topSelling![0]);

    _topSelling!.sort((m1, m2) {
      var ma = m1["TotalSales"] != null ? m1["TotalSales"].toDouble() : 0.0;
      var mb = m2["TotalSales"] != null ? m2["TotalSales"].toDouble() : 0.0;

      var r = ma.compareTo(mb);
      print(m1);
      print(m2);
      print(r);
      return r;
      
    });

   

    _topSelling = _topSelling!.reversed.toList();
    if(_topSelling!.length > 15){
      _topSelling = _topSelling!.take(15).toList();
    }

    //if(_totalStock!.length > 30){
    //  _totalStock = _totalStock!.take(15).toList();
   // }    
  
    notifyListeners();
  }
  
  Future<dynamic?> getDashboardData() async{
    //LoadingControl.showLoading();
    final response = await _httpService.getDashboardDataRequest();

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 201){     
      
      _staff = payload["staff"];    
      _noOfproduct = payload["noOfproduct"];    
      _customer = payload["customer"];    
      
      return payload;
      //notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
    else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  void startResetPassword(String phoneNumber) async{    

    LoadingControl.showLoading();
    final response = await _httpService.startResetPasswordRequest(checkForCountryCode(phoneNumber));

    if(response == null){
      LoadingControl.dismissLoading();
      return;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){     
      
     
      LoadingControl.dismissLoading();
       LoadingControl.showSnackBar(
        "Success!!!", 
        "A reset code have been sent your phone number. Enter the code to continue", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );
     Get.to(() => VerifyResetScreen(phoneNumber: phoneNumber,));

    }else if(statusCode == 422){
      print("error of 422");
      
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    
    else if(statusCode == 401){
      print("error of 422");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    else if(statusCode == 404){
      print("error of 422");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. This user does not exist.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    

  }

  void resetPassword(String phoneNumber, String password, String activationCode) async{    

    LoadingControl.showLoading();
    final response = await _httpService.resetPasswordRequest(checkForCountryCode(phoneNumber), password, activationCode);

    if(response == null){
      LoadingControl.dismissLoading();
       LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "It seems you are connected to the internet. Check your internet connectivity and try again", 
        Icon(Icons.error, color: Colors.red,)
      );
      return;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 201){     
      
     
      LoadingControl.dismissLoading();
       LoadingControl.showSnackBar(
        "Success!!!", 
        "Your password have been changed successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );

      Future.delayed(Duration(seconds: 2), () => Get.offAll(() => LoginScreen()) );
     

    }else if(statusCode == 422){
      print("error of 422");
      
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    
    else if(statusCode == 401){
      print("error of 422");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. Please provide valid login details", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    else if(statusCode == 404){
      print("error of 422");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User authenication failed. This user does not exist.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    

  }

  void updateStaffProfile(Profile pp, PickedFile imageFile) async{    

    LoadingControl.showLoading();
    final response = await _httpService.updateStaffProfileRequest(pp, imageFile);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){  

      LoadingControl.dismissLoading();   
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Profile updated successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );
      
      //Get.offAll(Land);

    }else if(statusCode == 422){
      print("error of 422");
      
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    

  }

  Future<bool> validateJwt() async{
    final token = await retrieveToken();
    if(token == null || token.isEmpty){
      return false;
    }
    
    DateTime? expiryDate = Jwt.getExpiryDate(token);
    DateTime? now = DateTime.now();

    if(expiryDate == null){
      return false;
    }
    Duration diff = expiryDate.difference(now);
    print(diff);
    if(diff.isNegative){
      return false;
    }else{
      return true;
    }
  }

  
  void _addBadge() {
    FlutterAppBadger.updateBadgeCount(_expiryInventories.length);
  }
  
  Future<dynamic?> getExpiryInventories({bool onlyOnce = false}) async{
    //LoadingControl.showLoading();
    final response = await _httpService.getAllExpiryInventoryRequest();

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){     
      _refreshController.refreshCompleted();
      
      var data  = payload["expiryInventory"];    
      _expiryInventories.clear();
      for (var i = 0; i < data.length; i++) {
        try{
          ExpiryInventory ei = ExpiryInventory.fromJson(data[i]);
          _expiryInventories.add(ei);
        }catch(e){
          print(e);
        }
      }

      if(onlyOnce && _expiryInventories.length > 0){
         _showNotification();
        _addBadge();
      }
       

      LoadingControl.dismissLoading();
      //_refreshController.loadComplete();
      notifyListeners();

    }else if(statusCode == 422){
      print("error of 422");
      
      LoadingControl.dismissLoading();
       _refreshController.loadFailed();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    
    else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
       _refreshController.loadFailed();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
       _refreshController.loadFailed();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }else {
      LoadingControl.dismissLoading();
       _refreshController.loadFailed();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
  }

  void inventorySoldOut(String inventoryId) async{    

    LoadingControl.showLoading();
    final response = await _httpService.soldOutRequest(inventoryId);

    if(response == null){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Seems you are not connected to internet. Check your connection and try again. Contact support if it persists.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return;
    }

    int statusCode = response.statusCode;
    var payload = response.data;
    print(response);
    print(payload);

    String status = payload['status'] ?? "";

    if (status.toLowerCase() == "ok" && statusCode == 200){   

      LoadingControl.dismissLoading();  
      
      LoadingControl.showSnackBar(
        "Success!!!", 
        "Inventory update was successfully", 
        Icon(Icons.check_box_rounded, color: Colors.green,)
      );

      Future.delayed(Duration(seconds: 1), (){
        Get.offAll(LandingScreen());
      });     
      

    }else if(statusCode == 422){
      print("error of 422");
      
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Your request could not be processed. Check your inputs and try again.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    
     else if(statusCode == 401){
      print("error of 401");

      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "User not authorized to perform this operation.", 
        Icon(Icons.error, color: Colors.red,)
      );
      return null;
    }
    else if(statusCode == 500){
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "An error occurred. Don't worry, we are working on it.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }else {
      LoadingControl.dismissLoading();
      LoadingControl.showSnackBar(
        "Ouchs!!!", 
        "Unknown server error occurred. If it persists, please contact support.", 
        Icon(Icons.error, color: Colors.red,)
      );
    }
    

  }


}
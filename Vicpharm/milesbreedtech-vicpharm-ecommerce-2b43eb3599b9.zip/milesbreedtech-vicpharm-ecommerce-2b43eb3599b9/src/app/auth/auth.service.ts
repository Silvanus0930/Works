import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  public authenticatedUser = new BehaviorSubject<boolean>(null);

  constructor() { }

  checkAuthenticated() {

    var authenticated =  false;

    var user = JSON.parse(localStorage.getItem('vicpharm_ecommerce_user'));
    if(user && user._id){

      this.setAuthenticatedUser(user);
      authenticated =  true;
      
    }

    return authenticated;
  }

  // set and get user functions
  getAuthenticatedUser(){
    return this.authenticatedUser.asObservable();
  }

  setAuthenticatedUser(user){
    this.authenticatedUser.next(user);
  }

  logout(){

    localStorage.removeItem('vicpharm_ecommerce_token')
    localStorage.removeItem('vicpharm_ecommerce_user')

    this.setAuthenticatedUser(null);

  }
  
}

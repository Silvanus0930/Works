import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../functions/request.service';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

  public year: any = null;
  
  public categories: any = [];

  constructor(
    private functionService: RequestService,
    private authService: AuthService,
  ) { }

  ngOnInit(): void {

    this.year = new Date().getFullYear();
    this.getCategories()
  }

  toastNotification(response) {

    this.functionService.showNotification(response);

  }
  
  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // get categories
  getCategories(){

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'GetCategories';

    this.functionService.getHttpRequestService(route).subscribe(
      (res: any)=>{

        if(res.status.toLowerCase() == httpSuccessText){

          this.categories = [];

          var categories = res.Categories.sort(() => Math.random() - 0.5);

          for (let i = 0; i < 4; i++) {

            if(categories[i]){

              var category = {
                id: categories[i]._id,
                name: categories[i].name ? this.capitalize(categories[i].name.toLowerCase()) : null,
              }

              this.categories.push(category);
              
            }
            
          }
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // capitalize text
  capitalize(sample){
    const words = sample.split(" ");

    for (let i = 0; i < words.length; i++) {
        words[i] = words[i][0].toUpperCase() + words[i].substr(1);
    }

    return words.join(" ");
  }

  // go to category products
  goToCategoryProducts(id){

    this.goToPage('products/category/'+id)

  }

}

import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../functions/request.service';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  public showMenu: any = false;

  // search variables
  public showSearchItems = false;
  public showSearchLoading = false;
  public searchText: any = null;
  public searchResult: any = [];

  public categories: any = [];
  
  public listOfCarts: any = [];

  
  // user variables
  public showUser = false;
  public user: any = {}
  

  constructor(
    private functionService: RequestService,
    private authService: AuthService,
  ) { 

  }

  ngOnInit(): void {

    this.getCategories()
    this.getListCart()
    
    this.authService.checkAuthenticated();

    this.authService.getAuthenticatedUser().subscribe((authenticatedUser: any)  => {

      if(authenticatedUser && authenticatedUser._id){

        this.user = authenticatedUser;

      }
    });

  }

  toastNotification(response) {

    this.functionService.showNotification(response);

  }
  
  // goto selected page
  goToPage(page){

    this.showMenu = false;
    this.toggleShowUser(false);
    this.functionService.setMenu(page);

  }

  // toggle menu
  toggleMenu(){

    this.showMenu = !this.showMenu

  }

  // toggle showSearchItems
  toggleShowSearchItems(status){

    this.showSearchItems = status
    this.toggleShowUser(false);
    
    if(status == false){

      this.searchText = null;

    }

  }

  // toggle showSearchLoading
  toggleShowSearchLoading(status){

    this.showSearchLoading = status

  }

  // search function
  searchEvent(event){

    var searchText = event.target.value;

    if(searchText && searchText.toString().length > 2 ){

      this.searchText = searchText;
      this.toggleShowSearchItems(true);
      this.searchResult = [];

      this.search();

    }

  }

  // search for product
  search(){

    this.toggleShowSearchLoading(true);

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'SearchProduct';
    var requestData = {
      keywords: this.searchText,
    }

    this.functionService.putHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        this.toggleShowSearchLoading(false);

        if(res.status.toLowerCase() == httpSuccessText){

          this.searchResult = [];

          var products = res.Product

          for (let i = 0; i < products.length; i++) {
            
            var product = {
              id: products[i]._id,
              image: products[i].Imageurl ? products[i].Imageurl : './assets/img/test-1.png',
              name: products[i].name ? products[i].name : null,
              priceInRange: products[i].unitOfMeasurement.length > 1 ? true : false,
              lowSellingPrice: 0,
              highSellingPrice: 0,
            }

            var sellingPricesUnits = products[i].sellingPrice ? Object.keys(products[i].sellingPrice) : [];
            var sellingPrices = [];

            for (let j = 0; j < sellingPricesUnits.length; j++) {

              var unit = sellingPricesUnits[j];
              
              sellingPrices.push(products[i].sellingPrice[unit]);
              
            }

            product.lowSellingPrice = Math.min(...sellingPrices)
            if(product.priceInRange){

              product.highSellingPrice = Math.max(...sellingPrices)

            }

            this.searchResult.push(product);
            
          }
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.toggleShowSearchLoading(false);

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // get categories
  getCategories(){

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'GetCategories';

    this.functionService.getHttpRequestService(route).subscribe(
      (res: any)=>{

        if(res.status.toLowerCase() == httpSuccessText){

          this.categories = [];

          var categories = res.Categories

          for (let i = 0; i < 10; i++) {

            if(categories[i]){

              var category = {
                id: categories[i]._id,
                name: categories[i].name ? this.capitalize(categories[i].name.toLowerCase()) : null,
              }

              this.categories.push(category);
              
            }
            
          }

          this.categories.sort((a, b) => a.name.localeCompare(b.name))
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // capitalize text
  capitalize(sample){
    const words = sample.split(" ");

    for (let i = 0; i < words.length; i++) {
        words[i] = words[i][0].toUpperCase() + words[i].substr(1);
    }

    return words.join(" ");
  }

  // go to category products
  goToCategoryProducts(id){

    this.goToPage('products/category/'+id)

  }
  
  // get list of carts
  getListCart(){

    this.functionService.getCart().subscribe((cart)=>{

      this.listOfCarts = cart;

    })

  }

  // toggle showUser
  toggleShowUser(status){

    this.showUser = status

  }

  // goto single product page
  goToSingleProduct(product){
    
    this.toggleShowSearchItems(false);
    this.goToPage('products/single/'+product.id);

  }

  logout(){

    this.toggleShowUser(false);

    this.user = {}

    this.authService.logout()

  }

}

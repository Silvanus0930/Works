import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { RequestService } from './functions/request.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ecommerce';

  constructor(
    private functionService: RequestService,
    private spinner: NgxSpinnerService,
  ){

    this.getLoading()

  }

  // get loading status
  getLoading(){

    this.functionService.getLoading().subscribe((loading) => {

      if(loading){

        this.spinner.show();

      }else{

        this.spinner.hide();

      }

    });

  }
}

import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { RequestService } from '../functions/request.service';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  public userdata: any = {
    firstName: null,
    lastName: null,
    phoneNumber: null,
    email: null,
    password: null,
  };

  public direction: any = null;

  constructor(
    private functionService: RequestService,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {

    this.activatedRoute.params.subscribe((res)=>{

      if(res.from){

        this.direction = res.from

      }

    });

  }

  // start and stop loading funx
  startLoading(){

    this.functionService.setLoading(true);

  }

  stopLoading(){

    this.functionService.setLoading(false);

  }

  toastNotification(response) {

    this.functionService.showNotification(response);

  }

  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // create account
  createAccount(form: NgForm){

    var numberPrefix = '+234';
    var extractedNumber = this.userdata.phoneNumber.substring(1, this.userdata.phoneNumber.length);
    var loginPhoneNumber = numberPrefix+extractedNumber;

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'SignUp';
    var requestData = {
      phoneNumber: loginPhoneNumber,
      password: this.userdata.password,
      email: this.userdata.email,
      firstName: this.userdata.firstName,
      lastName: this.userdata.lastName
    }

    this.functionService.postHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.status.toLowerCase() == httpSuccessText){

          requestResponse = 'Registration complete';
          this.toastNotification(requestResponse);

          localStorage.setItem('vicpharm_ecommerce_token', res.token);
          localStorage.setItem('vicpharm_ecommerce_user', JSON.stringify(res.user));

          this.authService.setAuthenticatedUser(res.user);

          form.resetForm();

          if(this.direction == 'cart'){
            this.goToPage('cart')
          }else{
            this.goToPage('home')
          }
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

}

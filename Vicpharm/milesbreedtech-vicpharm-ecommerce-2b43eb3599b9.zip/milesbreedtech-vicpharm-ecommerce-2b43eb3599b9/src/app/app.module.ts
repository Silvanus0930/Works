import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MaterialModule } from './material/material.module';
import { NgxSpinnerModule } from "ngx-spinner";
import { FontAwesomeModule, FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { fas } from '@fortawesome/free-solid-svg-icons'
import { far } from '@fortawesome/free-regular-svg-icons'
import { fab } from '@fortawesome/free-brands-svg-icons'
import { JwtModule } from '@auth0/angular-jwt';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { GooglePlaceModule } from "ngx-google-places-autocomplete";
import { Angular4PaystackModule } from 'angular4-paystack';

import { FooterComponent } from './component/footer/footer.component';
import { HeaderComponent } from './component/header/header.component';
import { HomeComponent } from './home/home.component';
import { AllProductsComponent } from './product/all-products/all-products.component';
import { SingleProductsComponent } from './product/single-products/single-products.component';
import { OrderProductComponent } from './product/order-product/order-product.component';
import { CartComponent } from './product/cart/cart.component';
import { ContactComponent } from './contact/contact.component';
import { CategoryProductsComponent } from './product/category-products/category-products.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';


@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    HomeComponent,
    AllProductsComponent,
    SingleProductsComponent,
    OrderProductComponent,
    CartComponent,
    ContactComponent,
    CategoryProductsComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FontAwesomeModule,
    BrowserAnimationsModule,
    NgxSpinnerModule,
    MaterialModule,
    FormsModule,
    HttpClientModule,
    GooglePlaceModule,
    NgxSkeletonLoaderModule.forRoot({ animation: 'progress' }),
    Angular4PaystackModule.forRoot('pk_live_4c5484d185026f69659c2c99f647f44b1dd8adbf'),
    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter,
        allowedDomains: ["vicpharm.milesbreed.com", "pharmacy.vicpharm.store", 'localhost:4200'],
        disallowedRoutes: [],
      }
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 

  constructor(library: FaIconLibrary) { 

		library.addIconPacks(fas, fab, far);

	}

}

export function tokenGetter() {
  return localStorage.getItem('vicpharm_ecommerce_token');
}
import { Component, OnInit } from '@angular/core';
import { RequestService } from '../functions/request.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  // feature products
  public featuredProducts: any = [];
  public superSaleProducts: any = [];
  public superSaleIndex = 0; 

  // testimonials
  public activeTestimonialIndex: any = 0
  public testimonials: any = [
    {
      message: 'Vicpharm has great customer care service. The staff always have a way to make you smile',
      name: 'Mrs Blessing',
      image: './assets/img/avatar.png',
      star: [1,1,1,1]
    },
    {
      message: 'I love patronizing Vicpharm for my routine drugs because their prices are cheap and very affordable',
      name: 'Khadijat',
      image: './assets/img/avatar.png',
      star: [1,1,1,1]
    },
    {
      message: 'Vicpharm is one wholesale pharmacy that is quick to answer my calls whenever I put a call through. They are never too busy to attend to me',
      name: 'Chuks',
      image: './assets/img/avatar.png',
      star: [1,1,1]
    },
    {
      message: 'I feel very at ease walking into Vicpharm to procure my medications. The personnels are very nice and the environment is inviting',
      name: 'Mrs James',
      image: './assets/img/avatar.png',
      star: [1,1]
    },
    {
      message: 'I love the fact that I can get quick delivery whenever I place an order for my supplements. Vicpharm is an ultra-modern pharmacy with the use of technology for easy transaction',
      name: 'Becca',
      image: './assets/img/avatar.png',
      star: [1,1,1,1,1]
    },
  ]


  constructor(
    private functionService: RequestService,
  ) { }

  ngOnInit(): void {

    this.getFeaturedProducts();
    this.getSupersaleProducts();

  }

  // start and stop loading funx
  startLoading(){

    this.functionService.setLoading(true);

  }

  stopLoading(){

    this.functionService.setLoading(false);

  }

  toastNotification(response) {

    this.functionService.showNotification(response);

  }
  
  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // get featured products
  getFeaturedProducts(){

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'GetFeatureProduct';

    this.functionService.getHttpRequestService(route).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.status.toLowerCase() == httpSuccessText){

          this.featuredProducts = [];

          var products = res.Products

          for (let i = 0; i < 8; i++) {

            if(products[i]){

              var product = {
                id: products[i]._id,
                image: products[i].Imageurl ? products[i].Imageurl : './assets/img/sample.jpg',
                name: products[i].name ? products[i].name : null,
                priceInRange: products[i].unitOfMeasurement.length > 1 ? true : false,
                lowSellingPrice: 0,
                highSellingPrice: 0,
                super: products[i].superSales
              }
  
              var sellingPricesUnits = products[i].sellingPrice ? Object.keys(products[i].sellingPrice) : [];
              var sellingPrices = [];
  
              for (let j = 0; j < sellingPricesUnits.length; j++) {
  
                var unit = sellingPricesUnits[j];
                
                sellingPrices.push(products[i].sellingPrice[unit]);
                
              }
  
              product.lowSellingPrice = Math.min(...sellingPrices)
              if(product.priceInRange){
  
                product.highSellingPrice = Math.max(...sellingPrices)
  
              }
  
              this.featuredProducts.push(product);
              
            }
            
          }
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // goto single product page
  goToSingleProduct(product){
    
    this.goToPage('products/single/'+product.id);

  }

  // toggle testimonials
  toggleTestimonial(index){
    
    var activeTestimonialIndex = Number(index) + Number(this.activeTestimonialIndex)
    if(activeTestimonialIndex > this.testimonials.length){

      activeTestimonialIndex = this.testimonials.length - 1;

    }else if(activeTestimonialIndex < 0){

      activeTestimonialIndex = 0;

    }

    this.activeTestimonialIndex = activeTestimonialIndex;

  }

  // get supersale products
  getSupersaleProducts(){

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'GetSuperSales';

    this.functionService.getHttpRequestService(route).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.status.toLowerCase() == httpSuccessText){

          this.superSaleProducts = [];

          var products = res.Products

          for (let i = 0; i < 8; i++) {

            if(products[i]){

              var product = {
                id: products[i]._id,
                image: products[i].Imageurl ? products[i].Imageurl : './assets/img/sample.jpg',
                name: products[i].name ? products[i].name : null,
                description: products[i].description ? products[i].description : null,
                priceInRange: products[i].unitOfMeasurement.length > 1 ? true : false,
                lowSellingPrice: 0,
                highSellingPrice: 0,
                super: products[i].superSales
              }
  
              var sellingPricesUnits = products[i].sellingPrice ? Object.keys(products[i].sellingPrice) : [];
              var sellingPrices = [];
  
              for (let j = 0; j < sellingPricesUnits.length; j++) {
  
                var unit = sellingPricesUnits[j];
                
                sellingPrices.push(products[i].sellingPrice[unit]);
                
              }
  
              product.lowSellingPrice = Math.min(...sellingPrices)
              if(product.priceInRange){
  
                product.highSellingPrice = Math.max(...sellingPrices)
  
              }
  
              this.superSaleProducts.push(product);
              
            }
            
          }
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // toggle SuperSalesIndex
  toggleSuperSalesIndex(index){
    
    var superSaleIndex = Number(index) + Number(this.superSaleIndex)
    if(superSaleIndex > this.superSaleProducts.length-1){

      superSaleIndex = this.superSaleProducts.length - 1;

    }else if(superSaleIndex < 0){

      superSaleIndex = 0;

    }

    this.superSaleIndex = superSaleIndex;

  }

}

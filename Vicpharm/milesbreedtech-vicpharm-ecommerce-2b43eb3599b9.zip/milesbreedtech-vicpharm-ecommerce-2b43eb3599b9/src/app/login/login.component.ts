import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { RequestService } from '../functions/request.service';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public userdata: any = {
    firstName: null,
    lastName: null,
    phoneNumber: null,
    email: null,
    password: null,
  };

  public direction: any = null;

  constructor(
    private functionService: RequestService,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {

    this.activatedRoute.params.subscribe((res)=>{

      if(res.from){

        this.direction = res.from

      }

    });

  }

  // start and stop loading funx
  startLoading(){

    this.functionService.setLoading(true);

  }

  stopLoading(){

    this.functionService.setLoading(false);

  }

  toastNotification(response) {

    this.functionService.showNotification(response);

  }

  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // create account
  loginUser(form: NgForm){

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'Login';
    var requestData = {
      password: this.userdata.password,
      phoneNumber: this.userdata.email,
    }

    this.functionService.postHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.token){

          requestResponse = 'Login complete';
          this.toastNotification(requestResponse);

          this.authService.setAuthenticatedUser(res.profile);

          localStorage.setItem('vicpharm_ecommerce_token', res.token);
          localStorage.setItem('vicpharm_ecommerce_user', JSON.stringify(res.profile));

          form.resetForm();

          if(this.direction == 'cart'){
            this.goToPage('cart')
          }else{
            this.goToPage('home')
          }
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

}

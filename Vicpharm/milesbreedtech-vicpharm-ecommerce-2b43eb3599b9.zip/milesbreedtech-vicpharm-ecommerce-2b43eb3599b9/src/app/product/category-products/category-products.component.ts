import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RequestService } from '../../functions/request.service';


@Component({
  selector: 'app-category-products',
  templateUrl: './category-products.component.html',
  styleUrls: ['./category-products.component.scss']
})
export class CategoryProductsComponent implements OnInit {

  // categories
  public passedCategory: any = {
    id:  null,
    name: null
  }
  public categories: any = [];
  
  // products
  public productList: any = [];


  constructor(
    private functionService: RequestService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {

    this.activatedRoute.params.subscribe((res)=>{

      if(res.id){

        this.passedCategory.id = res.id

        this.getCategories();
        this.getProducts();

      }else{

        this.goToPage('products');

      }

    });

  }

  // start and stop loading funx

  toastNotification(response) {

    this.functionService.showNotification(response);

  }
  
  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // get categories
  getCategories(){

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'GetCategories';

    this.functionService.getHttpRequestService(route).subscribe(
      (res: any)=>{

        if(res.status.toLowerCase() == httpSuccessText){

          this.categories = [];

          var categories = res.Categories

          for (let i = 0; i < 20; i++) {

            if(categories[i]){

              var category = {
                id: categories[i]._id,
                name: categories[i].name ? this.capitalize(categories[i].name.toLowerCase()) : null,
              }

              this.categories.push(category);
              
            }
            
          }

          this.categories.sort((a, b) => a.name.localeCompare(b.name))
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // capitalize text
  capitalize(sample){
    const words = sample.split(" ");

    for (let i = 0; i < words.length; i++) {
        words[i] = words[i][0].toUpperCase() + words[i].substr(1);
    }

    return words.join(" ");
  }

  // get products
  getProducts(){

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'GetCategoryProducts';
    var requestData = {
      categoryId: this.passedCategory.id
    }

    this.functionService.putHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        if(res.status.toLowerCase() == httpSuccessText){

          this.passedCategory.name = res.Categories.name

          this.productList = [];

          var products = res.Categories.product

          for (let i = 0; i < products.length; i++) {

            if(products[i]){

              var quantityExist = false;
              for (let j = 0; j < products[i].unitOfMeasurement.length; j++) {
                
                if(products[i].quantity[products[i].unitOfMeasurement[j]] > 0){

                  quantityExist = true;
                  break;

                }
                
              }

              var product = {
                id: products[i]._id,
                image: products[i].Imageurl ? products[i].Imageurl : './assets/img/sample.jpg',
                name: products[i].name ? products[i].name : null,
                priceInRange: products[i].unitOfMeasurement.length > 1 ? true : false,
                lowSellingPrice: 0,
                highSellingPrice: 0,
                super: products[i].superSales,
                quantityExist: quantityExist
              }
  
              var sellingPricesUnits = products[i].sellingPrice ? Object.keys(products[i].sellingPrice) : [];
              var sellingPrices = [];
  
              for (let j = 0; j < sellingPricesUnits.length; j++) {
  
                var unit = sellingPricesUnits[j];
                
                sellingPrices.push(products[i].sellingPrice[unit]);
                
              }
  
              product.lowSellingPrice = Math.min(...sellingPrices)
              if(product.priceInRange){
  
                product.highSellingPrice = Math.max(...sellingPrices)
  
              }
  
              this.productList.push(product);
              
            }
            
          }
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // go to category products
  goToCategoryProducts(id){

    this.goToPage('products/category/'+id)

  }

  // goto single product page
  goToSingleProduct(product){
    
    this.goToPage('products/single/'+product.id);

  }

}

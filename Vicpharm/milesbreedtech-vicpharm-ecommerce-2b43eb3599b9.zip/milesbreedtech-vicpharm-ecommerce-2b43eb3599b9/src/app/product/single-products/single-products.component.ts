import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../functions/request.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-single-products',
  templateUrl: './single-products.component.html',
  styleUrls: ['./single-products.component.scss']
})
export class SingleProductsComponent implements OnInit {

  // product details
  public productDetails: any = {
    id:  null,
    name: null
  }

  public relatedProductList: any = [];

  public cart: any = {
    totalQuantity: 1,
    quantity: 1,
    unitPrice: 0,
    unit: null,
    product: {}
  }

  public listOfCarts: any = [];

  constructor(
    private functionService: RequestService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {

    this.activatedRoute.params.subscribe((res)=>{

      if(res.id){

        this.productDetails.id = res.id

        this.getProductDetails();
        this.getListCart();

      }else{

        this.goToPage('products');

      }

    });

  }

  // start and stop loading funx

  toastNotification(response) {

    this.functionService.showNotification(response);

  }
  
  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // get product details
  getProductDetails(){

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'GetOneProduct';
    var requestData = {
      productId: this.productDetails.id
    }

    this.functionService.putHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        if(res.status.toLowerCase() == httpSuccessText){

          this.productDetails.id = res.Product._id
          this.productDetails.name = res.Product.name
          this.productDetails.description = res.Product.description
          this.productDetails.sellingPrice = res.Product.sellingPrice
          this.productDetails.unitOfMeasurement = res.Product.unitOfMeasurement
          this.productDetails.image = res.Product.Imageurl ? res.Product.Imageurl : './assets/img/sample.jpg'
          this.productDetails.quantity = res.Product.quantity

          this.productDetails.moreImages = [];
          for (let i = 0; i < 4; i++) {
            
            if(res.Product.moreImages[i]){

              this.productDetails.moreImages.push(res.Product.moreImages[i].imgUri)

            }
            
          }

          if(res.Product.category && res.Product.category[0]._id){

            this.getRelatedProducts(res.Product.category[0]._id)

          }

          this.cart.product = this.productDetails;
          this.cart.unit = this.productDetails.unitOfMeasurement[0];
          this.cart.unitPrice = this.productDetails.sellingPrice[this.cart.unit];
          this.cart.totalQuantity = this.productDetails.quantity[this.cart.unit];
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // get related products
  getRelatedProducts(categoryId){

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'GetCategoryProducts';
    var requestData = {
      categoryId: categoryId
    }

    this.functionService.putHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        if(res.status.toLowerCase() == httpSuccessText){

          this.relatedProductList = [];

          var products = res.Categories.product

          for (let i = 0; i < 4; i++) {

            if(products[i] && products[i]._id !== this.productDetails.id ){

              var product = {
                id: products[i]._id,
                image: products[i].Imageurl ? products[i].Imageurl : './assets/img/sample.jpg',
                name: products[i].name ? products[i].name : null,
                priceInRange: products[i].unitOfMeasurement.length > 1 ? true : false,
                lowSellingPrice: 0,
                highSellingPrice: 0,
                super: products[i].superSales
              }
  
              var sellingPricesUnits = products[i].sellingPrice ? Object.keys(products[i].sellingPrice) : [];
              var sellingPrices = [];
  
              for (let j = 0; j < sellingPricesUnits.length; j++) {
  
                var unit = sellingPricesUnits[j];
                
                sellingPrices.push(products[i].sellingPrice[unit]);
                
              }
  
              product.lowSellingPrice = Math.min(...sellingPrices)
              if(product.priceInRange){
  
                product.highSellingPrice = Math.max(...sellingPrices)
  
              }
  
              this.relatedProductList.push(product);
              
            }
            
          }
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // goto single product page
  goToSingleProduct(product){

    this.productDetails = {
      id:  null,
      name: null
    }

    this.relatedProductList = [];

    this.cart = {
      quantity: 0,
      unitPrice: 0,
      unit: null,
      product: {}
    }
    
    this.goToPage('products/single/'+product.id);

  }

  // get unit price
  getUnitPrice(event){

    if(this.productDetails.sellingPrice[this.cart.unit]){

      this.cart.unitPrice = this.productDetails.sellingPrice[this.cart.unit];

    }else{

      this.cart.unitPrice = null;

    }

  }

  // get list of carts
  getListCart(){

    this.functionService.getCart().subscribe((cart)=>{

      this.listOfCarts = cart;

    })

  }

  // add to cart
  addToCart(){

    if(this.cart.unit){

      if(this.cart.quantity > 0){

        var cart = {
          totalQuantity: this.cart.totalQuantity,
          quantity: this.cart.quantity,
          unitPrice: this.cart.unitPrice,
          unit: this.cart.unit,
          product: this.cart.product
        };

        var productExistingIndex = this.listOfCarts.findIndex(o => o.unit == cart.unit && o.product.id == cart.product.id);
        if(productExistingIndex > -1){

          this.listOfCarts[productExistingIndex].quantity = this.listOfCarts[productExistingIndex].quantity + cart.quantity;
          

        }else{

          this.listOfCarts.push(cart);

        }
        this.functionService.setCart(this.listOfCarts);

        this.goToPage('cart')

      }else{
  
        var requestResponse = 'Please enter the quantity.';
        this.toastNotification(requestResponse);
      }

    }else{

      var requestResponse = 'Please select the unit.';
      this.toastNotification(requestResponse);
    }

  }

}

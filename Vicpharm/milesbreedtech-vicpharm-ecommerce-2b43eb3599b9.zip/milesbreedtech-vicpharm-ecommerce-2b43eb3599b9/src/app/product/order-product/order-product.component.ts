import { Component, OnInit, ViewChild } from '@angular/core';
import { RequestService } from '../../functions/request.service';
import { PaystackOptions } from 'angular4-paystack';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-order-product',
  templateUrl: './order-product.component.html',
  styleUrls: ['./order-product.component.scss']
})
export class OrderProductComponent implements OnInit {

  public checkout: any = {
    cart: [],
    address: {
      country: 'nigeria',
      state: "federal capital territory",
      street: null
    },
    paymentMethod: null,
    contact: {
      firstName: null,
      lastName: null,
      phoneNumber: null,
      email: null
    }
  };
  public deliveryLocation: any = {
    locationName: null,
    longitude: null,
    latitude: null
  };
  public listOfStates: any = [
    "abia",
    "adamawa",
    "akwa Ibom",
    "anambra",
    "bauchi",
    "bayelsea",
    "benue",
    "borno",
    "cross River",
    "delta",
    "ebonyi",
    "edo",
    "ekiti",
    "enugu",
    "gombe",
    "imo",
    "jigawa",
    "kaduna",
    "kano",
    "katsina",
    "kebbi",
    "kogi",
    "kwara",
    "lagos",
    "nasarawa",
    "niger",
    "ogun",
    "ondo",
    "osun",
    "oyo",
    "plateau",
    "rivers",
    "sokoto",
    "taraba",
    "yobe",
    "zamfara",
    "federal capital territory"
  ];

  public invoice: any = {
    invoiceId: null,
    prescriptionProduct: null
  };
  public prescriptionDetails: any = {
    file: null,
    displayImage: null
  }
  public showLoader = false;
  public orderPayment: PaystackOptions = {
    email: null,
    amount: 0,
    ref: null,
  }

  // modal section
  public showModal: any = false;
  public modalData: any = {};

  @ViewChild("placesRef") placesRef;

  constructor(
    private functionService: RequestService,
    private authService: AuthService,
  ) { }

  ngOnInit(): void {

    this.getListCart();

    var contact: any = JSON.parse(localStorage.getItem('vicpharmEcommerceContact'))
    if(contact && contact.phoneNumber){
      this.checkout.contact = contact
    }

  }

  // start and stop loading funx
  startMajorLoading(){

    this.functionService.setLoading(true);

  }

  stopMajorLoading(){

    this.functionService.setLoading(false);

  }

  startLoading(){

    this.showLoader = true

  }

  stopLoading(){

    this.showLoader = false;

  }

  toastNotification(response) {

    this.functionService.showNotification(response);

  }

  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // get list of carts
  getListCart(){

    this.functionService.getCart().subscribe((cart)=>{

      this.checkout.cart = cart;

    })

  }

  public handleAddressChange(address) {
    console.log(address)

    this.deliveryLocation = {
      locationName: address.formatted_address,
      longitude: address.geometry.location.lng(),
      latitude: address.geometry.location.lat()
    };
  }

  // check entries
  checkEntries(){

    var requestResponse = null;

    if(this.checkout.cart.length > 0){

      if(this.checkout.paymentMethod){

        if(this.checkout.contact.firstName && this.checkout.contact.lastName && this.checkout.contact.phoneNumber){

          var defaultEmail = null;
          var user: any = JSON.parse(localStorage.getItem('vicpharm_ecommerce_user'));
          if(user){
            defaultEmail = user.email
          }
  
          this.checkout.contact.email = this.checkout.contact.email ? this.checkout.contact.email : defaultEmail;

          if(this.checkout.paymentMethod == 'card'){

            if(this.checkout.contact.email){
  
              if(this.checkout.address.street && this.checkout.address.state && this.checkout.address.country){
      
                this.generateInvoice()
      
              }else{
        
                requestResponse = 'Please enter your shipping details';
                this.toastNotification(requestResponse);
          
              }

            }else{

              requestResponse = 'Please enter your contact email address';
              this.toastNotification(requestResponse);

            }

          }else{

            if(this.checkout.address.street && this.checkout.address.state && this.checkout.address.country){
    
              this.generateInvoice()
    
            }else{
      
              requestResponse = 'Please enter your shipping details';
              this.toastNotification(requestResponse);
        
            }
            
          }
  
        }else{
    
          requestResponse = 'Please enter your contact details';
          this.toastNotification(requestResponse);
    
        }
      }else{
      
        requestResponse = 'Select method of payment';
        this.toastNotification(requestResponse);
      
      }

    }else{

      requestResponse = 'Cart is empty';
      this.toastNotification(requestResponse);

    }

  }

  // generate invoice
  generateInvoice(){

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    // organize order details
    var orderDetails = [];
    for (let i = 0; i < this.checkout.cart.length; i++) {
      
      var cart = {
        id: this.checkout.cart[i].product.id,
        quantity: this.checkout.cart[i].quantity,
        unitOfMeasurement: this.checkout.cart[i].unit
      }

      orderDetails.push(cart)
      
    }

    var numberPrefix = '+234';
    var extractedNumber = this.checkout.contact.phoneNumber.substring(1, this.checkout.contact.phoneNumber.length);
    var phoneNumber = numberPrefix+extractedNumber;

    var route = 'GenerateInvoice';
    var requestData = {
      orderDetails: orderDetails,
      deliveryLocation: this.checkout.address,
      contactPerson: {
        name: this.checkout.contact.firstName+' '+this.checkout.contact.lastName,
        phoneNumber: phoneNumber
      }
    }

    this.functionService.postHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.status.toLowerCase() == httpSuccessText){

          localStorage.setItem('vicpharmEcommerceContact', JSON.stringify(this.checkout.contact))

          var invoice = {
            contactPerson: res.contactPerson,
            deliveryLocation: res.deliveryLocation,
            distance: res.distance,
            invoiceId: res.invoiceId,
            shippingFee: res.shippingFee,
            subTotal: res.subTotalAmount - res.shippingFee - res.vat,
            totalAmount: res.totalAmount,
            totalDiscount: res.totalDiscount,
            vat: res.vat,
            prescriptionProduct: res.prescriptionProduct,
            continueToPay: res.prescriptionProduct ? false : true
          }

          this.invoice = invoice;

          if(this.checkout.paymentMethod == 'card'){

            this.orderPayment.email =  this.checkout.contact.email;
            this.orderPayment.amount =  this.invoice.totalAmount * 100;
            this.orderPayment.ref = 'vic-'+new Date().getTime() + this.generateReference()+'-web';

          }

          document.body.scrollTop = 0;
          document.documentElement.scrollTop = 0;
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // get image file
  onFileSelected() {
    
    var file:any = (<HTMLInputElement>document.getElementById('file')).files[0];
    this.prescriptionDetails.file = file;

    var r = new FileReader();

    r.onload = (e:any)=> {

      // data is in r.result
      this.prescriptionDetails.displayImage = e.target.result;

    }

    r.readAsDataURL(file);

  }

  // addPrescription
  addPrescription(){

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'UploadPrescription';

    var requestData = new FormData();
    requestData.append('invoiceId', this.invoice.invoiceId)
    requestData.append('image', this.prescriptionDetails.file)

    this.functionService.postHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.status.toLowerCase() == httpSuccessText){

          requestResponse = 'Prescription uploaded.';
          this.toastNotification(requestResponse);

          this.prescriptionDetails.file = null;
          this.prescriptionDetails.displayImage = null;

          this.invoice.continueToPay = true;
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // generate reference code
  generateReference(){

    var result           = '';

    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

    var charactersLength = 5;

    for( var i = 0; i < charactersLength; i++ ) {

      result += characters.charAt(Math.floor(Math.random() * charactersLength));

    }

    return result;

  }

  // cancel paystack payment
  cancelPayment(option){

    this.orderPayment.ref = 'vic-'+new Date().getTime() + this.generateReference()+'-web';

  }

  // place order
  placeOrder(payment?){

    this.startMajorLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';
    
    var requestData = {
      reference: payment ? payment.reference : this.checkout.paymentMethod,
      invoiceId: this.invoice.invoiceId,
    }

    if(this.authService.checkAuthenticated()){
      var route = 'PayForInvoice';

      this.functionService.putTokenHttpRequestService(route, requestData).subscribe(
        (res: any)=>{
  
          this.stopMajorLoading();
  
          if(res.status.toLowerCase() == httpSuccessText){
  
            requestResponse = 'Order placed successfully.';
            this.toastNotification(requestResponse);

            if(this.checkout.paymentMethod == 'bankTransfer'){

              var bankTransferIdArray = res.bankTransferId.split("-");

              var bankTransfer = {
                id: bankTransferIdArray[bankTransferIdArray.length - 1],
                bankDetail: res.bankDetail,
              }

              this.toggleModal(true, bankTransfer)

            }else{

              this.clearCheckoutCart()

            }
             
          }else{
        
            requestResponse = res.message;
            this.toastNotification(requestResponse);
        
          }
  
        },(err)=>{
  
          this.stopMajorLoading();
  
          requestResponse = err.error.message;
          this.toastNotification(requestResponse);
  
        }
  
      );

    }else{
      var route = 'GuestPayForInvoice';

      this.functionService.putHttpRequestService(route, requestData).subscribe(
        (res: any)=>{
  
          this.stopMajorLoading();
  
          if(res.status.toLowerCase() == httpSuccessText){
  
            requestResponse = 'Order placed successfully.';
            this.toastNotification(requestResponse);

            if(this.checkout.paymentMethod == 'bankTransfer'){

              var bankTransferIdArray = res.bankTransferId.split("-");

              var bankTransfer = {
                id: bankTransferIdArray[bankTransferIdArray.length - 1],
                bankDetail: res.bankDetail,
              }

              this.toggleModal(true, bankTransfer)

            }else{

              this.clearCheckoutCart()

            }
             
          }else{
        
            requestResponse = res.message;
            this.toastNotification(requestResponse);
        
          }
  
        },(err)=>{
  
          this.stopMajorLoading();
  
          requestResponse = err.error.message;
          this.toastNotification(requestResponse);
  
        }
  
      );

    }

  }

  // clear cart and checkout
  clearCheckoutCart(){

    this.checkout = {
      cart: [],
      address: {
        country: 'nigeria',
        state: 'FCT',
        street: ''
      },
      paymentMethod: null,
      contact: {
        firstName: null,
        lastName: null,
        phoneNumber: null,
        email: null
      }
    };
    this.invoice = {};
    this.functionService.setCart([]);
    this.toggleModal(false);
    this.goToPage('home')

  }

  // toggle modal section
  toggleModal(status, result?){

    this.showModal = status

    if(this.showModal){

      this.modalData = result
    }

  }

}

import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../functions/request.service';

@Component({
  selector: 'app-all-categories',
  templateUrl: './all-products.component.html',
  styleUrls: ['./all-products.component.scss']
})
export class AllProductsComponent implements OnInit {

  public priceSlider: any = {
    max: 100,
    min: 1,
    step: 1,
    value: 1,
    thumbLabel: true
  }

  // categories
  public categories: any = [];
  
  // products
  public productList: any = [];

  // pagination
  public pagination: any = {
    index: 1,
    total: null,
    itemPerPage: 20,
    lastPage:null,
    pages: []
  }

  constructor(
    private functionService: RequestService,
  ) { }

  ngOnInit(): void {

    this.getCategories();
    this.getProducts();

  }


  toastNotification(response) {

    this.functionService.showNotification(response);

  }
  
  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // get categories
  getCategories(){

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'GetCategories';

    this.functionService.getHttpRequestService(route).subscribe(
      (res: any)=>{

        if(res.status.toLowerCase() == httpSuccessText){

          this.categories = [];

          var categories = res.Categories

          for (let i = 0; i < 20; i++) {

            if(categories[i]){

              var category = {
                id: categories[i]._id,
                name: categories[i].name ? this.capitalize(categories[i].name.toLowerCase()) : null,
              }

              this.categories.push(category);
              
            }
            
          }

          this.categories.sort((a, b) => a.name.localeCompare(b.name))
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // capitalize text
  capitalize(sample){
    const words = sample.split(" ");

    for (let i = 0; i < words.length; i++) {
        words[i] = words[i][0].toUpperCase() + words[i].substr(1);
    }

    return words.join(" ");
  }

  // get products
  getProducts(){

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'GetOnlineInventories';
    var requestData = {
      page: this.pagination.index
    }

    this.productList = [];

    this.functionService.getHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        if(res.status.toLowerCase() == httpSuccessText){

          var products = res.Products

          for (let i = 0; i < products.length; i++) {

            if(products[i]){

              var quantityExist = false;
              for (let j = 0; j < products[i].unitOfMeasurement.length; j++) {
                
                if(products[i].quantity[products[i].unitOfMeasurement[j]] && products[i].quantity[products[i].unitOfMeasurement[j]] > 0){

                  quantityExist = true;
                  break;

                }
                
              }

              var product = {
                id: products[i]._id,
                image: products[i].Imageurl ? products[i].Imageurl : './assets/img/sample.jpg',
                name: products[i].name ? products[i].name : null,
                priceInRange: products[i].unitOfMeasurement.length > 1 ? true : false,
                lowSellingPrice: 0,
                highSellingPrice: 0,
                super: products[i].superSales,
                quantityExist: quantityExist
              }
  
              var sellingPricesUnits = products[i].sellingPrice ? Object.keys(products[i].sellingPrice) : [];
              var sellingPrices = [];
  
              for (let j = 0; j < sellingPricesUnits.length; j++) {
  
                var unit = sellingPricesUnits[j];
                
                sellingPrices.push(products[i].sellingPrice[unit]);
                
              }
  
              product.lowSellingPrice = Math.min(...sellingPrices)
              if(product.priceInRange){
  
                product.highSellingPrice = Math.max(...sellingPrices)
  
              }
  
              this.productList.push(product);
              
            }
            
          }

          this.pagination.total = res.totalItems
          this.structurePagination()
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // structure pagination
  structurePagination(){

    this.pagination.lastPage = Math.ceil(this.pagination.total/this.pagination.itemPerPage)

    var startIndex = this.pagination.index - 2
    if(startIndex < 1){
      startIndex = 1
    }

    var endIndex = this.pagination.lastPage + 2
    if(endIndex > this.pagination.lastPage){
      endIndex = this.pagination.lastPage
    }

    this.pagination.pages = [];
    for (let i = startIndex; i < endIndex + 1; i++) {
      
      if(this.pagination.pages.length < 5){

        this.pagination.pages.push(i);

      }
      
    }

  }

  // get page
  getPage(page){

    this.pagination.index = page;
    this.getProducts()

  }

  // toggle page
  togglePage(index){

    this.pagination.index = Number(this.pagination.index) + Number(index)
    this.getProducts()

  }

  // go to category products
  goToCategoryProducts(id){

    this.goToPage('products/category/'+id)

  }

  // goto single product page
  goToSingleProduct(product){
    
    this.goToPage('products/single/'+product.id);

  }

}

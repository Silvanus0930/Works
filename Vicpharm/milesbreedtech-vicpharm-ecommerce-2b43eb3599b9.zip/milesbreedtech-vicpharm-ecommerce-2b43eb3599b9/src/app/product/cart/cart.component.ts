import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../functions/request.service';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {

  public listOfCarts: any = [];

  constructor(
    private functionService: RequestService,
  ) { }

  ngOnInit(): void {

    this.getListCart();

  }

  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // get list of carts
  getListCart(){

    this.functionService.getCart().subscribe((cart)=>{

      this.listOfCarts = cart;

    })

  }

  // increase quantity
  increaseQuantity(product, increment){

    var quantity = product.quantity + increment
    if(quantity < 1){

      quantity = 1

    }else if(quantity > product.totalQuantity){

      quantity = product.totalQuantity

    }

    product.quantity = quantity

  }

  // remove product
  removeProduct(index){
    
    this.listOfCarts.splice(index,1);
    this.functionService.setCart(this.listOfCarts);
    
  }

  // proceedToCheckout
  proceedToCheckout(){

    this.goToPage('checkout')

  }

}

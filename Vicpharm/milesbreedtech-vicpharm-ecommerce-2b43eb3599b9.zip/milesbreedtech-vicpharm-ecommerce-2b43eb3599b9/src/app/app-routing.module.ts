import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from './auth/auth-guard.service';

import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { AllProductsComponent } from './product/all-products/all-products.component';
import { CartComponent } from './product/cart/cart.component';
import { SingleProductsComponent } from './product/single-products/single-products.component';
import { OrderProductComponent } from './product/order-product/order-product.component';
import { CategoryProductsComponent } from './product/category-products/category-products.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';


const routes: Routes = [
  { path: '', 
    redirectTo: '/home', 
    pathMatch: 'full' 
  },
  { path: 'home', 
    component: HomeComponent, 
    runGuardsAndResolvers: 'always'
  },
  { path: 'products', 
    component: AllProductsComponent, 
    runGuardsAndResolvers: 'always' 
  },
  { path: 'products/category/:id', 
    component: CategoryProductsComponent, 
    runGuardsAndResolvers: 'always' 
  },
  { path: 'products/single/:id', 
    component: SingleProductsComponent, 
    runGuardsAndResolvers: 'always' 
  },
  { path: 'cart', 
    component: CartComponent, 
    runGuardsAndResolvers: 'always' 
  },
  { 
    path: 'checkout', 
    component: OrderProductComponent, 
    runGuardsAndResolvers: 'always'
  },
  { path: 'contact', 
    component: ContactComponent, 
    runGuardsAndResolvers: 'always' 
  },
  { path: 'login/:from', 
    component: LoginComponent, 
    runGuardsAndResolvers: 'always' 
  },
  { path: 'register/:from', 
    component: RegisterComponent, 
    runGuardsAndResolvers: 'always' 
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollPositionRestoration: 'top'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrescriptionProductComponent } from './prescription-product.component';

describe('PrescriptionProductComponent', () => {
  let component: PrescriptionProductComponent;
  let fixture: ComponentFixture<PrescriptionProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrescriptionProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrescriptionProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

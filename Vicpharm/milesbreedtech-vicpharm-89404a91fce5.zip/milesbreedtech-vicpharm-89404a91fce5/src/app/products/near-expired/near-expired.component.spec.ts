import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NearExpiredComponent } from './near-expired.component';

describe('NearExpiredComponent', () => {
  let component: NearExpiredComponent;
  let fixture: ComponentFixture<NearExpiredComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NearExpiredComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NearExpiredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

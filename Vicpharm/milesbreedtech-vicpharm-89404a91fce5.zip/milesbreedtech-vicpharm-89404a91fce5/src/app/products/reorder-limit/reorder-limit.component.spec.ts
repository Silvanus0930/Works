import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReorderLimitComponent } from './reorder-limit.component';

describe('ReorderLimitComponent', () => {
  let component: ReorderLimitComponent;
  let fixture: ComponentFixture<ReorderLimitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReorderLimitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReorderLimitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

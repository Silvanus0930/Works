import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeactivedProductComponent } from './deactived-product.component';

describe('DeactivedProductComponent', () => {
  let component: DeactivedProductComponent;
  let fixture: ComponentFixture<DeactivedProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeactivedProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeactivedProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

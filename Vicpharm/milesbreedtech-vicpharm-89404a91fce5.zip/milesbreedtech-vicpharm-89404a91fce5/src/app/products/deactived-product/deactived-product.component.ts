import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { RequestService } from '../../functions/request.service';

@Component({
  selector: 'app-deactived-product',
  templateUrl: './deactived-product.component.html',
  styleUrls: ['./deactived-product.component.scss']
})
export class DeactivedProductComponent implements OnInit {

  // menu variables
  public activeInnerMenu: any = 'list';

  // product records variables
  public products: any = [];
  public selectedProduct: any = {};

  // pagination variables
  public pageIndex = 1;
  public totalRecords: any;
  public pageSize: any = 50;
  public pageArray = [];
  public noOfPages = 0;
  public activePagination: any = 0;

  // deactivate product variables
  public showDeactivateSearchItems = false;
  public showDeactivateSearchLoading = false;
  public searchDeactivateData: any;
  public searchDeactivateResult: any = [];
  public deactivateDetails: any = {
    item: '',
    status: false
  }

  constructor(
    private functionService: RequestService,
  ) { }

  ngOnInit(): void {

    this.getDeactivatedProducts();

  }

  // start and stop loading funx
  startLoading(){

    this.functionService.setLoading(true);

  }

  stopLoading(){

    this.functionService.setLoading(false);

  }

  toastNotification(response) {

    this.functionService.showNotification(response);

  }

  // toggle Inner Menu
  toggleInnerMenu(menu: any){

    this.activeInnerMenu = menu

  }
  
  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // get products
  getDeactivatedProducts(){

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'Product/GetDesactivatedProduct';
    var requestData = {
      page: this.pageIndex,
    }

    this.functionService.getTokenHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.status.toLowerCase() == httpSuccessText){

          this.products = [];

          var products = res.Products;

          for (let i = 0; i < products.length; i++) {
            
            if(products[i]){

              var product = {
                barCode: products[i].barCode,
                category: products[i].category[0],
                costPrice: products[i].costPrice,
                createdAt: products[i].createdAt,
                description: products[i].description,
                discount: products[i].discount,
                discountType: products[i].discountType,
                discountUnit: products[i].discountUnit,
                expiryDate: products[i].expiryDate,
                limitPrice: products[i].limitPrice,
                moreImages: products[i].moreImages,
                name: products[i].name,
                previousQuantity: products[i].previousQuantity,
                previousSellingPrice: products[i].previousSellingPrice,
                quantity: products[i].quantity,
                reOrderLimit: products[i].reOrderLimit,
                sellOnline: products[i].sellOnline,
                sellingPrice: products[i].sellingPrice,
                staffId: products[i].staffId,
                status: products[i].status,
                unitOfMeasurement: products[i].unitOfMeasurement,
                _id: products[i]._id,
                firstLetterOfCategory: products[i].category[0].name.substring(0,1)
              }

              this.products.push(product)

            }
            
          }

          this.structurePagination(res.totalItems);
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // structure pagination 
  structurePagination(totalItems){

    this.totalRecords = totalItems;

    this.noOfPages = Math.ceil(this.totalRecords/this.pageSize);

    this.pageArray = [];

    var start = this.pageIndex - 2;
    if(start < 0){

      start = 1

    }

    var end = this.pageIndex + 3;
    if(end < 6 && end <= this.noOfPages){

      end = 6

    }else if(end > this.noOfPages){

      end = this.noOfPages + 1

    }

    for (let i = start; i < end; i++) {

      this.pageArray.push(i);
      
    }

  }

  // get pages on scroll
  paginate(page){

    var pageIndex = this.pageIndex

    this.pageIndex = (this.pageIndex * 1) + (page * 1);

    if(this.pageIndex <= this.noOfPages && this.pageIndex > 0){

      this.getDeactivatedProducts();

    }else{

      this.pageIndex = pageIndex

    }

  }

  // get page on request
  getPage(page){

    if(page <= this.noOfPages){

      this.pageIndex = page;

      this.getDeactivatedProducts();

    }

  }

  // select product from product list
  selectProduct(product){

    this.goToPage('products/update/'+product._id)

  }

  // DEACTIVAVTE PRODUCT FUNCTION

  // search function
  searchDeactivateEvent(event){

    var searchData = event.target.value;

    if(searchData && searchData.toString().length > 2 ){

      this.searchDeactivateData = searchData;
      this.showDeactivateSearchItems = true;
      this.showDeactivateSearchLoading = true;
      this.searchDeactivateResult = [];

      this.searchDeactivateRequest();

    }

  }

  // close search result
  closeDeactivateSearch(){

    this.searchDeactivateResult = [];
    this.searchDeactivateData = '';
    this.showDeactivateSearchItems = false;
    this.showDeactivateSearchLoading = false;

  }

  // search request
  searchDeactivateRequest(){

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'Product/SearchProductByKeywords';
    var requestData = {
      keywords: this.searchDeactivateData,
    }

    this.functionService.putTokenHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        if(res.status.toLowerCase() == httpSuccessText){

          this.showDeactivateSearchLoading = false;

          if(res.Product.length > 0){

            this.searchDeactivateResult = [];

            var products = res.Product;
  
            for (let i = 0; i < products.length; i++) {
              
              if(products[i]){
  
                var product = {
                  category: products[i].category[0],
                  name: products[i].name,
                  costPrice: products[i].costPrice,
                  quantity: products[i].quantity,
                  unitOfMeasurement: products[i].unitOfMeasurement,
                  _id: products[i]._id,
                }
  
                this.searchDeactivateResult.push(product)
  
              }
              
            }
          }
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // create deactivate structure for the the selected item
  chooseProduct(product){

    this.deactivateDetails.item = product._id
    this.deactivateDetails.name = product.name
    
  }

  // deactivate function
  deactivateItem(deactivateForm: NgForm){

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'Product/DesactivaOrActivateProduct';
    var requestData: any = {
      productId: this.deactivateDetails.item,
      active: this.deactivateDetails.status
    }

    this.functionService.putTokenHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.status.toLowerCase() == httpSuccessText){

          requestResponse = 'Product deactiavted successfully.';
          this.toastNotification(requestResponse);

          deactivateForm.resetForm();

          this.closeDeactivateSearch()
          
          this.toggleInnerMenu('list')
          this.getDeactivatedProducts();
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }
    );

  }

}

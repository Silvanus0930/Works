import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReversedSalesRecordComponent } from './reversed-sales-record.component';

describe('ReversedSalesRecordComponent', () => {
  let component: ReversedSalesRecordComponent;
  let fixture: ComponentFixture<ReversedSalesRecordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReversedSalesRecordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReversedSalesRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../functions/request.service';
import { trigger, state, style, animate, transition, keyframes } from '@angular/animations';

@Component({
  selector: 'app-reversed-sales-record',
  templateUrl: './reversed-sales-record.component.html',
  styleUrls: ['./reversed-sales-record.component.scss'],
  animations: [
    trigger('animateArc', [
      state('true', style({
        width: '30%',
      })),
      state('false', style({
        width: '0%',
      })),
      transition('false => true', animate('500ms linear', keyframes([
        style({ width: '0%', }),
        style({ width: '30%', }),
      ]))),
      transition('true => false', animate('500ms linear', keyframes([
        style({ width: '30%', }),
        style({ width: '0%', }),
      ])))
    ]),
    trigger('animateOtherArc', [
      state('true', style({
        width: '70%',
      })),
      state('false', style({
        width: '100%',
      })),
      transition('false => true', animate('500ms linear', keyframes([
        style({ width: '100%', }),
        style({ width: '70%', }),
      ]))),
      transition('true => false', animate('500ms linear', keyframes([
        style({ width: '70%', }),
        style({ width: '100%', }),
      ])))
    ])
  ]
})
export class ReversedSalesRecordComponent implements OnInit {

  public shoppingCartView: string = 'false';
  public marketView: string = 'false'

  // sales records variables
  public records: any = [];
  public showSelectedRecord = false;
  public selectedRecord: any = {}

  // pagination variables
  public totalRecords: any;
  public pageSize: any = 50;
  public pageArray = [];
  public noOfPages = 0;
  public pageIndex = 1;
  public activePagination: any = 0;

  //filter variables
  public searchData: any;

  constructor(
    private functionService: RequestService,
  ) { }

  ngOnInit(): void {

    this.getRecords();
  }

  // start and stop loading funx
  startLoading(){

    this.functionService.setLoading(true);

  }

  stopLoading(){

    this.functionService.setLoading(false);

  }

  toastNotification(response) {

    this.functionService.showNotification(response);

  }

  // toggle side cart view
  toggleCartView(){
    this.shoppingCartView = this.shoppingCartView === 'false' ? 'true' : 'false';
    this.marketView = this.marketView === 'false' ? 'true' : 'false';
  }
  
  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // get records
  getRecords(){

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'Sales/GetReverseSales';
    var requestData = {
      page: this.pageIndex,
    }

    this.functionService.getTokenHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.status.toLowerCase() == httpSuccessText){

          this.records = res.sales;

          this.structurePagination(res.totalItems);
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // structure pagination 
  structurePagination(totalItems){

    this.totalRecords = totalItems;

    this.noOfPages = Math.ceil(this.totalRecords/this.pageSize);

    this.pageArray = [];

    var start = this.pageIndex - 2;
    if(start < 0){

      start = 1

    }

    var end = this.pageIndex + 3;
    if(end < 6 && end <= this.noOfPages){

      end = 6

    }else if(end > this.noOfPages){

      end = this.noOfPages + 1

    }

    for (let i = start; i < end; i++) {

      this.pageArray.push(i);
      
    }

  }

  // get pages on scroll
  paginate(page){

    var pageIndex = this.pageIndex

    this.pageIndex = (this.pageIndex * 1) + (page * 1);

    if(this.pageIndex <= this.noOfPages && this.pageIndex > 0){

     this.getRecords();

    }else{

      this.pageIndex = pageIndex

    }

  }

  // get page on request
  getPage(page){

    if(page <= this.noOfPages){

      this.pageIndex = page;

      this.getRecords();

    }

  }

  // select record fnc
  selectRecord(record){

    this.selectedRecord.customer = record.CustomerId ? record.CustomerId : null
    this.selectedRecord.createdAt = record.createdAt ? record.createdAt : null
    this.selectedRecord.receiptId = record.receiptId ? record.receiptId : null
    this.selectedRecord.staff = {
      name: record.staffId.personalInfo.firstName + ' ' + record.staffId.personalInfo.lastName,
      phoneNumber: record.staffId.personalInfo.phoneNumber,
      id: record.staffId._id
    }
    this.selectedRecord.reversalStaff = {
      name: record.reverseSalesStaffId.personalInfo.firstName + ' ' + record.reverseSalesStaffId.personalInfo.lastName,
      phoneNumber: record.reverseSalesStaffId.personalInfo.phoneNumber,
      id: record.reverseSalesStaffId._id
    }
    this.selectedRecord.totalAmount = record.totalAmount ? Number(record.totalAmount.toFixed(2)) : null
    this.selectedRecord.typeOfsales = record.typeOfsales ? record.typeOfsales : null
    this.selectedRecord.vat = record.vat ? record.vat : null
    this.selectedRecord._id = record._id ? record._id : null
    this.selectedRecord.products = [];
    this.selectedRecord.totalAmountAfterReturn = 0;

    for (let i = 0; i < record.productDetails.length; i++) {
      
      if(record.productDetails[i]){

        var soldProduct = record.productDetails[i];

        var product = {
          measurement: [],
        }
        
        // convert object to array
        var objectKeys = Object.keys(soldProduct.quantity);
        for (let j = 0; j < objectKeys.length; j++) {
          
          var unit = objectKeys[j];

          var measurement = {
            id: soldProduct.id,
            productName: soldProduct.productName,
            productUniqueId: soldProduct.productUniqueId,
            totalAmount: soldProduct.totalAmount,
            unitOfMeasurement: unit,
            sellingPrice: soldProduct.sellingPrice[unit],
            quantity: soldProduct.quantity[unit]
          }

          this.selectedRecord.products.push(measurement);
          
        }

      }
      
    }

    if(this.selectedRecord.returnProduct && this.selectedRecord.returnProduct.length > 0){

      var refundedAmount = 0;

      for (let i = 0; i < this.selectedRecord.returnProduct.length; i++) {
        
        if(this.selectedRecord.returnProduct[i].returnType.toLowerCase() == 'Refund'.toLowerCase()){

          refundedAmount = Number(refundedAmount) + Number(this.selectedRecord.returnProduct[i].amountReturn)

        }
        
      }

      this.selectedRecord.totalAmountAfterReturn = this.selectedRecord.totalAmount - refundedAmount;

    }

    if(record.paymentType[0].paymentType){

      this.selectedRecord.paymentType = record.paymentType ? record.paymentType : []

    }else{

      var paymentType = [
        {
          paymentType: record.paymentType,
          amount: this.selectedRecord.totalAmount
        }
      ]

      this.selectedRecord.paymentType = paymentType;

    }

    this.shoppingCartView = 'true';
    this.marketView = 'true';

  }

}

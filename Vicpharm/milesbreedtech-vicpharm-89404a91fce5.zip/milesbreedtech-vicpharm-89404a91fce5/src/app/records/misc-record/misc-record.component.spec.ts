import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MiscRecordComponent } from './misc-record.component';

describe('MiscRecordComponent', () => {
  let component: MiscRecordComponent;
  let fixture: ComponentFixture<MiscRecordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiscRecordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiscRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

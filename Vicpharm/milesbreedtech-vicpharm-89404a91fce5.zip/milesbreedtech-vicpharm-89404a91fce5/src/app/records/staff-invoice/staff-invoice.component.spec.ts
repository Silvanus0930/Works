import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffInvoiceComponent } from './staff-invoice.component';

describe('StaffInvoiceComponent', () => {
  let component: StaffInvoiceComponent;
  let fixture: ComponentFixture<StaffInvoiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StaffInvoiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffInvoiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

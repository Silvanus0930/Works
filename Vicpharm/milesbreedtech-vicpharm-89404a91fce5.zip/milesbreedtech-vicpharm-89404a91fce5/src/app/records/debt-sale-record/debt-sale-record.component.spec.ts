import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DebtSaleRecordComponent } from './debt-sale-record.component';

describe('DebtSaleRecordComponent', () => {
  let component: DebtSaleRecordComponent;
  let fixture: ComponentFixture<DebtSaleRecordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DebtSaleRecordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DebtSaleRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpirationRecordComponent } from './expiration-record.component';

describe('ExpirationRecordComponent', () => {
  let component: ExpirationRecordComponent;
  let fixture: ComponentFixture<ExpirationRecordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpirationRecordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpirationRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReturnRecordComponent } from './return-record.component';

describe('ReturnRecordComponent', () => {
  let component: ReturnRecordComponent;
  let fixture: ComponentFixture<ReturnRecordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReturnRecordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturnRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

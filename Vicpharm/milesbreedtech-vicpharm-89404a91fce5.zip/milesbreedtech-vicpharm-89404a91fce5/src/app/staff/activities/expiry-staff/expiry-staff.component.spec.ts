import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpiryStaffComponent } from './expiry-staff.component';

describe('ExpiryStaffComponent', () => {
  let component: ExpiryStaffComponent;
  let fixture: ComponentFixture<ExpiryStaffComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpiryStaffComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpiryStaffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

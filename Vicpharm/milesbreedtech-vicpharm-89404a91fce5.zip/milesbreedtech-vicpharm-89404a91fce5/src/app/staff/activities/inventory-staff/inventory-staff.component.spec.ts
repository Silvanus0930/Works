import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InventoryStaffComponent } from './inventory-staff.component';

describe('InventoryStaffComponent', () => {
  let component: InventoryStaffComponent;
  let fixture: ComponentFixture<InventoryStaffComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InventoryStaffComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InventoryStaffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

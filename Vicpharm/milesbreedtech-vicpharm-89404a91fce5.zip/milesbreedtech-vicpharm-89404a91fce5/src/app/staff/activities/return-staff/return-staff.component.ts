import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../../functions/request.service';
import { ActivatedRoute } from '@angular/router';
import { trigger, state, style, animate, transition, keyframes } from '@angular/animations';

@Component({
  selector: 'app-return-staff',
  templateUrl: './return-staff.component.html',
  styleUrls: ['./return-staff.component.scss'],
  animations: [
    trigger('animateArc', [
      state('true', style({
        width: '30%',
      })),
      state('false', style({
        width: '0%',
      })),
      transition('false => true', animate('500ms linear', keyframes([
        style({ width: '0%', }),
        style({ width: '30%', }),
      ]))),
      transition('true => false', animate('500ms linear', keyframes([
        style({ width: '30%', }),
        style({ width: '0%', }),
      ])))
    ]),
    trigger('animateOtherArc', [
      state('true', style({
        width: '70%',
      })),
      state('false', style({
        width: '100%',
      })),
      transition('false => true', animate('500ms linear', keyframes([
        style({ width: '100%', }),
        style({ width: '70%', }),
      ]))),
      transition('true => false', animate('500ms linear', keyframes([
        style({ width: '70%', }),
        style({ width: '100%', }),
      ])))
    ])
  ]
})
export class ReturnStaffComponent implements OnInit {

  public shoppingCartView: string = 'false';
  public marketView: string = 'false'

  // staff details
  public staffId: any = null;

  // return records variables
  public records: any = [];
  public showSelectedRecord = false;
  public selectedRecord: any = {}

  // pagination variables
  public totalRecords: any;
  public pageSize: any = 50;
  public pageArray = [];
  public noOfPages = 0;
  public pageIndex = 1;
  public activePagination: any = 0;

  //filter variables
  public searchData: any;

  constructor(
    private functionService: RequestService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {

    this.activatedRoute.params.subscribe((page)=>{

      if(page){

        if(page.id){

          this.staffId = page.id;

          this.getRecords();

        }
        
      }

    });
  }

  // start and stop loading funx
  startLoading(){

    this.functionService.setLoading(true);

  }

  stopLoading(){

    this.functionService.setLoading(false);

  }

  toastNotification(response) {

    this.functionService.showNotification(response);

  }

  // toggle side cart view
  toggleCartView(){
    this.shoppingCartView = this.shoppingCartView === 'false' ? 'true' : 'false';
    this.marketView = this.marketView === 'false' ? 'true' : 'false';
  }
  
  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // get records
  getRecords(){

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'Product/GetStaffReturnProduct';
    var requestData = {
      staffId: this.staffId,
      page: this.pageIndex,
    }

    this.functionService.putTokenHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.status.toLowerCase() == httpSuccessText){

          this.records = res.Products;

          this.structurePagination(res.totalItems);
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // structure pagination 
  structurePagination(totalItems){

    this.totalRecords = totalItems;

    this.noOfPages = Math.ceil(this.totalRecords/this.pageSize);

    this.pageArray = [];

    var start = this.pageIndex - 2;
    if(start < 0){

      start = 1

    }

    var end = this.pageIndex + 3;
    if(end < 6 && end <= this.noOfPages){

      end = 6

    }else if(end > this.noOfPages){

      end = this.noOfPages + 1

    }

    for (let i = start; i < end; i++) {

      this.pageArray.push(i);
      
    }

  }

  // get pages on scroll
  paginate(page){

    var pageIndex = this.pageIndex

    this.pageIndex = (this.pageIndex * 1) + (page * 1);

    if(this.pageIndex <= this.noOfPages && this.pageIndex > 0){

     this.getRecords();

    }else{

      this.pageIndex = pageIndex

    }

  }

  // get page on request
  getPage(page){

    if(page <= this.noOfPages){

      this.pageIndex = page;

      this.getRecords();

    }

  }

  // select record fnc
  selectRecord(record){

    this.selectedRecord._id = record._id ? record._id : null
    this.selectedRecord.amountReturn = record.amountReturn ? record.amountReturn : null;
    this.selectedRecord.createdAt = record.createdAt ? record.createdAt : null;
    this.selectedRecord.returnType = record.returnType ? record.returnType : null;
    this.selectedRecord.salesId = record.salesId ? record.salesId : null;
    this.selectedRecord.comment = record.comment ? record.comment : null;
    this.selectedRecord.staff = record.staffId ? {
      name: record.staffId.personalInfo.firstName + ' ' + record.staffId.personalInfo.lastName,
      phoneNumber: record.staffId.personalInfo.phoneNumber,
      id: record.staffId._id
    } : {
      name: null,
      phoneNumber: null,
      id: null
    }
    
    this.selectedRecord.product = {
      id:  null,
      productName:  null,
      unitOfMeasurement:  null,
      returnedQuantity:  null,
      soldQuantity:  null,
      sellingPrice:  null,
    }

    // convert returnedMeasurement object to array
    var returnedObjectKeys = Object.keys(record.returnQuantity);
    for (let j = 0; j < returnedObjectKeys.length; j++) {
      
      var returnedUnit = returnedObjectKeys[j];

      this.selectedRecord.product = {
        id: record.productDetail[0].id,
        productName: record.productDetail[0].productName,
        unitOfMeasurement: returnedUnit,
        returnedQuantity: record.returnQuantity[returnedUnit],
        soldQuantity: record.productDetail[0].quantity[returnedUnit],
        sellingPrice: record.productDetail[0].sellingPrice[returnedUnit]
      }
      
    }

    this.shoppingCartView = 'true';
    this.marketView = 'true';

  }

}

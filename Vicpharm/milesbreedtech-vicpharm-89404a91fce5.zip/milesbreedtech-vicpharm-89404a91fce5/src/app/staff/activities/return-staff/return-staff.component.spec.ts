import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReturnStaffComponent } from './return-staff.component';

describe('ReturnStaffComponent', () => {
  let component: ReturnStaffComponent;
  let fixture: ComponentFixture<ReturnStaffComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReturnStaffComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturnStaffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

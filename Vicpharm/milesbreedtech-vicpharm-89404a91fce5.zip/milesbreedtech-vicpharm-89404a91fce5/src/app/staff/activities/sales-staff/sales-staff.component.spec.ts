import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesStaffComponent } from './sales-staff.component';

describe('SalesStaffComponent', () => {
  let component: SalesStaffComponent;
  let fixture: ComponentFixture<SalesStaffComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SalesStaffComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalesStaffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

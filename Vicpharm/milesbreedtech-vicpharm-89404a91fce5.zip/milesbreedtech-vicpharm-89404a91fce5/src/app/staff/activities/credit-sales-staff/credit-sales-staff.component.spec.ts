import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreditSalesStaffComponent } from './credit-sales-staff.component';

describe('CreditSalesStaffComponent', () => {
  let component: CreditSalesStaffComponent;
  let fixture: ComponentFixture<CreditSalesStaffComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreditSalesStaffComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditSalesStaffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

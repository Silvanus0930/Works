import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../../functions/request.service';
import { ActivatedRoute } from '@angular/router';
import { trigger, state, style, animate, transition, keyframes } from '@angular/animations';

@Component({
  selector: 'app-credit-sales-staff',
  templateUrl: './credit-sales-staff.component.html',
  styleUrls: ['./credit-sales-staff.component.scss'],
  animations: [
    trigger('animateArc', [
      state('true', style({
        width: '30%',
      })),
      state('false', style({
        width: '0%',
      })),
      transition('false => true', animate('500ms linear', keyframes([
        style({ width: '0%', }),
        style({ width: '30%', }),
      ]))),
      transition('true => false', animate('500ms linear', keyframes([
        style({ width: '30%', }),
        style({ width: '0%', }),
      ])))
    ]),
    trigger('animateOtherArc', [
      state('true', style({
        width: '70%',
      })),
      state('false', style({
        width: '100%',
      })),
      transition('false => true', animate('500ms linear', keyframes([
        style({ width: '100%', }),
        style({ width: '70%', }),
      ]))),
      transition('true => false', animate('500ms linear', keyframes([
        style({ width: '70%', }),
        style({ width: '100%', }),
      ])))
    ])
  ]
})
export class CreditSalesStaffComponent implements OnInit {

  public shoppingCartView: string = 'false';
  public marketView: string = 'false'

  // staff details
  public staffId: any = null;

  // sales records variables
  public records: any = [];
  public showSelectedRecord = false;
  public selectedRecord: any = {}

  // pagination variables
  public totalRecords: any;
  public pageSize: any = 50;
  public pageArray = [];
  public noOfPages = 0;
  public pageIndex = 1;
  public activePagination: any = 0;
  public filterShow: any = false;

  // Payment variables
  public history: any = [];

  //filter variables
  public searchData: any;
  

  constructor(
    private functionService: RequestService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {

    this.activatedRoute.params.subscribe((page)=>{

      if(page){

        if(page.id){

          this.staffId = page.id;

          this.getRecords();

        }
        
      }

    });
  }

  // start and stop loading funx
  startLoading(){

    this.functionService.setLoading(true);

  }

  stopLoading(){

    this.functionService.setLoading(false);

  }

  toastNotification(response) {

    this.functionService.showNotification(response);

  }

  // toggle side cart view
  toggleCartView(){
    this.shoppingCartView = this.shoppingCartView === 'false' ? 'true' : 'false';
    this.marketView = this.marketView === 'false' ? 'true' : 'false';
  }
  
  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // get records
  getRecords(){

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'Sales/GetStaffCreditSales';
    var requestData = {
      staffId: this.staffId,
      page: this.pageIndex,
    }

    this.functionService.putTokenHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.status.toLowerCase() == httpSuccessText){

          this.records = res.sales;

          this.structurePagination(res.totalItems);
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // structure pagination 
  structurePagination(totalItems){

    this.totalRecords = totalItems;

    this.noOfPages = Math.ceil(this.totalRecords/this.pageSize);

    this.pageArray = [];

    var start = this.pageIndex - 2;
    if(start < 0){

      start = 1

    }

    var end = this.pageIndex + 3;
    if(end < 6 && end <= this.noOfPages){

      end = 6

    }else if(end > this.noOfPages){

      end = this.noOfPages + 1

    }

    for (let i = start; i < end; i++) {

      this.pageArray.push(i);
      
    }

  }

  // get pages on scroll
  paginate(page){

    var pageIndex = this.pageIndex

    this.pageIndex = (this.pageIndex * 1) + (page * 1);

    if(this.pageIndex <= this.noOfPages && this.pageIndex > 0){

     this.getRecords();

    }else{

      this.pageIndex = pageIndex

    }

  }

  // get page on request
  getPage(page){

    if(page <= this.noOfPages){

      this.pageIndex = page;

      this.getRecords();

    }

  }

  // select record fnc
  selectRecord(record){

    this.selectedRecord.customer = record.CustomerId ? record.CustomerId : null
    this.selectedRecord.createdAt = record.createdAt ? record.createdAt : null
    this.selectedRecord.expectedDate = record.expectedDate ? record.expectedDate : null
    this.selectedRecord.remainingAmount = record.remainingAmount ? record.remainingAmount : null
    this.selectedRecord.paid = record.paid ? record.paid : null
    this.selectedRecord.active = record.active ? record.active : null
    this.selectedRecord.staff = {
      name: record.staffId.personalInfo.firstName + ' ' + record.staffId.personalInfo.lastName,
      phoneNumber: record.staffId.personalInfo.phoneNumber,
      id: record.staffId._id
    }
    this.selectedRecord.totalAmount = record.totalAmount ? Number(record.totalAmount.toFixed(2)) : null
    this.selectedRecord._id = record._id ? record._id : null
    this.selectedRecord.products = [];

    for (let i = 0; i < record.productDetails.length; i++) {
    
      if(record.productDetails[i]){

        var soldProduct = record.productDetails[i];

        var product = {
          measurement: [],
        }
        
        // convert object to array
        var objectKeys = Object.keys(soldProduct.quantity);
        for (let j = 0; j < objectKeys.length; j++) {
          
          var unit = objectKeys[j];

          var measurement = {
            id: soldProduct.id,
            productName: soldProduct.productName,
            productUniqueId: soldProduct.productUniqueId,
            totalAmount: soldProduct.totalAmount,
            unitOfMeasurement: unit,
            sellingPrice: soldProduct.sellingPrice[unit],
            quantity: soldProduct.quantity[unit]
          }

          this.selectedRecord.products.push(measurement);
          
        }

      }
      
    }

    if(this.selectedRecord.paid.length > 0){

      this.history = this.selectedRecord.paid;

    }

    this.shoppingCartView = 'true';
    this.marketView = 'true';

  }

}

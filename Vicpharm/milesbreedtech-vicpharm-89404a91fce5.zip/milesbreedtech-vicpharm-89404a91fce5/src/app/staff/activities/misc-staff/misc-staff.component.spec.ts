import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MiscStaffComponent } from './misc-staff.component';

describe('MiscStaffComponent', () => {
  let component: MiscStaffComponent;
  let fixture: ComponentFixture<MiscStaffComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiscStaffComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiscStaffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

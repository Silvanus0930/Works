import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EcommerceNotificationComponent } from './ecommerce-notification.component';

describe('EcommerceNotificationComponent', () => {
  let component: EcommerceNotificationComponent;
  let fixture: ComponentFixture<EcommerceNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EcommerceNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EcommerceNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

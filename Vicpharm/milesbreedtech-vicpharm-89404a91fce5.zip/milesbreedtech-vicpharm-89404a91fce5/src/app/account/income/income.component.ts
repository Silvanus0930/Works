import { Component, OnInit, OnDestroy, EventEmitter, Output } from '@angular/core';
import { RequestService } from '../../functions/request.service';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import * as moment from 'moment';

@Component({
  selector: 'app-income',
  templateUrl: './income.component.html',
  styleUrls: ['./income.component.scss']
})
export class IncomeComponent implements OnInit {

  // currency variables
  public currency: any  = 'NGN';

  // profit/loss analysis variables
  public debtSales: any = [];
  public analysis: any = {
    totalDebt: 0,
    totalSales: 0,
    totalCost: 0,
    value: 0,
    result: null,
  };

  // date picker variable
  public selectedFromDate: any = null;
  public selectedToDate: any = null;
  public dateFilterShow = false;

  @Output() dateChange: EventEmitter<MatDatepickerInputEvent<any>>

  constructor(
    private functionService: RequestService,
  ) { }

  ngOnInit(): void {

    this.selectedToDate = moment(new Date()).format('YYYY-MM-D')
    this.selectedFromDate = moment(new Date()).subtract(30, "days").format('YYYY-MM-D')

    this.getDateRangeRecords()
  }

  // start and stop loading funx
  startLoading(){

    this.functionService.setLoading(true);

  }

  stopLoading(){

    this.functionService.setLoading(false);

  }

  toastNotification(response) {

    this.functionService.showNotification(response);

  }
  
  // goto selected page
  goToPage(page){

    this.functionService.setMenu(page);

  }

  // date event
  dateChangeFnc(event, selector){

    this.checkFilter();

  }

  // check filter date range
  checkFilter(){

    if(this.selectedFromDate == null || this.selectedToDate == null){

      var requestResponse = 'Select from date and to date';
      this.toastNotification(requestResponse);

    }else if(this.selectedFromDate !== null && this.selectedToDate !== null){

      this.getDateRangeRecords();

    }else{
      
      this.selectedFromDate = null;
      this.selectedToDate = null;

      this.dateFilterShow = false;

    }

  }
  
  // get record between date range
  getDateRangeRecords(){

    this.startLoading();

    var httpSuccessText = 'OK'.toLowerCase();
    var requestResponse = '';

    var route = 'Account/GetBalanceSheetByDateRange';
    var requestData = {
      startDate: this.selectedFromDate,
      endDate: this.selectedToDate,
    }

    this.functionService.putTokenHttpRequestService(route, requestData).subscribe(
      (res: any)=>{

        this.stopLoading();

        if(res.status.toLowerCase() == httpSuccessText){

          this.analyzeBalanceSheet(res.BalanceSheetSales, res.DebitSales)
           
        }else{
      
          requestResponse = res.message;
          this.toastNotification(requestResponse);
      
        }

      },(err)=>{

        this.stopLoading();

        requestResponse = err.error.message;
        this.toastNotification(requestResponse);

      }

    );

  }

  // analyse balance sheet
  analyzeBalanceSheet(balanceSheet, debitSales){

    this.analysis.totalSales = 0;
    this.analysis.totalCost = 0
    this.analysis.value = 0
    this.analysis.result = null

    for (let i = 0; i < balanceSheet.length; i++) {
      
      this.analysis.totalSales = Number(this.analysis.totalSales) + Number(balanceSheet[i].TotalSales)
      this.analysis.totalCost = Number(this.analysis.totalCost) + Number(balanceSheet[i].TotalCostPrice)
      
    }

    this.analysis.value = this.analysis.totalSales - this.analysis.totalCost;

    if(this.analysis.value < 0){

      this.analysis.result = 'loss';

    }else{

      this.analysis.result = 'profit';

    }

    this.analysis.totalDebt = 0
    this.debtSales = debitSales;
    for (let i = 0; i < this.debtSales.length; i++) {
      
      this.analysis.totalDebt = Number(this.analysis.totalDebt) + Number(this.debtSales[i].remainingAmount)

    }

  } 


}

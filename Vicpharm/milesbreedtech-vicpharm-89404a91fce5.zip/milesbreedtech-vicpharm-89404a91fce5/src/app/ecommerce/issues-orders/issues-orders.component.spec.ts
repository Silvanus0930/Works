import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IssuesOrdersComponent } from './issues-orders.component';

describe('IssuesOrdersComponent', () => {
  let component: IssuesOrdersComponent;
  let fixture: ComponentFixture<IssuesOrdersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IssuesOrdersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IssuesOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

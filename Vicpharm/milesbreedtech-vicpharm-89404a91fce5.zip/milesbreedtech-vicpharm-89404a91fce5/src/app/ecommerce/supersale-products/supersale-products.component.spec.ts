import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupersaleProductsComponent } from './supersale-products.component';

describe('SupersaleProductsComponent', () => {
  let component: SupersaleProductsComponent;
  let fixture: ComponentFixture<SupersaleProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupersaleProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupersaleProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

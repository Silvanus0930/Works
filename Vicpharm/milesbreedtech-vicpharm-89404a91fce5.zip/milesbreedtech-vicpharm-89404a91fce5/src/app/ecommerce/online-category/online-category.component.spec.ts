import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineCategoryComponent } from './online-category.component';

describe('OnlineCategoryComponent', () => {
  let component: OnlineCategoryComponent;
  let fixture: ComponentFixture<OnlineCategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineCategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransitOrdersComponent } from './transit-orders.component';

describe('TransitOrdersComponent', () => {
  let component: TransitOrdersComponent;
  let fixture: ComponentFixture<TransitOrdersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransitOrdersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransitOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
